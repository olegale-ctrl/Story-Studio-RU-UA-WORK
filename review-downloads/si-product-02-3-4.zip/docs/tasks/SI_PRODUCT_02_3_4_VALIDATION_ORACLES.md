# SI-PRODUCT-02.3.4 — Pre-execution Validation Oracles

**FROZEN BEFORE SCENARIO EXECUTION — 2026-11-16.**
Base: `4dd1805ed19d1e76ef525f2adb0e746089a70465`.
Status: validation expectations, not new product/eligibility/authority rules.

This document is written before generating pipeline outputs. Its SHA-256 is saved
outside Git before execution and checked throughout validation and packaging.
Expected values below come from supplied synthetic inputs and the accepted code/
contracts, not from the outputs of these new scenarios. No PASS-driven rewrite.
Any incorrect expectation must remain here with a separate review note in REPORT.

## Independent criteria and procedure

- Five distinct topics, explicitly artificial local materials and human/model labels.
  No real citations, medical instructions, retrieved documents or actual human reviews.
- For each CASE: mode A has no SI frame; mode B supplies a separately prepared valid
  synthetic SI frame. These frames are test inputs, not converted research records.
  Their generic SI semantic view intentionally has no proven research correspondence.
- Both modes run with API locale ru and uk: 20 paths. Preserve originals; no translation.
- Public sequence: intake → analyze → integrate; B additionally runs the public
  evaluator and Preview as independent comparators of the bridge's returned values.
- Exact references/bytes and nonmutation, all blockers/gaps/limits, declared creativity,
  no rating import, no invented findings, no semantic-equivalence claim, no production.
- Fail closed for corrupted inputs as prescribed by existing APIs; do not add refusal
  policies. An intact STALE view remains STALE; absent inputs remain UNKNOWN/NOT_RUN.
- A: intake NEEDS_INPUT is expected (manual ratings UNKNOWN/no optional frame), valid
  dossier still exists. Evidence status OK, bridge status OK, SI context NO_FRAME,
  no Preview/evaluator result; scope NO_FRAME, semantic_coverage_verified=false.
- B: exact same research dossier/evidence, frame passed unchanged; bridge status OK,
  actual SI outcome below, scope UNVERIFIED_SCOPE and semantic_coverage_verified=false.
  Evidence readiness never changes because a frame is supplied or its score is high.
- All paths: NOT_ASSESSED production, recommendation_generated=false; actual Preview
  grants_permission/permissions_granted remain false. No source/model statement becomes
  an authenticated reviewer or evidence of science/rights through these checks.

Structural PASS means mechanically observed conformance only. It does not establish
understandability/usefulness to a person, research quality or global completeness.

## Predeclared per-case oracles

### CASE-01 — «Почему исчезли древние цивилизации?»

Goal: show competing explanations, insufficient support and need to narrow scope.
Synthetic inputs: two alternative hypothesis records, artificial text listing H1/H2,
a HIGH separate-human-declared critique; two recorded alternative angles and a hook.
Intentional gaps: one central claim has no supporting link; uncertainty HIGH; review
and original material verification remain incomplete. Broad question must be narrowed.
Expected evidence readiness: **NEEDS_INPUT**. Required gaps: EVIDENCE_MISSING,
SOURCE_REVIEW_MISSING, CRITIQUE_HIGH. Both claims/angles, uncertainty and critique retained.
B expected SI eligibility: **ELIGIBLE_FOR_CREATIVE**, aggregate Known 1000, from its
independent generic SI fixture; this does not cover either research hypothesis.
Forbidden: one proven universal cause of all vanished civilizations; invented consensus;
SI high score clearing the research gap or granting development/production authority.
Editor-use criteria: can locate both hypotheses, their limitations, missing support,
provided alternative angles and explicit narrowing action; human utility NOT_ASSESSED.

### CASE-02 — «Можно ли доверять ИИ в медицинских советах?»

Goal: expose unsupported generalization and distinguish science information from advice.
Synthetic inputs: a record describing an intentionally unsupported test generalization,
CRITICAL declared human critique and a safety-boundary note. No actual medical advice.
Intentional gaps: central support empty, material not retrieved and no exact fragment
or pointer; UNKNOWN uncertainty; no independent clinical or scientific evidence.
Expected evidence readiness: **NEEDS_INPUT**. Required gaps: EVIDENCE_MISSING,
SOURCE_NOT_RETRIEVED, FRAGMENT_UNCONFIRMED, CRITIQUE_HIGH. CRITICAL retained.
B expected SI eligibility: **BLOCKED**, aggregate Known 1000: the independently prepared
SI frame has an unreviewed central claim. High score must not remove that blocker.
Forbidden: medical instructions, claims of clinical reliability, permission to develop
risky content, treating a critic label as medical expertise or scientific approval.
Editor-use criteria: can identify missing support, severity and the supplied requirement
for human expert consideration; human utility NOT_ASSESSED.

### CASE-03 — «Почему самолёты не падают при турбулентности?»

Goal: preserve explanatory potential while exposing absolute wording and source limits.
Synthetic inputs: an artificial teaching analogy, recorded support, HIGH declared human
critique about wording, a supplied alternative angle, hook and illustrative visual need.
Intentional gaps: nonempty applicability limits, integrity only HASH_REPORTED, further
human consideration needed. The title's absolute assertion must not become a fact.
Expected evidence readiness: **NEEDS_REVIEW**. Required gaps: SOURCE_REVIEW_MISSING,
CLAIM_REVIEW_MISSING, CRITIQUE_HIGH; visuals/angle remain recorded proposals only.
B expected SI eligibility: **ELIGIBLE_FOR_CREATIVE**, aggregate Known 1000, independent
of the research topic's narrative/visual appeal or preliminary ratings.
Forbidden: claiming aviation safety facts were verified; generated visual assets/rights;
turning topic attractiveness or a manual proposal into the SI score.
Editor-use criteria: can find exact wording caution, applicability limits and the
provided illustrative direction; human utility NOT_ASSESSED.

### CASE-04 — «Загадочные сигналы из космоса»

Goal: separate observation from hypothesis and expose repeated weak material.
Synthetic inputs: two local source labels for the same artificial bytes/hash; the
second source references the first; two records distinguish observation/interpretation;
a MODEL_PROPOSED critique, and a provided non-sensational alternative angle.
Intentional gaps: material not retrieved, observations unreviewed, UNKNOWN uncertainty;
model critique is not an independent human review; scientific origin remains unknown.
Expected evidence readiness: **NEEDS_INPUT**. Required gaps: MATERIAL_REUSED,
SOURCE_NOT_RETRIEVED, CLAIM_REVIEW_MISSING, CRITIQUE_INDEPENDENCE_UNKNOWN, CRITIQUE_HIGH.
Both source entries remain; shared material is not two independent confirmations.
B expected SI eligibility: **NEEDS_INPUT**, aggregate UNKNOWN: one SI rating is UNKNOWN,
with a genuine correctly bound supplied frame. Research preliminary ratings stay separate.
Forbidden: proven extraterrestrial origin; treating hypothesis as observation; model
critique as human approval; inventing a source, quote or independent corroboration.
Editor-use criteria: can trace reuse, source dependency, claim kind and alternative
explanations; human utility NOT_ASSESSED.

### CASE-05 — «Почему некоторые популярные исторические факты оказались мифами?»

Goal: preserve contrary testimony, source lineage and factual/interpretive distinctions.
Synthetic inputs: two different artificial fragments, second source explicitly derives
from first, supporting+contradicting links, recorded interpretive alternative angle;
a HIGH self-review declared as SEPARATE_HUMAN to test the known inconsistency guard.
Intentional gaps: no selected real historical example; limited sources/contexts;
independence not established, uncertainty and contradiction remain unresolved.
Expected evidence readiness: **NEEDS_REVIEW**. Required gaps: CONTRADICTION_UNRESOLVED,
SOURCE_REVIEW_MISSING, CRITIQUE_INDEPENDENCE_UNKNOWN, CRITIQUE_HIGH. Source upstream_refs,
contradicting links and provided interpretation/angle stay exact; no majority verdict.
B expected SI eligibility: **BLOCKED**, aggregate Known 1000, from an independently
prepared SI frame with contradicting evidence on a central claim.
Forbidden: all popular history is false; invented debunking of a real event; two
source labels as independent corroboration; self-review as independent human critique.
Editor-use criteria: can see the need to choose a specific example, examine original
source/dependency and resolve contrary testimony; human utility NOT_ASSESSED.

## Qualitative validation rubric, predeclared for every CASE

| Trait | Question | Without independent human editor |
|---|---|---|
| Clarity | Can a person understand the topic state? | NOT_ASSESSED |
| Traceability | Can a person follow reasons in practice? | NOT_ASSESSED |
| Risk visibility | Does a person notice essential risks? | NOT_ASSESSED |
| Actionability | Can a person use/prioritize next actions? | NOT_ASSESSED |
| Creative usefulness | Does a person select a useful direction? | NOT_ASSESSED |

Separate structural observations (exact refs, preserved lists, linked gaps, controlled
limitations) can PASS; none is silently promoted to a human rubric PASS. No overall
utility score or topic ranking. Automated output inspection is a preliminary expert
hypothesis only, not confirmed user validation.

## Negative/regression expectations

Changed dossier/snapshot/SHA, substituted evidence/RRef, mismatched explicit versus
embedded frame and extra already_verified fields: controlled INVALID, report=None.
UNKNOWN remains UNKNOWN; full intact STALE has genuine null SI eligibility/aggregate.
Invalid SI graph: controlled bridge INVALID. HIGH/CRITICAL, repeats, self/model/missing
critique, contradicting links and unverified correspondence remain visible as applicable.
No production grants, no automatic preliminary-rating import, no mutations or side
effects in new scenario paths. Full existing tests remain required, without production
code edits, skipped failures or invented refusals. Legacy D1 synthetic full-regression
media are not research production and must not enter the review archive.
