# SI-PRODUCT-02.3.4 — Product Gaps and Validation Limits

2026-11-16. **Validation observations / proposals, not new contracts or implementation.**
Base: `4dd1805ed19d1e76ef525f2adb0e746089a70465`.
Evidence: 20 actual synthetic A/B × ru/uk paths in the review package, immutable
pre-run oracles, and separate OR-01 review in VALIDATION_REPORT.
No independent human editor participated. All five qualitative traits for every
CASE remain **NOT_ASSESSED**. Candidate human-impact statements below are preliminary
AI output-inspection hypotheses, not confirmed usability findings or SI ratings.

## A. Contract defects

No confirmed violation of existing contracts found in the exercised scenarios.
This is a limited validation result, not proof of completeness or real-world truth.

- CASE-04/B initially disagreed with the new validation oracle. Approved R1 §3.2
  and frozen N04 require NEEDS_RESEARCH for a well-formed UNKNOWN rating, with
  aggregate UNKNOWN. The runtime follows that rule. No contract was amended.
- Research readiness, supplied-view SI eligibility and production authority are
  separate. Their differing values are intended, not a contract defect.
- Unverified correspondence, no automatic SI builder and absent reviewer/rights
  authority are intentional boundaries. They are not failures to implement new powers.

## B. Implementation defects

No confirmed production implementation defect found in the exercised scenarios.
No production code, schemas, existing tests or contracts were changed.

OR-01 is a **validation-methodology error**, not an implementation defect: original
CASE-04/B expected NEEDS_INPUT, actual and contract require NEEDS_RESEARCH. The original
oracle/case bytes and first two FAIL remain in the package; reviewed tests assert the
specific contract-correct mismatch rather than skipping/waiving arbitrary failures.

This finding does not establish that all possible inputs, platforms or scientific
questions are correct. Existing regression outcomes are reported separately.

## C. Candidate product gaps — functional conformance does not prove usefulness

### PG-01 — Exact traceability requires manual joins

Observed in CASE-01/05 and applicable to all: bridge.evidence_context.claim_review
contains exact claim refs, uncertainty and links, but no claim statement; source_review
contains source refs/observations/limits, but not source title/locator. Those originals
remain in dossier.input_snapshot, not lost or changed. An editor must join the views.

Structural result: exact refs/bytes preserved — PASS. Human Clarity/Traceability:
NOT_ASSESSED. Preliminary hypothesis: reference-heavy raw JSON slows human inspection.
Proposed improvement: a private read-only view that joins original labels/statements
with exact refs; keep qualifiers/provenance and avoid public PII/hash disclosure.
No rewriting records, semantic-equivalence proof or new source credibility claim.

### PG-02 — Action lists are linked but not an editorial work queue

Observed in all cases: generic bilingual actions refer to exact refs; case-specific
supplied actions remain nested in recorded_recommendation.payload.next_actions and
critic.editor_action. There is no structured owner/deadline/resolution field or user
prioritization evidence. Input order and declared severity survive, not human triage.

Structural result: required actions/risks not dropped — PASS. Actionability:
NOT_ASSESSED. Preliminary hypothesis: the editor needs one clearly labelled view of
recorded topic-specific tasks and mechanical gaps. Do not invent new priority scores,
closure states or automatic human decisions. Any future workflow fields need their
own approved contract; this task does not introduce them.

### PG-03 — Recorded creative options are available, not selected or evaluated

CASE-01 has two supplied angles; CASE-03 has a supplied illustrative visual need;
CASE-04/05 preserve alternative interpretations and supplied hooks. CASE-02 intentionally
has no angle/hook generation. Data survives under recorded_recommendation, rather than
being surfaced as a new generated recommendation. Generic SI scene drafts in mode B
are not demonstrated scripts for the research topics.

Structural availability/preservation — PASS. Creative usefulness — NOT_ASSESSED.
Proposed improvement: expose only supplied creative options with their original
basis/limitations and no claimed rights/production readiness. No automatic generation
or ranking is authorized by this observation.

### PG-04 — Multiple state axes need explicit human-facing context

Observed: intake NEEDS_INPUT, evidence NEEDS_REVIEW/NEEDS_INPUT and SI
ELIGIBLE_FOR_CREATIVE/BLOCKED/NEEDS_RESEARCH coexist in separate fields. Scope remains
unverified. OR-01 shows an error by this automated validation author in distinguishing
UNKNOWN-rating research from missing-input classification; it is not a human study.

Structural separation — PASS. Human Clarity/Risk visibility — NOT_ASSESSED.
Preliminary hypothesis: show the three axes with their scope and source, especially
“supplied SI view, not proven evaluation of this research”. Do not change enums,
priority or eligibility to make the display appear consistent.

## D. Future enhancements / untested capabilities — not current defects

- Independent human editorial sessions: perform Q1–Q5 tasks, observe navigation,
  record the five qualitative traits with rater provenance and disagreements. No
  user ratings or “expert acceptance” are fabricated in this validation.
- More realistic manually aligned SI views with reviewed correspondence. Current
  B frames are valid generic synthetic fixtures, intentionally not converted research.
  Matching metadata/hash is not semantic proof; no automatic builder/ERef adapter.
- Actual evidence quality/clinical/historical/scientific review using lawfully obtained
  materials and independent qualified people. This synthetic validation cannot assess
  scientific accuracy, licensing, audience demand or calibration.
- Future typed critique disposition, source acquisition/provider or durable workflow
  only after separate owner contracts. No new network, LLM, storage, corpus or authority.

## Recommended next product priority — PROPOSAL / NOT APPROVED

A bounded **private read-only editorial view + independent editor pilot** is the next
candidate priority: join original topic/claim/source text to refs, expose existing
risks/actions/creative proposals, clearly separate research and supplied SI scope.
Use these five frozen cases as a baseline; measure human observations without a total
utility score or topic ranking. Owner supplies exact scope/allowlist/acceptance before
any implementation. Start with human validation of the proposed view; do not add a new
scoring engine, automatic SI builder or scientific/production gate to solve UI friction.

This recommendation is a validation conclusion, not authorization for the next stage.
**STOP FOR INDEPENDENT REVIEW.**
