# SI-PRODUCT-02.3.4 — Validation Report

## OR-01 — Separate post-run oracle review (original oracle is preserved)

Дата: 2026-11-16. This section was written after the first targeted execution and
before the reviewed rerun. It is appended to the audit trail, not substituted into
the pre-execution oracle or static scenario JSON.

First targeted run: 14 test methods, exit 1, failures=2, errors=0. Both mismatches:
CASE-04 / B / ru and CASE-04 / B / uk. Original expected SI eligibility NEEDS_INPUT;
actual NEEDS_RESEARCH, aggregate UNKNOWN. Other original expectations were not revised.

The original oracle and cases bytes remain frozen:

- ORACLES SHA-256: `a9ff1e7771f3ec80c079b6c3df5bcb6b6ccfe4126de695339d62ba5d9bbd80d9`.
- CASES SHA-256: `ff7615f0bd5c0ba85843f4bdd0d4d94bba612065d58c3d8ec3d7dbaca9768f94`.

Authoritative basis, read after the mismatch to classify it:

1. [Approved R1 §3.2](STORY_INTELLIGENCE_V1_R1_CONTRACT_CLARIFICATIONS.md), item 4:
   mandatory UNKNOWN ratings → NEEDS_RESEARCH, aggregate UNKNOWN. NEEDS_INPUT is
   for missing постановка/audience/channel/required current data, not this fixture.
2. [Findings N04](STORY_INTELLIGENCE_SI_E02_2_1A_TEST_ORACLES.md): one rating.value
   UNKNOWN → NEEDS_RESEARCH/EVIDENCE_NEEDED, no zero-fill/renormalization.
   [Owner freeze](STORY_INTELLIGENCE_SI_E02_2_1B_OWNER_APPROVAL_2026_11_10.md) §1
   approves N01–N04/T01–T38 in that exact source revision.
3. Runtime `_scoring_findings` in unchanged evaluate_v1.py emits NEEDS_RESEARCH /
   EVIDENCE_NEEDED at `$.ratings[0].value`, consistent with those contracts.

Classification: **validation-oracle error**, not a contract or implementation defect.
Reviewed expectation for this one field in the two CASE-04/B paths: NEEDS_RESEARCH.
Research readiness remains NEEDS_INPUT; these are separate axes. The source fixtures,
original expected NEEDS_INPUT, production code and existing contracts stay unchanged.

The reviewed test explicitly asserts that the original expected value is NEEDS_INPUT,
that actual differs, that the approved expected value is NEEDS_RESEARCH, and that the
UNKNOWN aggregate/required diagnostic are retained. It does not skip/expectedFailure
or waive arbitrary mismatches. A separate regression preserves the original mismatch.

**Original-oracle verdict remains FAIL for the two CASE-04/B paths.** A reviewed
conformance PASS must not be presented as 20/20 initial-oracle agreement. First-run
log, freeze metadata and reviewed test results are retained in the package.


## Final validation result

**READY_FOR_INDEPENDENT_REVIEW — SYNTHETIC_STRUCTURAL_VALIDATION_ONLY.**
Not product acceptance, human usability validation, scientific verification or production readiness.

- Repository: `olegale-ctrl/Story-Studio-RU-UA-WORK`.
- Branch: `test/si-product-02-3-4-end-to-end-validation`.
- Exact base / parent: `4dd1805ed19d1e76ef525f2adb0e746089a70465`.
- Owner task status: OWNER_AUTHORIZED_FOR_VALIDATION, not feature development.
- Result commit: commit containing this report; full SHA in HANDOFF.json and final
  handoff, without circular self-reference in the committed bytes.
- Base exists; clean source worktree verified; new branch created at exact SHA.
- Existing interfaces/contracts were inspected; no production source or policy changed.

### Coverage and qualification

Five distinct synthetic topics, modes A/B, API locales ru/uk: **20 actual paths**.
Full stage artifacts are under `paths/CASE-xx-mode-locale.json` in the review archive.
Each contains exact input, intake status/dossier, evidence status/report, bridge
status/report, genuine SI result and genuine Preview status/artifacts when applicable.
All outputs are actual returned values, not substituted success values.

A has no SI frame/result/Preview. B supplies a prebuilt valid generic SI fixture,
independent of research; it is intentionally **not** a research-to-SI conversion or
proof of topic correspondence. Both modes preserve separate research/SI axes and
semantic_coverage_verified=false. All paths production NOT_ASSESSED, no grants.

**Original oracle agreement: 18 PASS / 2 FAIL.** The two CASE-04/B failures remain
visible above and in the first-run log. Reviewed contract conformance: **20 PASS**
after the separately documented OR-01 correction. Do not report 20/20 initial agreement.
No changes to the original oracle document or case JSON after first execution.

No independent human editor participated. For **each CASE**, Clarity, Traceability,
Risk visibility, Actionability and Creative usefulness are **NOT_ASSESSED**.
Machine-checkable data preservation can PASS; it is not human usefulness PASS.
No overall product score, topic rank, authentic human labels or science-quality claim.

### Actual path results (intake/evidence/bridge structural status)

Every path: valid dossier produced, evidence status OK, bridge status OK. Intake
NEEDS_INPUT is nonfatal incompleteness (including UNKNOWN manual ratings/no frame),
not a rejected JSON snapshot. SI columns describe only the supplied SI view.

| CASE | Mode / locale | Intake | Evidence readiness | SI eligibility/context | Original oracle | Reviewed contract |
|---|---|---|---|---|---|---|
| CASE-01 | A / ru | NEEDS_INPUT | NEEDS_INPUT | NO_FRAME | PASS | PASS |
| CASE-01 | A / uk | NEEDS_INPUT | NEEDS_INPUT | NO_FRAME | PASS | PASS |
| CASE-01 | B / ru | NEEDS_INPUT | NEEDS_INPUT | ELIGIBLE_FOR_CREATIVE | PASS | PASS |
| CASE-01 | B / uk | NEEDS_INPUT | NEEDS_INPUT | ELIGIBLE_FOR_CREATIVE | PASS | PASS |
| CASE-02 | A / ru | NEEDS_INPUT | NEEDS_INPUT | NO_FRAME | PASS | PASS |
| CASE-02 | A / uk | NEEDS_INPUT | NEEDS_INPUT | NO_FRAME | PASS | PASS |
| CASE-02 | B / ru | NEEDS_INPUT | NEEDS_INPUT | BLOCKED | PASS | PASS |
| CASE-02 | B / uk | NEEDS_INPUT | NEEDS_INPUT | BLOCKED | PASS | PASS |
| CASE-03 | A / ru | NEEDS_INPUT | NEEDS_REVIEW | NO_FRAME | PASS | PASS |
| CASE-03 | A / uk | NEEDS_INPUT | NEEDS_REVIEW | NO_FRAME | PASS | PASS |
| CASE-03 | B / ru | NEEDS_INPUT | NEEDS_REVIEW | ELIGIBLE_FOR_CREATIVE | PASS | PASS |
| CASE-03 | B / uk | NEEDS_INPUT | NEEDS_REVIEW | ELIGIBLE_FOR_CREATIVE | PASS | PASS |
| CASE-04 | A / ru | NEEDS_INPUT | NEEDS_INPUT | NO_FRAME | PASS | PASS |
| CASE-04 | A / uk | NEEDS_INPUT | NEEDS_INPUT | NO_FRAME | PASS | PASS |
| CASE-04 | B / ru | NEEDS_INPUT | NEEDS_INPUT | NEEDS_RESEARCH | FAIL | PASS |
| CASE-04 | B / uk | NEEDS_INPUT | NEEDS_INPUT | NEEDS_RESEARCH | FAIL | PASS |
| CASE-05 | A / ru | NEEDS_INPUT | NEEDS_REVIEW | NO_FRAME | PASS | PASS |
| CASE-05 | A / uk | NEEDS_INPUT | NEEDS_REVIEW | NO_FRAME | PASS | PASS |
| CASE-05 | B / ru | NEEDS_INPUT | NEEDS_REVIEW | BLOCKED | PASS | PASS |
| CASE-05 | B / uk | NEEDS_INPUT | NEEDS_REVIEW | BLOCKED | PASS | PASS |

### Qualitative rubric for each CASE — no independent human rater

| CASE | Clarity | Traceability | Risk visibility | Actionability | Creative usefulness |
|---|---|---|---|---|---|
| CASE-01 | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED |
| CASE-02 | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED |
| CASE-03 | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED |
| CASE-04 | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED |
| CASE-05 | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED | NOT_ASSESSED |

The following Q1–Q5 interpretations are preliminary AI output inspections, not
confirmed editorial/user judgments. They describe available recorded data and gaps;
none is a final develop/reject recommendation for a real topic.

## CASE-01 — Почему исчезли древние цивилизации?

Inputs: five-topic static JSON entry `CASE-01`, all synthetic. Original independent oracle: ORACLES §CASE-01. Expected research NEEDS_INPUT; actual NEEDS_INPUT. Expected B SI ELIGIBLE_FOR_CREATIVE; actual ELIGIBLE_FOR_CREATIVE.

Structural original A/B verdicts: PASS / PASS; reviewed contract conformance: PASS / PASS, both ru/uk. Full actual snapshots: `paths/CASE-01-A-ru.json`, `paths/CASE-01-B-ru.json` and corresponding uk files. All structural fields except OR-01 match original expectations.

**Q1. Стоит ли развивать тему?** Нет автоматического ответа «развивать». Input-recorded prospect RESEARCH_MORE остаётся заявлением fixture; generic SI ELIGIBLE/1000 не доказывает оценку H1/H2.

**Q2. Почему?** Два exact claim refs, competing H1/H2 и HIGH critique сохранены. У H2 supporting пуст, EVIDENCE_MISSING видим; uncertainty HIGH, SOURCE_REVIEW_MISSING и нужда сузить период/регион остаются.

**Q3. Что может пойти не так?** Риск универсальной причины/мнимого консенсуса не снят. Научные данные искусственные, applicability ограничена, production/rights NOT_ASSESSED; истинность не установлена.

**Q4. Какие варианты подачи возможны?** Два supplied alternative_angles и intellectual/emotional hooks доступны под recorded_recommendation. Они не созданы системой и не выбраны как лучший угол.

**Q5. Что необходимо сделать дальше?** В исходных next_actions: выбрать период/регион и получить независимые основания H2. В root actions есть exact refs и human review, но нет единого удобного плана с ответственными/приоритетами.

Product rubric: all five traits NOT_ASSESSED; no human rater. Preliminary improvement suggestions are catalogued separately in PRODUCT_GAPS, not applied to production.

## CASE-02 — Можно ли доверять ИИ в медицинских советах?

Inputs: five-topic static JSON entry `CASE-02`, all synthetic. Original independent oracle: ORACLES §CASE-02. Expected research NEEDS_INPUT; actual NEEDS_INPUT. Expected B SI BLOCKED; actual BLOCKED.

Structural original A/B verdicts: PASS / PASS; reviewed contract conformance: PASS / PASS, both ru/uk. Full actual snapshots: `paths/CASE-02-A-ru.json`, `paths/CASE-02-B-ru.json` and corresponding uk files. All structural fields except OR-01 match original expectations.

**Q1. Стоит ли развивать тему?** Модуль не даёт медицинской рекомендации или права разрабатывать рискованный контент. Generic SI BLOCKED при aggregate 1000; source research NEEDS_INPUT и CRITICAL остаются видимыми.

**Q2. Почему?** Central support отсутствует; material not retrieved, fragment/pointer UNKNOWN и CRITICAL critique сохранены. SI blocker происходит из отдельно supplied central unreviewed claim, не clinical validation.

**Q3. Что может пойти не так?** Опасно принять toy score за надёжность ИИ/клинический вывод. Синтетические inputs не содержат реальной медицинской рекомендации/исследования; human expertise/identity не удостоверены.

**Q4. Какие варианты подачи возможны?** В research recommendation нет новых angles/hooks; pipeline ничего не придумывает. Generic SI scene drafts не медицинский сценарий для этого исследования.

**Q5. Что необходимо сделать дальше?** Предоставленные действия: не использовать кейс как медицинский совет, собрать/передать точные материалы профильному человеку. Root actions сохраняют capture/review/critical gaps; их практическая полезность не проверена человеком.

Product rubric: all five traits NOT_ASSESSED; no human rater. Preliminary improvement suggestions are catalogued separately in PRODUCT_GAPS, not applied to production.

## CASE-03 — Почему самолёты не падают при турбулентности?

Inputs: five-topic static JSON entry `CASE-03`, all synthetic. Original independent oracle: ORACLES §CASE-03. Expected research NEEDS_REVIEW; actual NEEDS_REVIEW. Expected B SI ELIGIBLE_FOR_CREATIVE; actual ELIGIBLE_FOR_CREATIVE.

Structural original A/B verdicts: PASS / PASS; reviewed contract conformance: PASS / PASS, both ru/uk. Full actual snapshots: `paths/CASE-03-A-ru.json`, `paths/CASE-03-B-ru.json` and corresponding uk files. All structural fields except OR-01 match original expectations.

**Q1. Стоит ли развивать тему?** Возможность редакционного рассмотрения не равна доказанной безопасности/перспективности. NEEDS_REVIEW research отдельно от generic SI ELIGIBLE/1000; окончательное решение отсутствует.

**Q2. Почему?** Записаны teaching analogy, support links, limits и HIGH critique абсолютной формулировки. HASH_REPORTED не повышен до verified bytes; CLAIM_REVIEW_MISSING и дальнейшее исследование сохранены.

**Q3. Что может пойти не так?** Можно чрезмерно обобщить аналогию или принять название вопроса за проверенный факт. Ни факты о реальном полёте, ни права на visuals/производство не подтверждены.

**Q4. Какие варианты подачи возможны?** Supplied angle, hook и visual_needs сохранены exact в recorded recommendation. Это направление пояснения и помеченная учебная схема, не созданный asset или готовое видео.

**Q5. Что необходимо сделать дальше?** Исходные действия требуют уточнить заголовок и рассмотреть применимость/права. Generic SI score не выведен из narrative/visual appeal: preliminary ratings UNKNOWN, supplied SI ratings остаются отдельными.

Product rubric: all five traits NOT_ASSESSED; no human rater. Preliminary improvement suggestions are catalogued separately in PRODUCT_GAPS, not applied to production.

## CASE-04 — Загадочные сигналы из космоса

Inputs: five-topic static JSON entry `CASE-04`, all synthetic. Original independent oracle: ORACLES §CASE-04. Expected research NEEDS_INPUT; actual NEEDS_INPUT. Expected B SI NEEDS_INPUT; actual NEEDS_RESEARCH.

Structural original A/B verdicts: PASS / FAIL; reviewed contract conformance: PASS / PASS, both ru/uk. Full actual snapshots: `paths/CASE-04-A-ru.json`, `paths/CASE-04-B-ru.json` and corresponding uk files. All structural fields except OR-01 match original expectations.

**Q1. Стоит ли развивать тему?** Нет результата о целесообразности разработки реальных cosmic claims. Research NEEDS_INPUT; actual generic SI NEEDS_RESEARCH/UNKNOWN. Original oracle ошибочно ожидал NEEDS_INPUT у SI; OR-01 отдельно объясняет различие.

**Q2. Почему?** Два source labels имеют общий reported material hash, source2 upstream_ref→source1, factual/interpretation tags раздельны. MATERIAL_REUSED, no retrieval, uncertainty и model-independence gap видимы.

**Q3. Что может пойти не так?** Нельзя назвать происхождение сигнала доказанным, перепечатки независимыми или model critique human review. Данные только synthetic; scientific/rights/production authority отсутствует.

**Q4. Какие варианты подачи возможны?** Supplied nonsensational angle/hook сохранены, не generated extraterrestrial conclusion. Hypothesis не переименована observation; конкретный creative выбор остаётся человеку.

**Q5. Что необходимо сделать дальше?** Исходные действия: получить primary material вручную, проверить зависимости и отдельную человеческую критику. Root generic actions привязаны к refs; human interpretation требует читать также dossier originals.

Product rubric: all five traits NOT_ASSESSED; no human rater. Preliminary improvement suggestions are catalogued separately in PRODUCT_GAPS, not applied to production.

## CASE-05 — Почему некоторые популярные исторические факты оказались мифами?

Inputs: five-topic static JSON entry `CASE-05`, all synthetic. Original independent oracle: ORACLES §CASE-05. Expected research NEEDS_REVIEW; actual NEEDS_REVIEW. Expected B SI BLOCKED; actual BLOCKED.

Structural original A/B verdicts: PASS / PASS; reviewed contract conformance: PASS / PASS, both ru/uk. Full actual snapshots: `paths/CASE-05-A-ru.json`, `paths/CASE-05-B-ru.json` and corresponding uk files. All structural fields except OR-01 match original expectations.

**Q1. Стоит ли развивать тему?** Нет автоматического вывода обо всей истории или конкретном реальном мифе. Research NEEDS_REVIEW; generic SI BLOCKED/1000 связан с отдельным supplied contrary evidence, не debunking реального события.

**Q2. Почему?** Supporting и contradicting не устранены голосованием. Source2 имеет exact upstream source1; factual и interpretation tags и HIGH self-review с CRITIQUE_INDEPENDENCE_UNKNOWN сохранены.

**Q3. Что может пойти не так?** Риск неподтверждённого обобщения и зависимых свидетельств остаётся. Source2 с другим hash не становится доказанно независимым; ни подлинность reviewers, ни фактология не удостоверены.

**Q4. Какие варианты подачи возможны?** Supplied interpretive angle и intellectual hook доступны. Pipeline не выбирает исторический пример и не сочиняет факт/цитату/новую рекомендацию.

**Q5. Что необходимо сделать дальше?** Предоставленные действия: выбрать один пример, проследить оригинал и разрешить contrary testimony человеком. Exact refs помогают машинному аудиту, но человеку нужны cross-joins к текстам и удобное отображение задач.

Product rubric: all five traits NOT_ASSESSED; no human rater. Preliminary improvement suggestions are catalogued separately in PRODUCT_GAPS, not applied to production.

## Categories, constraints and next priority

See [PRODUCT_GAPS](SI_PRODUCT_02_3_4_PRODUCT_GAPS.md):

- A Contract defects: no confirmed violation in exercised paths; no new approval/eligibility rules.
- B Implementation defects: no confirmed production defect; no runtime edits.
- C Candidate product gaps: manual joins for labels/text, fragmented topic-specific actions,
  buried creative options and multiple state axes. Human impact is a preliminary hypothesis.
- D Future enhancements/untested: independent editor sessions, realistic manually aligned
  SI views and lawful real scientific/source review. No automatic builder/provider/storage.

OR-01 is separate methodology history, not A/B and not a new product policy. Structural
success does not establish product readiness, independent human acceptance, rights,
scientific truth, actual medical/aviation/history quality or audience demand.

Proposed next priority: private read-only topic/claim/source/action view plus an
independent human editor pilot, under a separate owner-approved task. No next-stage
code, new scoring engine, corpus, LLM/provider/network integration or production.

## Final checks and exact scope

Linux/Python 3.12.14, project `.venv`; no new dependencies.

| Check | Tests | Exit |
|---|---:|---:|
| e2e | 15 | 0 |
| research | 49 | 0 |
| bridge | 29 | 0 |
| preview | 16 | 0 |
| full | 1249 | 0 |
| compileall | — | 0 |
| diff-check | — | 0 |

Commands (`python` is project `.venv/bin/python`):

```text
python -m unittest tests.test_si_product_02_3_4_e2e -v
python -m unittest tests.test_research_intake tests.test_evidence_critique -v
python -m unittest tests.test_topic_scoring_bridge -v
python -m unittest tests.test_editor_preview -v
python -m unittest discover -s tests -v
python -m compileall -q tests/test_si_product_02_3_4_e2e.py
git diff --check
```

Final completed unit suites: failures/errors/skips/expectedFailure=0. First targeted
run was exit 1 / 14 tests / two failing subtests, preserved verbatim; no PASS assigned.
Reviewed tests explicitly retain/assert the known original mismatch under OR-01.
There are 20 parameterized main paths plus negative/reproducibility variants in the
15 test methods; overlapping tests are not counted as extra distinct topics/users.
20 full stage snapshots were separately captured through actual APIs, all no-forbidden-
effect mocks asserted not called. No positive results were mocked. Input objects and
originals/Unicode are not mutated or auto-translated. Actual test command exits and
SHA-256 of the tested test/oracle/cases files are in TEST_RESULTS.json/HANDOFF.
Legacy full tests include approved D1 synthetic media regression; their temporary
media are not research production and are excluded from the archive.

Exactly six allowed paths:

1. [tests/test_si_product_02_3_4_e2e.py](../../tests/test_si_product_02_3_4_e2e.py).
2. [examples/si_product_02_3_4_cases.json](../../examples/si_product_02_3_4_cases.json).
3. [ORACLES](SI_PRODUCT_02_3_4_VALIDATION_ORACLES.md), immutable original.
4. This VALIDATION_REPORT, preserving initial separate OR-01 note as a byte-exact prefix.
5. [PRODUCT_GAPS](SI_PRODUCT_02_3_4_PRODUCT_GAPS.md).
6. [WORKLOG](../../project-log/WORKLOG.md), append only.

Existing production source, schemas/contracts, existing tests/goldens, nine criteria/
weights, RD-01–04/HIST-01, dependencies and CI are unchanged. No contracts, correspondence
proof or production authority were approved by this validation. PUBLISH_REVISION remains
DISABLED; partial COMMIT reconstruction OFF; Windows S3.2b unchanged/BLOCKED.

Local validation commit only; full SHA/parent/statistics in HANDOFF.json. Review ZIP and
checksum only on existing `artifacts/si-product-02-3-0-research-contract` branch,
`review-downloads/si-product-02-3-4.zip` / `.sha256`. No real private research data,
keys/models/media, implementation-branch push, PR, merge, tag, release or main change.
No future implementation was started. **STOP — WAIT FOR INDEPENDENT REVIEW.**
