"""Frozen pre-run oracles, five synthetic topics × A/B × ru/uk; no product edits."""
from contextlib import ExitStack
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import json
import unittest
from unittest.mock import patch

from scripts import research_intake, evidence_critique, topic_scoring_bridge, editor_preview
from story_intelligence.evaluate_v1 import evaluate_si
from tests.test_story_intelligence_decision_projection_v1 import stale_args

ROOT=Path(__file__).resolve().parents[1]
ORACLE_SHA='a9ff1e7771f3ec80c079b6c3df5bcb6b6ccfe4126de695339d62ba5d9bbd80d9'
CASES_SHA='ff7615f0bd5c0ba85843f4bdd0d4d94bba612065d58c3d8ec3d7dbaca9768f94'
FORBIDDEN=('subprocess.run','subprocess.Popen','socket.socket','socket.create_connection',
    'urllib.request.urlopen','wave.open','scripts.first_video.build','scripts.first_video.render_mp4',
    'core.mp4_render.render_mp4','integrations.silero_local.SileroLocalProvider.synthesize')


def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def reference(r):return dict(research_type=r['schema_version'],id=r['id'],revision=r['revision'],content_sha256=sha256(canonical(r)).hexdigest())


def cases():
    assert sha256((ROOT/'docs/tasks/SI_PRODUCT_02_3_4_VALIDATION_ORACLES.md').read_bytes()).hexdigest()==ORACLE_SHA
    p=ROOT/'examples/si_product_02_3_4_cases.json';assert sha256(p.read_bytes()).hexdigest()==CASES_SHA
    return json.loads(p.read_text())['cases']


def run_path(case,mode,locale):
    """Actual public API calls; returned artifacts are observations, not oracles."""
    research=deepcopy(case['research_input'])
    frame=deepcopy(case['supplied_si_frame']) if mode=='B' else None
    before=deepcopy((research,frame))
    intake_status,intake_files=research_intake.intake(research,locale)
    d=intake_files.get('dossier.json')
    evidence_status,e=evidence_critique.analyze(d,locale)
    bridge_status,b=topic_scoring_bridge.integrate(d,e,existing_preview_input=frame,locale=locale)
    si=evaluate_si(**deepcopy(frame['evaluation_inputs'])) if frame is not None else None
    preview_status,preview_files=editor_preview.preview(deepcopy(frame)) if frame is not None else (None,{})
    assert (research,frame)==before
    return dict(case_id=case['case_id'],mode=mode,locale=locale,research_input=research,
        supplied_si_frame=frame,intake=dict(status=intake_status,dossier=d),
        evidence=dict(status=evidence_status,report=e),bridge=dict(status=bridge_status,report=b),
        si_result=si,preview=dict(status=preview_status,artifacts=preview_files))


def assert_path(t,case,out):
    oracle=case['oracle'];d=out['intake']['dossier'];e=out['evidence']['report'];b=out['bridge']['report']
    t.assertEqual(out['intake']['status']['state'],'NEEDS_INPUT')
    t.assertIsNotNone(d)
    t.assertEqual(out['evidence']['status'],dict(state='OK',diagnostics=[]))
    t.assertEqual(out['bridge']['status'],dict(state='OK',diagnostics=[]))
    t.assertEqual(e['research_readiness'],oracle['research_readiness'])
    t.assertTrue(set(oracle['required_gap_codes'])<=set(g['code'] for g in e['evidence_gaps']))
    t.assertEqual(b['evidence_context']['evidence_gaps'],e['evidence_gaps'])
    t.assertEqual(b['evidence_context']['research_readiness'],oracle['research_readiness'])
    t.assertEqual(b['research_identity']['dossier_sha256'],sha256(canonical(d)).hexdigest())
    t.assertEqual(b['research_identity']['research_snapshot_sha256'],sha256(canonical(case['research_input'])).hexdigest())
    t.assertEqual(b['research_identity']['evidence_report_sha256'],sha256(canonical(e)).hexdigest())
    t.assertFalse(b['research_identity']['semantic_coverage_verified'])
    t.assertEqual(d['production_state'],'NOT_ASSESSED');t.assertEqual(b['production_state'],'NOT_ASSESSED')
    t.assertFalse(b['editorial_decision_support']['recommendation_generated'])
    t.assertEqual(b['editorial_decision_support']['recorded_recommendation'],case['research_input']['recommendation'])
    t.assertEqual(b['editorial_decision_support']['research_preliminary_assessments'],case['research_input']['preliminary_assessments'])
    t.assertEqual(d['input_snapshot'],case['research_input'])
    expected_claims=[reference(r) for r in case['research_input']['claims']['value']]
    t.assertEqual([x['claim_ref'] for x in e['claim_review']],expected_claims)
    if out['mode']=='A':
        t.assertIsNone(out['si_result']);t.assertIsNone(out['preview']['status'])
        t.assertEqual(b['si_scoring_context']['state'],'NO_FRAME')
        t.assertEqual(b['research_identity']['correspondence_state'],'NO_FRAME')
        t.assertIsNone(b['si_scoring_context']['evaluation_result'])
        t.assertIsNone(b['preview']['status']);t.assertEqual(b['preview']['artifacts'],{})
    else:
        si=out['si_result'];t.assertEqual(si['status'],'OK')
        if case['case_id']=='CASE-04':
            # OR-01: original oracle remains FAIL; reviewed contract conformance is separate.
            t.assertEqual(oracle['si_eligibility'],'NEEDS_INPUT')
            t.assertNotEqual(si['eligibility']['state'],oracle['si_eligibility'])
            t.assertEqual(si['eligibility']['state'],'NEEDS_RESEARCH')
            t.assertTrue(any(x['code']=='EVIDENCE_NEEDED' and x['field_path']=='$.ratings[0].value' for x in si['diagnostics']))
        else:
            t.assertEqual(si['eligibility']['state'],oracle['si_eligibility'])
        t.assertEqual(si['aggregate_tenths']['state'],oracle['si_aggregate_state'])
        if oracle['si_aggregate_value'] is not None:t.assertEqual(si['aggregate_tenths']['value'],oracle['si_aggregate_value'])
        t.assertEqual(b['si_scoring_context']['evaluation_result'],si)
        t.assertEqual(b['si_scoring_context']['supplied_si_ratings'],case['supplied_si_frame']['evaluation_inputs']['ratings'])
        t.assertEqual(b['preview'],out['preview'])
        t.assertEqual(out['preview']['artifacts']['evaluation.json'],si)
        t.assertEqual(b['research_identity']['correspondence_state'],'UNVERIFIED_SCOPE')
        t.assertFalse(out['preview']['status']['production_readiness']['permissions_granted'])
        t.assertFalse(any(n.endswith(('.mp4','.wav')) for n in out['preview']['artifacts']))
    t.assertEqual(set(oracle['subjective_traits'].values()),{'NOT_ASSESSED'})


class ProductValidation(unittest.TestCase):
    def setUp(self):
        self.stack=ExitStack();self.denied=[self.stack.enter_context(patch(n,side_effect=AssertionError('forbidden effect'))) for n in FORBIDDEN]
        self.addCleanup(self.stack.close)

    def tearDown(self):
        for m in self.denied:m.assert_not_called()

    def test_01_oracles_frozen_before_execution(self):
        data=cases();self.assertEqual(len(data),5);self.assertEqual(len({x['topic'] for x in data}),5)
        self.assertTrue(all(x['synthetic_only'] for x in data))
        self.assertEqual([x['case_id'] for x in data],['CASE-01','CASE-02','CASE-03','CASE-04','CASE-05'])

    def test_02_twenty_frozen_oracle_paths(self):
        for case in cases():
            for mode in ('A','B'):
                for locale in ('ru','uk'):
                    with self.subTest(case=case['case_id'],mode=mode,locale=locale):assert_path(self,case,run_path(case,mode,locale))

    def test_03_case01_competing_hypotheses_and_recorded_angles(self):
        c=cases()[0];out=run_path(c,'A','ru');e=out['evidence']['report'];b=out['bridge']['report']
        self.assertEqual(len(e['claim_review']),2)
        self.assertTrue(e['claim_review'][0]['supporting']);self.assertEqual(e['claim_review'][1]['supporting'],[])
        rec=b['editorial_decision_support']['recorded_recommendation']['value']['payload']
        self.assertEqual(len(rec['alternative_angles']),2);self.assertTrue(rec['intellectual_hooks'])
        self.assertEqual(rec,c['research_input']['recommendation']['value']['payload'])

    def test_04_case02_medical_boundary_and_high_score_blocker(self):
        out=run_path(cases()[1],'B','ru');b=out['bridge']['report']
        self.assertEqual(b['evidence_context']['critique_review'][0]['severity'],'CRITICAL')
        self.assertEqual(out['si_result']['aggregate_tenths']['value'],1000)
        self.assertEqual(out['si_result']['eligibility']['state'],'BLOCKED')
        self.assertFalse(b['editorial_decision_support']['recommendation_generated'])

    def test_05_case03_visuals_and_wording_not_automatic_score(self):
        c=cases()[2];out=run_path(c,'B','uk');r=out['bridge']['report']['editorial_decision_support']['recorded_recommendation']['value']['payload']
        self.assertEqual(r['visual_needs'],c['research_input']['recommendation']['value']['payload']['visual_needs'])
        self.assertTrue(r['visual_needs']);self.assertTrue(r['production_limits']['value'])
        self.assertTrue(all(a['proposed_value']['state']=='UNKNOWN' for a in c['research_input']['preliminary_assessments']['value']))
        self.assertEqual(out['si_result']['aggregate_tenths']['value'],1000)

    def test_06_case04_reuse_observation_hypothesis_model_critic(self):
        out=run_path(cases()[3],'B','ru');e=out['evidence']['report']
        self.assertEqual(len(e['source_review']),2);self.assertEqual(len(e['reused_materials'][0]['source_refs']),2)
        self.assertEqual([c['claim_kind']['value'] for c in e['claim_review']],['factual','interpretation'])
        self.assertTrue(e['source_review'][1]['provenance']['upstream_refs'])
        self.assertEqual(e['critique_review'][0]['provenance']['kind'],'MODEL_PROPOSED')
        self.assertIn('CRITIQUE_INDEPENDENCE_UNKNOWN',[g['code'] for g in e['evidence_gaps']])
        self.assertEqual(out['si_result']['aggregate_tenths']['state'],'UNKNOWN')

    def test_07_case05_dependency_contradiction_self_review(self):
        c=cases()[4];out=run_path(c,'A','ru');e=out['evidence']['report']
        self.assertEqual(e['source_review'][1]['provenance']['upstream_refs'],[reference(c['research_input']['sources']['value'][0])])
        self.assertTrue(e['claim_review'][0]['contradicting'])
        self.assertEqual(e['claim_review'][1]['claim_kind']['value'],'interpretation')
        self.assertIn('CRITIQUE_INDEPENDENCE_UNKNOWN',[g['code'] for g in e['evidence_gaps']])

    def test_08_tampered_dossier_evidence_sha_rref_and_extra_flags(self):
        base=run_path(cases()[0],'A','ru');original=(base['intake']['dossier'],base['evidence']['report'])
        for mode in ('snapshot','sha','evidence','rref','verified'):
            with self.subTest(mode=mode):
                d,e=deepcopy(original)
                if mode=='snapshot':d['input_snapshot']['editor_notes'].append('tamper')
                elif mode=='sha':d['intake_sha256']='0'*64
                elif mode=='evidence':e['research_readiness']='READY_FOR_EDITOR_REVIEW'
                elif mode=='rref':e['claim_review'][0]['claim_ref']['content_sha256']='0'*64
                else:d['already_verified']=True
                before=deepcopy((d,e));s,r=topic_scoring_bridge.integrate(d,e)
                self.assertEqual((d,e),before);self.assertEqual(s['state'],'INVALID');self.assertIsNone(r)

    def test_09_mismatched_embedded_frame(self):
        c=cases()[2];data=deepcopy(c['research_input']);data['existing_preview_input']=dict(state='KNOWN',value=deepcopy(c['supplied_si_frame']))
        _,files=research_intake.intake(data);d=files['dossier.json'];_,e=evidence_critique.analyze(d)
        other=deepcopy(c['supplied_si_frame']);other['topic']['text']='Different supplied frame metadata'
        s,r=topic_scoring_bridge.integrate(d,e,existing_preview_input=other)
        self.assertEqual(s['state'],'INVALID');self.assertIsNone(r)

    def test_10_stale_is_intact_and_invalid_graph_rejected(self):
        base=run_path(cases()[2],'A','ru');d,e=base['intake']['dossier'],base['evidence']['report']
        frame=deepcopy(cases()[2]['supplied_si_frame']);frame['evaluation_inputs']=stale_args()
        s,r=topic_scoring_bridge.integrate(d,e,existing_preview_input=frame)
        self.assertEqual(s['state'],'OK');self.assertEqual(r['si_scoring_context']['state'],'STALE')
        self.assertIsNone(r['si_scoring_context']['evaluation_result']['eligibility'])
        self.assertIsNone(r['si_scoring_context']['evaluation_result']['aggregate_tenths'])
        frame['evaluation_inputs']['records']=[];s,r=topic_scoring_bridge.integrate(d,e,existing_preview_input=frame)
        self.assertEqual(s['state'],'INVALID');self.assertIsNone(r)

    def test_11_missing_critique_is_visible(self):
        data=deepcopy(cases()[2]['research_input']);data['critiques']=dict(state='KNOWN',value=[])
        data['recommendation']=dict(state='UNKNOWN',reason='Synthetic negative scenario; no recommendation.')
        s,files=research_intake.intake(data);self.assertNotEqual(s['state'],'INVALID')
        d=files['dossier.json'];s,e=evidence_critique.analyze(d);self.assertEqual(s['state'],'OK')
        self.assertIn('CRITIQUE_NOT_PERFORMED',[g['code'] for g in e['evidence_gaps']])
        s,b=topic_scoring_bridge.integrate(d,e);self.assertEqual(s['state'],'OK')
        self.assertEqual(b['evidence_context']['evidence_gaps'],e['evidence_gaps'])

    def test_12_reproducibility_languages_and_nonmutation(self):
        c=cases()[0];before=deepcopy(c)
        a=run_path(c,'B','ru');b=run_path(c,'B','uk')
        self.assertEqual(c,before)
        self.assertEqual(canonical(a['bridge']),canonical(b['bridge']))
        self.assertEqual(canonical(a['evidence']),canonical(b['evidence']))
        self.assertEqual(canonical(a['intake']),canonical(b['intake']))
        self.assertNotEqual(a['locale'],b['locale'])
        self.assertTrue(all(x['ru']!=x['uk'] for x in a['bridge']['report']['limitations']))

    def test_13_research_only_does_not_evaluate_or_preview(self):
        with patch.object(editor_preview,'preview',side_effect=AssertionError('no frame')) as preview,patch.object(editor_preview,'evaluate_si',side_effect=AssertionError('no frame')) as evaluate:
            out=run_path(cases()[0],'A','ru')
        preview.assert_not_called();evaluate.assert_not_called();self.assertIsNone(out['si_result'])

    def test_15_original_oracle_mismatch_and_reviewed_contract_are_distinct(self):
        c=cases()[3];out=run_path(c,'B','ru')
        self.assertEqual(c['oracle']['si_eligibility'],'NEEDS_INPUT')
        self.assertEqual(out['si_result']['eligibility']['state'],'NEEDS_RESEARCH')
        self.assertNotEqual(c['oracle']['si_eligibility'],out['si_result']['eligibility']['state'])
        text=(ROOT/'docs/tasks/STORY_INTELLIGENCE_V1_R1_CONTRACT_CLARIFICATIONS.md').read_text()
        self.assertIn('обязательные UNKNOWN ratings',text)
        self.assertIn('UNKNOWN confidence без достаточного обоснования → NEEDS_RESEARCH',text)
        note=(ROOT/'docs/tasks/SI_PRODUCT_02_3_4_VALIDATION_REPORT.md').read_text()
        self.assertIn('Original-oracle verdict remains FAIL',note)

    def test_14_no_human_utility_claim_or_topic_ranking(self):
        for c in cases():self.assertEqual(set(c['oracle']['subjective_traits'].values()),{'NOT_ASSESSED'})
        data=json.loads((ROOT/'examples/si_product_02_3_4_cases.json').read_text())
        self.assertNotIn('overall_score',data);self.assertNotIn('topic_ranking',data)


if __name__=='__main__':unittest.main()
