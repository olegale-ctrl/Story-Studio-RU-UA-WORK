# SI-PRODUCT-02.3.4 — Validation Report

## OR-01 — Separate post-run oracle review (original oracle is preserved)

Дата: 2026-11-16. This section was written after the first targeted execution and
before the reviewed rerun. It is appended to the audit trail, not substituted into
the pre-execution oracle or static scenario JSON.

First targeted run: 14 test methods, exit 1, failures=2, errors=0. Both mismatches:
CASE-04 / B / ru and CASE-04 / B / uk. Original expected SI eligibility NEEDS_INPUT;
actual NEEDS_RESEARCH, aggregate UNKNOWN. Other original expectations were not revised.

The original oracle and cases bytes remain frozen:

- ORACLES SHA-256: `a9ff1e7771f3ec80c079b6c3df5bcb6b6ccfe4126de695339d62ba5d9bbd80d9`.
- CASES SHA-256: `ff7615f0bd5c0ba85843f4bdd0d4d94bba612065d58c3d8ec3d7dbaca9768f94`.

Authoritative basis, read after the mismatch to classify it:

1. [Approved R1 §3.2](STORY_INTELLIGENCE_V1_R1_CONTRACT_CLARIFICATIONS.md), item 4:
   mandatory UNKNOWN ratings → NEEDS_RESEARCH, aggregate UNKNOWN. NEEDS_INPUT is
   for missing постановка/audience/channel/required current data, not this fixture.
2. [Findings N04](STORY_INTELLIGENCE_SI_E02_2_1A_TEST_ORACLES.md): one rating.value
   UNKNOWN → NEEDS_RESEARCH/EVIDENCE_NEEDED, no zero-fill/renormalization.
   [Owner freeze](STORY_INTELLIGENCE_SI_E02_2_1B_OWNER_APPROVAL_2026_11_10.md) §1
   approves N01–N04/T01–T38 in that exact source revision.
3. Runtime `_scoring_findings` in unchanged evaluate_v1.py emits NEEDS_RESEARCH /
   EVIDENCE_NEEDED at `$.ratings[0].value`, consistent with those contracts.

Classification: **validation-oracle error**, not a contract or implementation defect.
Reviewed expectation for this one field in the two CASE-04/B paths: NEEDS_RESEARCH.
Research readiness remains NEEDS_INPUT; these are separate axes. The source fixtures,
original expected NEEDS_INPUT, production code and existing contracts stay unchanged.

The reviewed test explicitly asserts that the original expected value is NEEDS_INPUT,
that actual differs, that the approved expected value is NEEDS_RESEARCH, and that the
UNKNOWN aggregate/required diagnostic are retained. It does not skip/expectedFailure
or waive arbitrary mismatches. A separate regression preserves the original mismatch.

**Original-oracle verdict remains FAIL for the two CASE-04/B paths.** A reviewed
conformance PASS must not be presented as 20/20 initial-oracle agreement. First-run
log, freeze metadata and reviewed test results are retained in the package.
