# SI-PRODUCT-02.3.0 — Research & Scoring Contract

Дата: 2026-11-16. **MIXED STATUS — DOCS ONLY.**
База фактической архитектуры: `e0a9f63640c147365b17f1fe9d3b8d4b5f23986b`.
[RD-01–RD-04](SI_PRODUCT_02_3_0_OWNER_DECISIONS.md) — **APPROVED, A/A/A/A**
по явному решению владельца 2026-11-16, регистрация 02.3.0a от
`8b6c34103a557e68dfda7b56f5765bffc24a0d7d`.
Approval касается только содержания четырёх решений. Остальные research-форматы,
wire/field/enum/serialization details и предложения ниже — **PROPOSAL / NOT APPROVED**.
Нет blanket approval документа, нового SI/1 RecordType, реализации или provider.
02.3.1 остаётся **BLOCKED_BY_DEPENDENCY** до приёмки 02.3.0 и отдельного задания.

## 1. Неизменная основа и минимальный объём

Основания: [продуктовое решение](SI_PRODUCT_02_OWNER_DECISION.md),
[SI-D01–D10](STORY_INTELLIGENCE_V1_OWNER_APPROVAL_2026_11_09.md),
[original SI/1](STORY_INTELLIGENCE_V1_SPEC_PROPOSAL.md),
[R1](STORY_INTELLIGENCE_V1_R1_CONTRACT_CLARIFICATIONS.md),
[R1a](STORY_INTELLIGENCE_V1_R1A_RECORD_OPERATION_CLARIFICATIONS.md),
[R1b approval](STORY_INTELLIGENCE_V1_R1B_OWNER_APPROVAL_2026_11_09.md),
[TI/SR approval](STORY_INTELLIGENCE_SI_E02_1A_OWNER_APPROVAL_2026_11_10.md),
[EVAL-P01–P04](STORY_INTELLIGENCE_SI_E02_2_1B_OWNER_APPROVAL_2026_11_10.md),
[RC-P01–P06](STORY_INTELLIGENCE_SI_E02_2_1E_RC_OWNER_APPROVAL_2026_11_12.md),
[Q1–Q3](STORY_INTELLIGENCE_SI_E02_2_1F_OWNER_APPROVAL_2026_11_12.md).
Их scope-specific approvals имеют приоритет над историческими PROPOSAL-заголовками
утверждённых частей; настоящая работа не переутверждает их и не расширяет.

Утверждённый RD-03=A scope первого шага — ручной локальный intake реальных материалов и приватное
досье, отдельно от существующего SI-графа. Сеть, поиск, LLM, внешние провайдеры,
платные вызовы и чтение произвольных локальных материалов не подразумеваются.
Исследователь может получать материалы вручную; модуль не заявляет, что сам их нашёл.
Подключение агента возможно позже через те же явно маркированные предложения,
после отдельного privacy/licence/cost/provider контракта по SI-D09.

Это не второй evaluator, не ScientificApproval, Topic Intent implementation,
ProductionBrief builder, SI operation runner или долговременное SI-хранилище.
Первый dossier — недоверенный частный snapshot/export, не authoritative workspace.
SI-D03 durable lifecycle, EVAL-P05 Request/replay, ERef adapter и export authority
остаются отдельными границами. Никаких renderer/build, WAV/MP4, TTS или публикации.

## 2. Роли и происхождение

| Роль | Допустимый результат | Чего роль не устанавливает |
|---|---|---|
| Researcher: человек сейчас, отдельно разрешённый агент позже | Реальные source leads/captures, точные фрагменты, candidate claims, пробелы, предварительные обоснования | Истинность, human ClaimCheck, права, итоговый score или факт выполненного поиска без наблюдений |
| Independent Critic | Отдельный разбор аргументов, контрдоказательств, альтернатив и сенсационности с собственными основаниями | Независимую фактологическую верификацию лишь по названию роли, human findings, разрешение производства |
| Deterministic Evaluator | Только существующий `evaluate_si`, девять критериев, установленный aggregate/eligibility и все diagnostics | Получение источников, самостоятельные ratings, подлинность reviewer, научную истину |
| Human Editor | Проверка точных материалов, явные оценочные решения, рассмотрение критики/неопределённости, выбор ракурса и дальнейших действий | Автоматическую authority/rights/render eligibility через label, подпись в JSON или высокий score |

Research-поля различают `EDITOR_DECLARED`, `TOOL_OBSERVED`, `MODEL_PROPOSED`.
Это происхождение записанных сведений, не криптографическая аутентификация.
Редакторское согласие с моделью не меняет MODEL_PROPOSED на ручное авторство:
исходное предложение и отдельное решение сохраняются раздельно.
Внешний JSON с `confirmed=true` сам по себе не доказывает человеческий review.
Поставляемые решения отображаются как заявления редактора, не эффективные approvals.

## 3. Общие правила предлагаемых private research values

Это предлагаемые закрытые payload-структуры. Все перечисленные поля обязательны;
неизвестное значение выражается `K<T> = {state:KNOWN,value:T} | {state:UNKNOWN,reason:Text}`.
Для явно перечисленных state enums применяются их собственные UNKNOWN/NOT_* states.
`Hash` — 64 lowercase hex; Int0..5 — целое 0..5, не bool.
`Text` непустой, исходный Unicode и кавычки/qualifiers не нормализуются.
`UTC` — действительный `YYYY-MM-DDTHH:MM:SSZ`. `Date` — tagged
`{precision:YEAR|DATE|INSTANT,value:Text}` с действительным годом, датой YYYY-MM-DD
или UTC соответственно. Неизвестные авторы/даты не заполняются моделью или часами.

Общий envelope только четырёх типов §4–7 (не intake/dossier контейнеров): `{schema_version,id,revision,previous,provenance,payload}`.
Версия — имя соответствующего V1-типа; id — UUID; revision положительная; previous
null только для первой версии, иначе точная предыдущая research revision.
`provenance={kind,producer_label:K<Text>,method_label:K<Text>,upstream_refs:List<RRef>}`.
`RRef={research_type,id,revision,content_sha256}`; research_type — один из четырёх
типов §4–7. Это **не SIRef/ERef**; его нельзя передать в SI H/input_refs/basis_refs.
Хеш — SHA-256 канонических bytes всего envelope, без поля собственного хеша внутри
него: UTF-8, sorted keys, compact JSON, exact Unicode, no floats/duplicates/surrogates.
Порядок массивов сохраняется. Хеш связывает bytes, не существование материала/истину.

Изменение текста, исходных bytes, scope или источника создаёт новую research revision;
старые refs и решения сохраняются, не переносятся автоматически. Циклы/отсутствующие
refs/несовпадающие хеши — структурный отказ, не ordinary research uncertainty.
Подтверждения и связи относятся к exact revision, не к совпадающему title/URL/id.
Конкретные файловые лимиты/CLI/allowlist задаёт отдельное задание 02.3.1; никакой
неутверждённый durable store, CAS/recovery или auto-replay здесь не вводится.

## 4. ResearchSourceV1

**RD-02 = A — APPROVED / OWNER DECISION.** Достаточность evidence рассматривается
для каждого claim с учётом источника, фрагмента, контекста, метода, периода и
ограничений. Для спорных центральных или причинных claims нужно рассмотреть
независимое подтверждение либо явно обосновать его отсутствие и сохранить
неопределённость. Количество URL не доказывает истинность. Это утверждённый
качественный принцип, не автоматическое утверждение схемы ниже.

| Поле payload | Предлагаемый смысл/форма |
|---|---|
| title | K<Text>; реально предоставленное название, не сгенерированная библиография |
| author, organization | По K<Text>; UNKNOWN допустим для каждого независимо |
| locator | `{kind:URL\|LOCAL_ID,value:Text}`; абсолютный http(s) URL без credentials либо непрозрачный локальный идентификатор |
| published_at | K<Date>; точность исходной даты сохраняется |
| retrieved_at | K<UTC>; фактическое получение, если известно; не дата импорта JSON |
| material_sha256 | K<Hash>; SHA-256 исходных bytes, не hash SI-record или переписанного summary |
| source_type | `K<PRIMARY_DOCUMENT\|RESEARCH_PUBLICATION\|DATASET\|INSTITUTIONAL\|REPORTING\|PERSONAL_ACCOUNT\|OTHER>` |
| fragments | List<{fragment_id,exact_text:K<Text>,pointer:K<Text>,material_sha256:K<Hash>}> |
| applicability_limits | K<List<Text>>; период, население, география, методология, scope переноса выводов |
| checks | Пять независимых stage observations из таблицы ниже |

Для каждого fragment нужен точный текст или воспроизводимый pointer (страница/таблица/
секция/таймкод). Если оба UNKNOWN — остаётся source lead с диагностикой, не пригодное
цитатное основание. Pointer не означает, что материал получен/прочитан. Текст без
доступного exact материала хранится как предоставленная цитата, не проверенная.
Перевод — отдельная человечески рассмотренная версия рядом с оригиналом; не подмена.

Каждый stage observation содержит `state`, `basis:K<Text>`, `reviewed_material_sha256:K<Hash>`
и `origin:K<EDITOR_DECLARED|TOOL_OBSERVED>`; до observation origin=UNKNOWN.
Положительное editor_confirmation требует отдельное EDITOR_DECLARED основание;
модель не может выдать TOOL_OBSERVED или человеческое подтверждение.
Первый intake лишь сохраняет заявленное происхождение, не удостоверяет факт наблюдения.
Автоматический инструмент сможет создавать observation только после реального действия
в отдельно разрешённом execution path. Human label/копия receipt тоже не аутентификация.

| Независимая ось checks | Закрытые предлагаемые states | Граница |
|---|---|---|
| link_existence | NOT_CHECKED / RESOLVED / NOT_RESOLVED | Введённый URL не доказывает существование; NOT_RESOLVED не доказывает, что статьи нет |
| retrieval | NOT_RETRIEVED / RETRIEVED / FAILED | HTTP status, redirect, login или ссылка на PDF не сами bytes нужного документа |
| integrity | NOT_STORED / HASH_REPORTED / BYTES_HASH_MATCHED | Скопированный digest — только HASH_REPORTED; совпадение требует реальных exact bytes |
| content | NOT_REVIEWED / FRAGMENT_MATCH_REPORTED / CONTEXT_REVIEW_REPORTED | Цитата должна соответствовать месту и контексту; это ещё не истинность вывода |
| editor_confirmation | NOT_REVIEWED / CONFIRMED_AS_RECORDED / CONTESTED | Явное заявление человека об exact материале; не права или editorial approval |

Ни одна ось не продвигает другую автоматически. Для положительных observations нужны
соответствующие основания; иначе сохранить исходное заявление с gap, не повышать state.
При неуказанном locator/statement сохраняется сырой intake draft с диагностикой;
это не валидный Source/Claim и не повод выдумывать URL или текст.
Смена bytes обнуляет применимость прежнего рассмотрения к новой версии, но не историю.

Дубли одного id/revision с разным hash отклоняются. Совпавшие bytes отмечаются как
same-material candidates, не как два независимых подтверждения. Перепечатки/общий
первоисточник сохраняются со связями происхождения; нет голосования числом URL,
слияния по названию/переводу/filename и молчаливого удаления противоречий.

## 5. ResearchClaimV1

| Поле payload | Предлагаемый смысл/форма |
|---|---|
| statement, research_question | Точный тезис и вопрос, который он помогает исследовать |
| claim_kind, materiality | `K<factual\|interpretation\|fictional>` и `K<CENTRAL\|SUPPORTING\|CONTEXT>`; для SI admission явный выбор редактора, не эвфемизм для обхода blocker |
| evidence_expectation | K<Text>; требуемое основание тезиса, без выдуманного default для SI |
| supporting, contradicting | Lists<{source_ref:RRef<ResearchSourceV1>,fragment_id:Text,relation_reason:Text}>; не counts/вердикты |
| contextual | Та же связь для context/insufficient, с явной relation |
| verification_state | NOT_REVIEWED / EDITOR_REVIEW_RECORDED / DISAGREEMENT_RECORDED / WITHDRAWN_FROM_DRAFT |
| uncertainty | `{level:LOW\|MEDIUM\|HIGH\|UNKNOWN,reasons:K<List<Text>>}`; не вероятность истинности |
| further_research | `{needed:YES\|NO\|UNDETERMINED,actions:List<Text>}` |
| editor_review | K<{reviewer_label,reviewed_at:K<UTC>,reason,reviewed_source_refs:List<RRef>}> |

Поддерживающие/противоречащие связи — записанные аналитические утверждения, не
ClaimCheck. Модельная формулировка остаётся MODEL_PROPOSED, даже если редактор
согласился. Отсутствие замечаний критика не переводит claim в supported.
Контрдоказательства и нерешённые существенные оговорки не исчезают при большинстве
supports, высоком narrative score или перестановке ракурса. Factual не меняется
на fictional лишь для прохождения evaluator; снятый тезис нельзя оставить фактом
в hook/сценах. Критика может оспаривать поддерживающую relation, а не саму цитату.

### 5.1 Граница с существующим SI/1

[Typed schemas](../../story_intelligence/records_v1.py), [headers](../../story_intelligence/model_v1.py)
и [provenance verifier](../../story_intelligence/provenance_v1.py) остаются неизменны.
Предлагается внешняя correspondence table `RRef ↔ exact SIRef`, не поля внутри H
или скрытый JSON в reason/rationale. Она не доказывает semantic equivalence сама по себе.

При показе оценки рядом с новым досье отдельно фиксировать exact research snapshot,
SHA-256 полного evaluation_inputs, correspondence и человеческую scope-note: все ли
relevant sources, claims и контрдоказательства представлены. Сам evaluator проверяет
только supplied view, не глобальную полноту исследования. Без рассмотренной привязки
показывать результат как оценку предоставленного SI-контекста, а текущее досье —
ещё не оценённым. Совпадение topic title/id или прежний OK не заменяет эту границу.
Изменение research refs/данных инвалидирует связь с прежней оценкой; новые данные
не отбрасываются ради сохранения ELIGIBLE. Никаких новых полей в evaluator/Preview.
Привязка — recorded correspondence, не proof истинности, чтения или прав.

| SI тип | Допустимая подготовка после явного человеческого рассмотрения | Нельзя автоматически делать |
|---|---|---|
| SourceItem | source_kind URL/LOCAL, original_locator; title/author/publisher/published_at/captured_at/material_sha256/rights_note/freshness_requirement в existing Known forms; editorial_ref только существующий exact ERef либо null | URL→fetch, reported hash→verified bytes, organization→publisher без явного основания, дата дня→вымышленная UTC-секунда |
| ClaimItem | statement с сохранёнными оговорками; claim_kind/materiality/evidence_expectation по actual payload; editorial_ref по existing правилам | Перевести MODEL_PROPOSED в MANUAL_INPUT кнопкой «принять», стереть ancestry, invent editorial binding |
| EvidenceItem | Точные claim_ref/source_ref; relation supports/contradicts/context/insufficient, locator Known/UNKNOWN, explanation; только реально сопоставленные фрагменты | Сгенерированный summary→точная цитата; relation supports→проверенный факт |
| ClaimCheck | Только отдельный явный человеческий review exact claim/evidence; existing state/metadata invariants ниже | ResearchClaim.state или Critique.delivery→supported/qualified, модель→reviewer, непустая причина→human review |

SourceItem не хранит весь research payload. В нём нет source_type, оригинальной
цитаты или отдельного статуса fetch/integrity/content. Эти сведения сохраняются
в досье; EvidenceItem.locator указывает на точный фрагмент/снимок, а не подменяет его.
Дата публикации с точностью YEAR/DATE остаётся в досье; SI published_at=UNKNOWN
с причиной неизвестного UTC instant, а не выдуманные timezone/полночь. captured_at
не становится Known от даты записи метаданных. Нет material bytes — нет вычисленного
material hash; копия hash остаётся заявлением со своим происхождением.

Полный SI ClaimCheck state set: `unreviewed`, `supported`, `disputed`, `unverified`,
`qualified`, `removed`. Никакого автоматического соответствия research states.
Если mandatory SI field (например evidence_expectation) не предоставлен, bridge
не заполняет его технической заглушкой ради валидной структуры.
ClaimCheck `unreviewed`: reviewer_label/reviewed_at/reason = null.
Остальные states требуют непустые reviewer_label/reason и реальный declared UTC
reviewed_at; для qualified обязательна qualification, только для неё она non-null.
Supported/qualified требуют Known nonempty evidence_refs. Unknown review time
не достраивается: сохранить заявление в research, не выпускать ложный reviewed Check.
Даже корректный ClaimCheck лишь recorded consideration, не authenticated reviewer.

Исходные SourceItem/ClaimItem/EvidenceItem/ClaimCheck допускают только реально
ручной MANUAL_INPUT или честный USER_IMPORT с imported_from. Новая revision
сохраняет previous и HUMAN_EDIT/REVISION ancestry по R1/R1a. Native model/provider
mapping для этих записей не утверждён: MODEL_DERIVED runtime недоступен, provider
в RunRecord должен быть null. Технически валидный USER_IMPORT не лицензия на
скрытие машинного происхождения. Неподдержанное машинное содержимое остаётся
в research до отдельного truthful provenance bridge; никаких fake CREATIVE runs.

На базе нет публичного исполняемого RECORD_INPUT/REVISE_INPUT/операционного writer.
Есть pure validators/resolver/provenance/currentness. Поэтому указанная подготовка
не обещает, что эти операции уже реализованы, не создаёт persisted SI refs сама.
По утверждённому RD-03=A готовый EditorPreviewInputV1/SI frame **необязателен**
и передаётся существующему 02.2.2 без изменения его схемы. Без SI frame — только
исследовательское досье и действия редактора, без вымышленной оценки. Без проверенной
correspondence нельзя утверждать, что SI evaluation охватывает текущее исследование.
Отсутствие bridge не исправляется synthetic records; автоматический SI builder,
сеть, crawler, LLM provider и authoritative storage не разрешены.

## 6. ResearchCritiqueV1 и независимость

Payload: `{target:RRef<ResearchClaimV1|TopicRecommendationV1>,issue:K<Text>,counterargument:K<Text>,alternative:K<Text>,
evidence_links:List<{source_ref:RRef<ResearchSourceV1>,fragment_id:Text,relation_reason:Text}>,severity:LOW|MEDIUM|HIGH|CRITICAL|UNKNOWN,
editor_action:Text,delivery:NOT_PERFORMED|DELIVERED|FAILED,
independence:NOT_ESTABLISHED|SEPARATE_HUMAN|SEPARATE_RUN_SAME_PROVIDER|SEPARATE_PROVIDER,
independence_basis:K<Text>,checklist_notes:K<Text>}`.

Если критика направлена на прежнюю рекомендацию, новая recommendation ссылается
на critique и прежний snapshot; не создавать цикл critique↔текущая recommendation.
DELIVERED значит наличие записанного разбора, не «критика пройдена». «Проблем не
сообщено» явно отличается от NOT_PERFORMED, unknown или отсутствующего evidence.
Отсутствие исполнения/документа нельзя подменять положительным отчётом; неизвестную
independence не повышать по отличающемуся model label. Расхождение исследователя
и критика остаётся видимым до отдельного решения человека с exact evidence refs.

**RD-01 = A — APPROVED / OWNER DECISION, 2026-11-16.**
Для каждой темы перед окончательной редакторской рекомендацией требуется отдельный
короткий критический проход. В manual-first реализации независимый критик — другой
человек. Повторная проверка тем же человеком не считается независимой. Незавершённый
intake разрешён; отсутствие критики остаётся видимым. Существенные научные и правовые
разногласия эскалируются человеку. Это не automatic scientific approval или новый
блокер evaluator; отдельный человеческий проход должен реально состояться.

Второе чтение тем же человеком отмечается NOT_ESTABLISHED, не SEPARATE_HUMAN.
Неутверждённый будущий agent design (не часть RD-01=A): агент-критик получает вопрос и источники для отдельного первичного анализа,
затем аргументы Researcher для challenge; отдельный запуск/контекст и записанные
метаданные, не один ответ модели, переименованный в независимый. Та же модель
в другой сессии имеет коррелированные ограничения; другой provider тоже не
гарантирует правильность. Ничего из этого не включает provider сейчас.

Checklist SR-C01–C07 уже требует рассмотрения терминов, датировки, альтернатив,
контрдоказательств, оговорок/неопределённости, traceability и intended-use rights.
Здесь checklist_notes — человечески читаемое описание, не новый machine-verifiable
Scientific Review completion profile. Нет ScientificApproval, новых SI states или
автоматического снятия Risk/ClaimCheck blocker. Expert labels не credentials.

## 7. TopicRecommendationV1

Payload: `{research_snapshot_refs:List<RRef<ResearchSourceV1|ResearchClaimV1|ResearchCritiqueV1>>,prospect:RESEARCH_MORE|EDITOR_REVIEW|DEFER_PROPOSAL|DO_NOT_DEVELOP_PROPOSAL,
reasons:List<Reason>,audience:K<Text>,main_angle:K<Text>,alternative_angles:List<CreativeProposal>,
emotional_hooks:List<CreativeProposal>,intellectual_hooks:List<CreativeProposal>,
narrative_potential:K<Text>,visual_needs:List<Text>,scientific_risks:List<Reason>,
editorial_risks:List<Reason>,production_limits:K<List<Text>>,gaps:List<Text>,
next_actions:List<Text>,evaluation_binding:K<Hash>,production_state:NOT_ASSESSED}`.
`evaluation_binding` — digest отдельного объекта в досье: `{research_snapshot_refs,
evaluation_inputs_sha256,correspondence,editor_scope_note}` из §5.1; объект целиком
сохраняется, не один opaque hash. В binding входят source/claim/critique inputs,
не текущая recommendation с этим же binding: self-hash/cycle запрещён. UNKNOWN если привязка не рассмотрена; совпадение
хешей само по себе не machine proof semantic completeness.
`Reason={text,basis_claim_refs:List<RRef<ResearchClaimV1>>,kind:FACTUAL_CONCLUSION|INTERPRETATION|RESEARCH_GAP}`;
`CreativeProposal={text,basis_claim_refs:List<RRef<ResearchClaimV1>>,label:CREATIVE_PROPOSAL,limitations:List<Text>}`.

Каждый существенный фактический вывод обязан иметь exact claim→source→fragment
chain и отражать actual review/qualifications. Без неё вывод остаётся явно
неподтверждённым предположением/пробелом, а не FACTUAL_CONCLUSION. Число ссылок
не заменяет их применимость. Reasons не могут скрывать противоречащий source.
Досье отдельно показывает факт предоставленного материала, интерпретацию,
модельную гипотезу и редакторское заявление; ни одно не научная сертификация.

Крючки/ракурсы — помеченные предложения, не новые факты или сценарии. Если нет
поддержанного claim, допустим только открытый исследовательский вопрос с явным gap,
не сенсационный ответ. Нельзя убирать qualifier ради удержания внимания.
Нет автоматического создания SI CreativeAlternative: её первоначальная версия
требует отдельный CREATIVE Run по R1a. Нет auto-переноса в scene_drafts или Brief.

Prospect — не evaluator eligibility, рейтинг, Topic Intent action или ранжирование.
Это предварительный редакторский совет; окончательное решение человека отдельно.
Имеющиеся genuine BLOCKED/STALE/INVALID и все ограничения оценки показываются рядом,
не заменяются «перспективностью». Нет второго итогового балла, вероятности успеха
или автоматической рекомендации render/publication/commercial use.

## 8. Предварительные оценки → единственный существующий evaluator

Для каждого критерия предлагается запись: `{criterion_key,proposed_value:K<Int0..5>,
basis_refs:List<RRef>,rationale:Text,confidence:{level,basis},origin:EDITOR_DECLARED|MODEL_PROPOSED,
editor_choice:K<{chosen_value:K<Int0..5>,reason,reviewer_label,reviewed_at:K<UTC>,reviewed_refs:List<RRef>}>}`.
Это отдельные значения досье, не SI ratings и не human_findings. Девять критериев
в фиксированном порядке ниже; по ним не считается research total.

| Критерий | Вес | Основание и явное человеческое действие перед admission |
|---|---:|---|
| audience_interest | 15 | Мотивация/вопрос и помеченные гипотезы аудитории; не вымышленная статистика; редактор выбирает/оставляет UNKNOWN |
| channel_fit | 10 | Реальная цель/язык/ограничения ChannelContext; редактор подтверждает соответствие |
| angle_novelty | 10 | Различия exact ракурса с предоставленным портфелем; не global novelty; редактор рассматривает недостаток сравнения |
| evidence_quality | 20 | Traceable fragments, контрдоказательства и actual human reviews; редактор оценивает применимость, не количество URL |
| narrative_potential | 15 | Объяснимая структура без изменения фактов/qualifiers; редактор рассматривает субъективную оценку |
| visual_feasibility | 10 | Указанные существенные visuals и ограничения использования; фактические права/доступность отдельно |
| resource_fit | 10 | Реальные доступные ресурсы/CPU/время либо явно неизвестные; capability_notes не доказательство исполнимости |
| risk_manageability | 5 | Научные/правовые/прочие риски и основания review; высокий рейтинг blocker не снимает |
| portfolio_distinctness | 5 | Все предоставленные local portfolio entries и явные сравнения; не обещание уникальности в интернете |

**RD-04 = A — APPROVED / OWNER DECISION.** На первом этапе preliminary ratings
выбирает человек; допускается UNKNOWN. Модельные предложения сохраняются отдельно
с происхождением и не импортируются автоматически в SI ratings. Не хватает основания —
UNKNOWN с причиной, не 0/среднее/искусственный confidence. Девять критериев, веса,
eligibility и human findings неизменны. Это не изменение evaluator и не аутентификация
автора ratings; provider/модельная генерация этим решением не разрешена.

Существующий `_RATING`: criterion_key, value:Known<Int0..5>, basis_refs:List<SIRef>,
explanation, confidence:{level:LOW|MEDIUM|HIGH|UNKNOWN,basis}. Никаких RRef в basis_refs:
только уже подготовленные exact SI refs с верным scope. Полная девятка/order/weights
обязательны. Один неизвестный rating → aggregate UNKNOWN. При всех известных
единственный aggregate_tenths вычисляет evaluate_si: `2 * Σ(weight * value)` (0..1000).
Не рассчитывать независимый total и не добавлять пороги перспективности.

HumanFindingsInput остаётся exact `si-evaluate-findings/proposal-1`: binding пяти
core refs, ordered semantic roots, expected context и ratings_sha256; confidence
findings только для UNKNOWN confidence (`SUFFICIENT|INSUFFICIENT` с binding/rating
hashes); duplicate findings для **всех** Known local portfolio entries с exact
index/entry digest/candidate ref (`DISTINCT|DUPLICATE|UNRESOLVED`). Ни Researcher,
ни Critic не выпускают эти human outcomes автоматически. SUFFICIENT не повышает
confidence level и не делает UNKNOWN rating известным. LOW/MEDIUM/HIGH не повод
изобретать новый confidence gate, которого нет в действующем evaluator.

`required_current_premise` отдельно, tag `si-required-current/proposal-1`:
REQUIRED/NOT_REQUIRED/UNDETERMINED — явное человеческое определение, не clock,
keywords, дата публикации или ответ модели. NOT_REQUIRED не удостоверяет freshness;
нужны все применимые source_freshness assessments. Existing proof требует exact
Evidence/ClaimCheck/material refs, hash и approved coverage, не копию receipt.
Смена ratings/refs/context требует нового exact binding и повторного рассмотрения,
не automatic rebasing. EVAL-P05 Request persistence не реализуется.

Malformed refs/graph/hash → INVALID; intact, но устаревшие inputs/context → STALE.
Они не ordinary missing research. Затем неизменная precedence:
BLOCKED → NEEDS_INPUT → NEEDS_RESEARCH → REVIEW_DUPLICATE → ELIGIBLE_FOR_CREATIVE.
Все applicable diagnostics сохраняются, high score не перебивает их. Центральный
factual claim с unresolved review/contradicts остаётся BLOCKED, другой positive check
его не очищает. Existing positive predicate — только recorded consistency:
supported/qualified Check + связанный supports Evidence с Known locator и Source
material hash; это не proof scientific truth/reading/rights.

## 9. Приватное досье, эталон и границы следующего шага

Предлагаемый dossier — пакет exact source/claim/critique refs, предварительных оценок,
отдельных human declarations, TopicRecommendation, пробелов и действий. Ввод темы,
аудитории, вопроса и ракурса сохраняется дословно; неполное разрешено. У всех typed
sections явно показано UNKNOWN/NOT_PERFORMED; нет “исследование проведено” из наличия
текста. Dossier не masquerades as EvaluationReport, ProductionBrief или approval.

RU/UK локализуют fixed labels/actions. Оригиналы цитат/утверждений не переводятся и
не переписываются автоматически. Человеческий перевод — отдельный связанный текст,
не независимый источник/второе подтверждение. Private raw source URLs/личные данные/
полные тексты не попадают в контролируемые сообщения Projection или внешние сервисы.
Досье может содержать необходимые точные цитаты privately; это не право распространять
полный материал, обходить paywall, лицензии или ограничения intended-use.

Утверждённый RD-03=A scope: локальный ручной intake и явный частный snapshot export в новый
каталог вне Git, по ограничениям privacy 02.2.2; без authoritative SI persistence,
ключей, network, material file crawler, provider и overwrite. POSIX modes не NTFS
qualification. Детальная source acquisition/import-root policy, durable workspace,
SSRF/redirect/download limits и подключение агента требуют отдельного задания.
Исходные документы — данные, не команды на выполнение или инструкции агенту.

### 9.1 Предлагаемые контейнеры локального intake/export

Это новые private file values, не расширение SI Request или EditorPreviewInputV1.
Закрытый `ResearchIntakeV1` имеет поля:

- `schema_version=ResearchIntakeV1`, `purpose=RESEARCH_ONLY`;
- `topic={id:UUID,wording:K<Text>,source_locale:ru|uk}`;
- `audience:K<Text>`, `research_question:K<Text>`, `proposed_angle:K<Text>`;
- `sources:K<List<ResearchSourceV1>>`, `claims:K<List<ResearchClaimV1>>`,
  `critiques:K<List<ResearchCritiqueV1>>` — полные envelopes §3;
- `preliminary_assessments:K<List<оценка §8>>`,
  `recommendation:K<TopicRecommendationV1>`, `editor_notes:List<Text>`;
- `existing_preview_input:K<EditorPreviewInputV1>` — неизменённый отдельный объект 02.2.2;
- `evaluation_correspondence:K<{research_snapshot_refs,evaluation_inputs_sha256,
  correspondence:List<{research_ref:RRef,si_ref:SIRef}>,editor_scope_note:Text}>`.

UNKNOWN lists не становятся пустыми KNOWN lists. KNOWN [] означает только
предоставленное отсутствие entries, не отсутствие источников/рисков во внешнем мире.
Незавершённый или malformed input остаётся private raw draft с диагностикой;
это не повод выпустить валидный research envelope с вымышленным locator/statement.

Закрытый output `ResearchDossierV1`:
`{schema_version:ResearchDossierV1,purpose:RESEARCH_ONLY,intake_sha256:Hash,
input_snapshot:ResearchIntakeV1,diagnostics:List<Diagnostic>,next_actions:List<Action>,
preview_association:NO_FRAME|UNVERIFIED_SCOPE|SCOPE_REVIEW_RECORDED,
preview_status:K<EditorPreviewStatusV1>,production_state:NOT_ASSESSED}`.
`Action={ru:Text,uk:Text}`. `Diagnostic={code,section,action:Action}`; proposed code set:
`INPUT_MISSING, INPUT_INVALID, SOURCE_NOT_RETRIEVED, FRAGMENT_MISSING,
SOURCE_REVIEW_MISSING, CLAIM_REVIEW_MISSING, CONTRADICTION_UNRESOLVED,
CRITIQUE_NOT_PERFORMED, CRITIQUE_INDEPENDENCE_UNKNOWN, SI_BRIDGE_UNAVAILABLE,
SCOPE_UNVERIFIED, EVALUATION_INVALID, EVALUATION_STALE, PROJECTION_UNAVAILABLE`.
Это только новый research namespace, не SI ErrorCode. Controlled text не повторяет
raw values/paths/URLs из входа. Полный список private originals находится отдельно.

`NO_FRAME` — нет предоставленного frame; `UNVERIFIED_SCOPE` — frame есть, но
correspondence не рассмотрена; `SCOPE_REVIEW_RECORDED` — рассмотрение заявлено.
Эти association states не означают, что preview был выполнен.
`preview_status` может быть Known только после фактического вызова existing preview;
NOT_RUN evaluation внутри такого настоящего статуса не подменяется OK. При отсутствии
вызова — UNKNOWN. Для отрицательной validation input отсутствует valid Dossier:
сохраняется диагностический draft, а не фиктивный input_snapshot/положительная Card.
`SCOPE_REVIEW_RECORDED` фиксирует человеческое заявление correspondence, не
машинную гарантию её смысловой полноты/подлинности. До него оценка относится лишь
к supplied SI view; новый research snapshot не наследует прежний статус.
Ни один контейнер не содержит credential, run request_id, production permit или
команду запуска. Provider proposals не получают человеческое происхождение через import.

### 9.2 План эталона и качества

Эталон — **24 различных темы**, не 24 перефразировки/перевода. Только план набора:

| Плановые слоты | Основная страта | Отбор человеком |
|---|---|---|
| B01–B03 | Сильная доказательная база | Реально доступные первичные материалы, прослеживаемые claims |
| B04–B06 | Спорная наука | Содержательные конкурирующие объяснения, не искусственное противоречие |
| B07–B09 | Популярные слабо подтверждённые сюжеты | Проверяемые основания слабости, без придуманной популярности |
| B10–B12 | Высокая визуальная сложность | Реальные ограничения материалов, права и доступность отдельно |
| B13–B15 | Недостаток источников | Честная незавершённость; UNKNOWN сохраняется |
| B16–B18 | Риск преувеличения | Sensational hooks против bounds/оговорок исходного исследования |
| B19–B21 | Несколько перспективных ракурсов | Различные вопросы/аудитории без изменения underlying facts |
| B22–B24 | Кандидаты на отказ редактора | Проверяемые причины; итоговый REJECT только после реальных human labels |

Карточка эталона: topic_id/primary_stratum/risk_tags, exact dossier snapshot,
audience/angle/channel context, source/claim refs, данные на дату фиксации;
два независимых human reviews со значениями девяти критериев/UNKNOWN и причинами,
списком контрдоказательств/essential gaps, предложенными действиями и разрешением
разногласий третьим review либо сохранённым disagreement. Первичные labels не
удаляются после adjudication. Human label остаётся заявлением, не trusted authority.
Original locale и RU/UK интерфейсные варианты отмечаются отдельно; перевод одного
кейса не увеличивает число тем. Истинные labels/источники/цитаты здесь **не созданы**.

До сравнения скрыть system/model рекомендации от независимых human raters; не
подбирать labels после результата модели. Dev/holdout разделять по теме и общей
source family, не разнести перевод/перепечатку в train и test. Размеры split и
доступность второго rater фиксируются до качества-эксперимента, не выдумываются.

Метрики отдельно, без нового composite score: доля реальных traceable source/fragment
links; точность цитат; число/доля unsupported factual assertions и ложных human/fetch
подтверждений; recall размеченных противоречий и critical gaps; preservation UNKNOWN;
per-criterion MAE на совместно известных human/system values и coverage UNKNOWN;
межэкспертное согласие/разногласия; совпадение downstream eligibility/reasons при
одинаковом approved SI frame; RU/UK fidelity/privacy leaks; затраты человеческого
времени/критики отдельно. Доля неопределённых/неполученных source items входит в
отчёт и знаменатели, не исключается ради красивой accuracy.
Цели качества/доверительные интервалы/согласие ратеров измеряются на реальных labels;
численных PASS thresholds, результатов или калиброванных весов сейчас нет.
Ошибочная атрибуция model→human и вымышленные источники — обязательные negative
cases будущих тестов, не приемлемая автокоррекция.

Исследовательские JSON остаются отдельными от закрытого EditorPreviewInputV1.
Точная [интеграция и future oracles](SI_PRODUCT_02_3_0_INTEGRATION_MATRIX.md)
и [зарегистрированные решения владельца](SI_PRODUCT_02_3_0_OWNER_DECISIONS.md) — рядом.
A14 editorial HANDOFF, rights policy и Production Readiness не меняются;
[D1](SI_PRODUCT_02_2_D1_SYNTHETIC_RENDER_PERMIT.md) применим только к зарегистрированному
синтетическому тесту 02.2.1, не к этим источникам, вопросам или планам.
`PUBLISH_REVISION` DISABLED, partial COMMIT reconstruction OFF; никаких новых
разрешений render/publication/commercial use. **STOP до независимого ревью.**
