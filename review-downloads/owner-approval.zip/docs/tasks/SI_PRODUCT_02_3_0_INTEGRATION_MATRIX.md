# SI-PRODUCT-02.3.0 — Integration Matrix

**MIXED STATUS — DOCS ONLY.** База API: `e0a9f63640c147365b17f1fe9d3b8d4b5f23986b`.
[RD-01–RD-04](SI_PRODUCT_02_3_0_OWNER_DECISIONS.md) — **APPROVED, A/A/A/A**
по решению владельца 2026-11-16. [Контракт](SI_PRODUCT_02_3_0_RESEARCH_CONTRACT.md)
и матрица утверждены только в scope этих четырёх решений; остальные private formats,
wire details и предлагаемые переходы сохраняют **PROPOSAL / NOT APPROVED**.
«Proposed» не означает существующий runtime или разрешение начать реализацию.

## 1. Фактические API и границы на базе

| API / сущность | Что существует | Чего нельзя предполагать |
|---|---|---|
| `validate_si_record(value)`, `si_record_ref(value)`, `validate_si_record_ref(value,expected_ref)` | Pure typed SI/1 schema/byte identity; [records_v1.py](../../story_intelligence/records_v1.py) | Создание review, retrieval, операции RECORD_INPUT/REVISE_INPUT или trusted persistent state |
| `resolve_si_closure(records,roots)` | Exact hashes/types/refs, graph/cycles/audit closure; [resolver](../../story_intelligence/resolver_v1.py) | Semantic truth, global completeness или implicit latest |
| `verify_si_provenance(records,roots)` | Cross-record run/revision consistency; [provenance](../../story_intelligence/provenance_v1.py) | Факт реального запуска, внешнюю model provenance или authenticated editor |
| `check_si_currentness(records,root,observed_active_input_refs,observed_selection_head_refs)` | Pure explicit observed-context semantic currentness; [currentness](../../story_intelligence/currentness_v1.py) | Global current truth, clock-based source freshness или разрешённый ERef adapter |
| `evaluate_si(records,semantic_input_refs,observed_context,ratings,expected_context,human_findings,required_current_premise=None,*,ui_locale=None)` | [Точный evaluator](../../story_intelligence/evaluate_v1.py), plain dict OK/INVALID/STALE | Поиск/извлечение/ratings generation, новый final score, output `EvaluationReport`/`RunRecord` |
| `project_evaluation(evaluation_inputs=None,evaluation_result=None,display_locale=None)` | [Projection](../../story_intelligence/decision_projection_v1.py); обязательная повторная оценка; Card или UNAVAILABLE | Добавление research разделов/сырого текста в fixed Card, bypass проверки, производство |
| `preview(data)` / `run(source,output)` | [02.2.2](../../scripts/editor_preview.py): новый local export, actual evaluation/cards и manual plans | Research intake parser, SI builder, acceptance отсутствующих human findings |
| `first_video.read_plan(path)` | Существующая structural validation locale ru/uk и 1–20 scenes | Перевод, semantic correctness, разрешение рендера или прав |

Важно: currentness API получает отдельные списки active refs/selection heads,
а evaluator принимает полные observed/expected ContextSnapshot. Они не взаимозаменяемы.
Никакие RRef из research dossier не проходят как SIRef или ERef.
Audit ancestry и required-current semantic dependencies не склеиваются. Relevant
ERef, включая фактический producer Run, без validated snapshot остаётся INVALID /
REF_MISSING: currentness API не принимает такой snapshot. Нельзя удалить ERef ради CURRENT.

## 2. Логическая цепочка и исполнение

```text
Editor Input → Research → Critique → human admission → SI/1 inputs
             → evaluate_si → Projection → Editorial Preview
```

На базе нет исполнителя первых proposed research/bridge стадий. По утверждённому RD-03=A новая
часть готовит private dossier и работает только с отдельно предоставленным existing
EditorPreviewInputV1/SI frame. Она не выдаёт подготовленный research объект за SI.
Отсутствие frame — честные dossier/gaps, не фальшивый end-to-end EVALUATE.

Для существующего пути фактическая точка вызова — неизменённый `preview(data)` или
его CLI `run(source,output)`. Он **внутри** вызывает evaluate_si и Projection для
двух display locales; каждый вызов Projection дополнительно повторяет evaluator.
Это реализация трёх последних логических стрелок, а не повод сначала вычислить
карточки, а затем тайно вложить их в новый запрос preview. Не добавлять к input
`evaluation_result`, `research`, `recommendation`, `human_approved` или иные ключи.

## 3. Полная матрица переходов

В колонке «полномочия» — допустимое основание действия, не editorial authority.
Каждая строка имеет отдельные вход/выход/ответственного/состояния/отказ/проверки/API.

| ID / переход | Вход | Выход | Ответственный | Основание полномочий | Допустимые состояния | Отказ / остановка перехода | Необходимые проверки | Совместимость |
|---|---|---|---|---|---|---|---|---|
| M01 Editor Input → Research intake (proposed) | Standalone ResearchIntakeV1 (§9.1): тема/audience/question/angle; sources/claims | ResearchDossierV1, частный input snapshot и gaps | Human Editor, intake validator | Явная локальная передача данных; не разрешение fetch/model | COMPLETE / NEEDS_INPUT / INVALID на уровне нового адаптера | Неверный формат/неизвестные поля/непринятые URLs; нет выдуманного исправления | Неполное сохранить как draft; типы/версии, unknown и исходный язык; private data separation | Новый standalone research input; не расширение закрытого EditorPreviewInputV1 |
| M02 Intake → ResearchSourceV1 / ResearchClaimV1 (proposed) | Реально предоставленные metadata/fragments и provenance | Exact research revisions/refs, supporting/contradicting links, uncertainties | Researcher; редактор для factual review | Declared input либо отдельно разрешённое реальное tool observation | Source axes независимо; Claim NOT_REVIEWED / EDITOR_REVIEW_RECORDED / DISAGREEMENT_RECORDED / WITHDRAWN_FROM_DRAFT | Нет source/fragment/ref/hash — gap или structural failure по причине; никаких fake sources/evidence | Exact original text/pointer, dates precision, bytes vs reported digest, duplicates; RD-02=A: claim/source/fragment/context/method/period/limits, независимое подтверждение спорного central/causal claim либо причина отсутствия и uncertainty; число URL не truth | Research values отдельно от 18 SI types; URL не fetch; новый SI graph не возникает |
| M03 Research → ResearchCritiqueV1 (proposed) | Exact claim/conclusion и sources, контекст вопроса; отдельно argument Researcher | Разбор проблем, контраргументов и альтернатив с refs | Independent Critic | Отдельное фактически выполненное human review; agent только после provider approval | NOT_PERFORMED / DELIVERED / FAILED; independence отдельно | Нет critique/основания независимости — отметить, не “PASS”; RD-01=A требует отдельного прохода каждой темы другим человеком; отсутствие критики видимо, существенные научные/правовые разногласия эскалируются человеку | Отдельный проход, provenance, source access/context, severity, не спрятанные contradictions; SR seven-area notes | Нет нового SI stage CRITIQUE, provider RunRecord или human finding |
| M04 Research + Critique → editor dispositions (proposed) | Exact revisions и contested issues | Человеческие explanations, сохранить disagreement/gaps либо новые research revisions | Human Editor / отдельный reviewer при escalation | Явное рассмотрение человека; label не identity proof | NOT_REVIEWED / REVIEW_RECORDED / DISAGREEMENT; прежние remarks сохраняются | Неизвестный review time/scope, нерешённое essential disagreement — не выдавать positive Check | Не менять origin модели, hash binding review scope, qualifiers, все SR-C01–07 как человеческий checklist | Не ScientificApproval и не machine-verifiable SR completion, не ApprovalRecord |
| M05 Human admission → SI/1 correspondence (proposed boundary) | Досье + реально ручные/imported данные; отдельный existing SI frame если имеется | Correspondence RRef↔SIRef и/или NOT_BUILT; SI records только по отдельному допустимому пути §5.1 контракта | Editor и отдельно разрешённый builder/adapter | Только genuine ручное авторство/честный import, не model confirmation flag | NOT_BUILT / NEEDS_INPUT / VALIDATED_INPUTS / INVALID_REFERENCE | Нет truthful provenance/real fields/refs или runtime builder — остановить bridge; не invent H/runs | Actual schemas; Source Known fields; exact Claim/Evidence/Check linkage; typed imports; no laundering; revision/previous integrity | На базе pure validators, не публичные operation runners. RD-03=A не реализует новый builder; MODEL_DERIVED/provider остаются недоступны |
| M06 SI/1 frame → evaluate_si (existing) | Шесть required arguments + существующие optional premise/ui_locale, exact ratings/bindings/contexts | Настоящий plain evaluation dict | Unchanged deterministic evaluator | Явный caller frame; human fields как declared consideration, не authority | OK/CURRENT с five eligibility values либо INVALID/STALE с null eligibility/aggregate | Missing invocation: не вызывать; malformed graph/hash/findings: actual INVALID; intact stale: actual STALE | Существующие shape/resolver/provenance/currentness, rubric 9/order/weights, binding, all portfolio/freshness coverage | Ни новых enum/codes/weights/thresholds, ни отдельного total. EvaluationReport/RunRecord автоматически не записываются |
| M07 evaluation → Projection (existing) | Тот же полный evaluation_inputs + фактический result + display_locale ru/uk | Exact private Card либо UNAVAILABLE | Unchanged Projection | Mandatory real re-evaluation + canonical equality, не caller trusted flag | DISPLAYABLE / UNAVAILABLE | Изменённый score/findings/blocker, missing/unsupported result — no fabricated Card | Сохранять 30 families, все blockers/порядок/UNKNOWN/six limitations, privacy | Research recommendation/critique не вставляются в Card. Direct Projection умеет genuine INVALID diagnostic card; путь 02.2.2 сознательно её не создаёт |
| M08 Projection + manual drafts → Editorial Preview (existing) | Допустимый EditorPreviewInputV1; RU/UK authored drafts и materials declarations | preview-status/evaluation/cards при actual availability; complete plans отдельно от partial drafts | Existing 02.2.2 adapter; Human Editor задаёт тексты | PREVIEW_ONLY, не производственный допуск | Input completeness отдельно; INVALID: нет card; STALE: genuine freshness card; UNAVAILABLE: нет card; DRAFT_PLAN_VALID/PARTIAL/MISSING | Повтор output dir запрещён; нет valid результата — соответствующего файла нет, причина указана | Exact text/locales, existing read_plan; input/source digests; statusNOT_ASSESSED и false permissions | Только прежние семь top-level keys. Нельзя внести research Question/Angle как новые поля; не упаковывать скрытый JSON в topic/audience |

**M05 — потенциальная граница, не действующий SI writer.** В первом варианте 02.3.1
без supplied SI frame путь M06–M08 остаётся NOT_RUN/NEEDS_INPUT, а досье полезно само
по себе. При supplied frame передать его значения неизменно. Human editor отдельно
согласует фактический SI Idea/Audience/Angle с research question; совпадение title/id
не доказывает семантическое соответствие. Нет автоматического metadata→SI mapping.
Нужна отдельная exact research snapshot↔frame привязка с рассмотрением полноты
correspondence (§5.1 контракта). До неё действительный результат относится только
к supplied SI view, не к текущему досье. Нельзя скрыть новые contradicting материалы
или объявить старый OK подтверждением нового исследования. Изменение snapshot
требует нового рассмотрения; genuine SI eligibility не переписывается.

## 4. Контрольная граница human findings

Три разных артефакта не склеиваются:

| Research output | Что необходимо до existing evaluator field | Что не заменяет действие |
|---|---|---|
| Предложенное rating/confidence/rationale | Явный editor choice всех девяти критериев по утверждённому RD-04=A; автоматический импорт model ratings запрещён; существующий Rating только с SI basis_refs | Авторитет модели, confidence=HIGH, непустая explanation, галочка “verified” |
| Critic считает uncertainty acceptable | Отдельное явное human SUFFICIENT/INSUFFICIENT для exact UNKNOWN-confidence Rating, если такое finding требуется | Текст критики, другой provider, “consensus” двух LLM |
| Список похожих тем/duplicate suggestions | Human DISTINCT/DUPLICATE/UNRESOLVED на всех exact Known local portfolio entries с index/hash/candidate binding | Короткий shortlist, поисковая похожесть, unknown portfolio как “уникально” |
| Недавняя source publication/capture | Явный required-current determination и отдельные source_freshness assessments/proof по RC | Дата сама по себе, clock TTL, “данные свежие” из model summary |
| ResearchClaim подтверждён/опровергнут в досье | Отдельный человеческий ClaimCheck на exact claim/evidence с полными metadata и допустимой provenance | Research state/подпись label/сгенерированные reviewer fields |
| Rights note или source hash | Отдельная применимая rights/usage проверка; production review всё равно вне scope | VERIFIED_EXTERNALLY из preview, quoted licence text, high visual score |

HumanFindingsInput не имеет reviewer identity/approval fields; нельзя добавить их
или переписать contract_tag. Scientific checklist completion и research dispositions
не имеют утверждённого machine mapping в эти findings. EVAL-P05 остаётся OPEN:
никакого Request/request_id/persistent replay embedding с новым контрактом.

## 5. Future independent test requirements — NOT_RUN

Это требования к будущему bounded task, не созданные/выполненные tests или vectors.
SI/1/source digests в fixtures должны быть настоящими и независимо проверенными;
real-human labels не берутся из синтетических mocks. Новые intake cases могут
использовать явно обозначенные synthetic данные для проверки структуры, не истины.

| ID | Сценарий | Проверяемый oracle |
|---|---|---|
| R-T01 | Полные manually supplied реальные metadata/fragment links | Traceable dossier без simulated search, без новых SI/authority states |
| R-T02 | Нет audience/question/части материалов или SI frame | NEEDS_INPUT только adapter-level; доступный research draft сохранён; evaluator NOT_RUN при отсутствии frame |
| R-T03 | URL записан, получение не выполнено; pointer без текста/bytes | Retrieval/content не продвинуты; нет claim “источник проверен”, gap видим |
| R-T04 | Source supports и independently contradicts central factual Claim | Оба точных основания сохранены; нет majority rule; при соответствующем supplied SI frame actual BLOCKED |
| R-T05 | Источник/фрагмент отсутствует либо неправильный ref/hash/cycle | Missing capture — gap; повреждённая заявленная exact ref — structural rejection, не STALE/ordinary uncertainty |
| R-T06 | Неизвестная publication/capture date либо только год/день | Нет вымышленной UTC/даты получения; coarse date сохранена; SI timestamp UNKNOWN если exact instant неизвестен |
| R-T07 | Одинаковые bytes/перепечатки и повторяющийся id | Нет ложной независимой corroboration; сохранять citations; конфликт id/revision/hash отклонить |
| R-T08 | MODEL_PROPOSED text принят человеком / изменён | Model ancestry остаётся; отдельно human decision; нет MANUAL_INPUT washing, фиктивного CREATIVE/REVISION run |
| R-T09 | Отсутствующая/не независимая критика | NOT_PERFORMED/NOT_ESTABLISHED, не положительный report; утверждённый RD-01=A: другой human critic каждой темы, без нового evaluator blocker |
| R-T10 | Critic/model выдаёт SUFFICIENT, DISTINCT или “source fresh” | Не конвертировать в human findings/premise; нужна отдельная explicit human consideration по точным bindings |
| R-T11 | UNKNOWN value/confidence, противоречивые оценки разных людей | UNKNOWN не0, не усреднение; initial proposals/labels сохранены; никаких второго score/new thresholds |
| R-T12 | Изменились source/claim/rating/context bytes | Новая exact версия/binding; старые review/evaluation не переносятся, no implicit latest/rebase |
| R-T13 | Supplied complete frame возвращает INVALID/STALE; Projection UNAVAILABLE | Фактические статусы неизменны; 02.2.2 INVALID без card, STALE поясняется, UNAVAILABLE без counterfeit Card |
| R-T14 | RU/UK display одного dossier / human translation/qualifiers | Fixed labels локализованы; исходный текст/оговорки не переписаны; перевод не независимый источник |
| R-T15 | URL credentials/private query, локальный путь, приватный текст в ошибке | Не network/open arbitrary paths и не echo в публичных диагностических сообщениях; private original отдельно |
| R-T16 | Source/prompt содержит инструкции запустить поиск/render/выдать approval | Только данные, не команды; нет provider/network/TTS/first_video.build даже render=False |
| R-T17 | High score/all reviews/material VERIFIED_EXTERNALLY | Нет scientific certification/rights clearance; production NOT_ASSESSED, grants false; нет WAV/MP4/publication |
| R-T18 | Обратная совместимость | Неизменённые 02.2.1 D1, 02.2.2, SI/evaluator/Projection/goldens проходят; никакого текущего runtime PASS этим документом |

## 6. Что остаётся недоступным

Нет live research/provider, автоматического SI conversion/operation persistence,
Topic Intent execution, машинного Scientific Review completion, durable SI-D03
workspace, ERef adapter, нового scoring/authority, render или production handoff.
Состояния нового research слоя не добавляются в EvaluationReport/Request/RunRecord.
RD-01–RD-04 закрыты выбором A. Нужны независимая приёмка 02.3.0 и отдельное
точное задание 02.3.1; регистрация решений не авторизует реализацию. **STOP / WAIT FOR INDEPENDENT REVIEW.**
