# SI-PRODUCT-02.3.0 — Owner Decisions

Дата решения владельца: **2026-11-16**.
**APPROVED / OWNER DECISION — RD-01–RD-04 ONLY, A/A/A/A.**

Основание — явное задание владельца SI-PRODUCT-02.3.0a, не вывод из рекомендации.
Точный исходный commit: `8b6c34103a557e68dfda7b56f5765bffc24a0d7d`, ветка
`docs/si-product-02-3-0-research-contract`.
Прежние NOT_APPROVED/default ожидания superseded **только для четырёх решений ниже**.
Выбор окончательный; повторное обсуждение A/B не требуется.

| Решение | Выбор | Статус |
|---|---|---|
| RD-01 | A | APPROVED |
| RD-02 | A | APPROVED |
| RD-03 | A | APPROVED |
| RD-04 | A | APPROVED |

[Контракт](SI_PRODUCT_02_3_0_RESEARCH_CONTRACT.md) и
[матрица](SI_PRODUCT_02_3_0_INTEGRATION_MATRIX.md) обновлены в этой узкой области.
Это не blanket approval всех Research* schemas, полей/enum/сериализации, benchmark
protocol/порогов, будущих adapters/providers, durable storage или реализации.
Остальные предложения сохраняют PROPOSAL / NOT APPROVED. Прежний
[RESULT 02.3.0](SI_PRODUCT_02_3_0_RESULT.md) — неизменённая история до этого решения;
актуальная регистрация — [APPROVAL_RESULT](SI_PRODUCT_02_3_0A_APPROVAL_RESULT.md).

## Уже принято — не выносится на повторное утверждение

SI-PRODUCT-02: реальные источники/получение/фрагменты, четыре разные роли, эталон
20–30 тем с человеческими оценками, human editorial decision, сохранение SI/evaluator/
Projection/Storage. SI-PRODUCT-01: private RU/UK Card, mandatory evaluator verification,
30 families, девять критериев/веса, no authority. SI/1/R1/R1a/R1b и EVAL/RC/Q:
Known/UNKNOWN, exact hashes/refs, provenance/currentness, blockers, human findings,
no washing, all applicable reasons. A14, D1 synthetic-only и PREVIEW_ONLY 02.2.2
не пересматриваются. SR-P01–04 уже требуют семь областей человеческого рассмотрения;
нового ScientificApproval быть не должно. Эти решения не требуют новых голосований.

## RD-01 — Когда и как обязательна независимая критика

**Статус: APPROVED / OWNER DECISION. RD-01 = A.**

- **A — УТВЕРЖДЕНО:** для каждой темы перед окончательной редакторской рекомендацией
  требуется отдельный короткий критический проход. В manual-first реализации
  независимым критиком выступает **другой человек**. Повторная проверка тем же
  человеком не считается независимой. Незавершённый intake разрешён; отсутствие
  критики остаётся видимым. Существенные научные и правовые разногласия эскалируются
  человеку. Это не разрешение agent/provider и не подтверждение scientific truth.
- **B — ИСТОРИЧЕСКИЙ ВАРИАНТ / НЕ ВЫБРАН:** обязательна только по explicit risk/trigger: contested/causal/scientific
  central claim, существенное counter-evidence, слабая traceability, sensational
  framing, essential rights/usage gap, неразрешённое disagreement. Отсутствие
  первичной разметки не должно становиться автоматическим “низкий риск”.
- Основание выбора A (из proposal): A меньше зависит от распознавания риска первым исследователем.
  Цена — дополнительный проход/редакторское время на каждую тему; B дешевле, но
  может пропускать неизвестные заранее проблемы. Численные затраты не измерены.
- Последствия: оформить отсутствие/independence/разногласия в досье; не менять
  evaluator eligibility или научные blockers. Возможность раннего incomplete intake
  сохраняется в утверждённом варианте A; “не было критики” не равно “критика пройдена”.
- RD-01 закрыт выбором A. Это не свидетельство выполненного критического прохода
  конкретной темы и не разрешение реализации 02.3.1; отдельный task всё ещё нужен.

## RD-02 — Минимальный evidence admission profile для исследовательского досье

**Статус: APPROVED / OWNER DECISION. RD-02 = A.**

- **A — УТВЕРЖДЕНО:** достаточность evidence рассматривается отдельно для каждого
  claim применительно к источнику, фрагменту, контексту, методу, периоду и ограничениям.
  Для спорных центральных или причинных утверждений необходимо рассмотреть
  независимое подтверждение либо явно обосновать его отсутствие и сохранить
  неопределённость. Количество URL не доказывает истинность; перепечатка не является
  независимым подтверждением. Общий source-count threshold не вводится.
- **B — ИСТОРИЧЕСКИЙ ВАРИАНТ / НЕ ВЫБРАН:** дополнительно требовать независимое corroboration для каждого central
  factual claim до положительного research recommendation; если её нет — продолжить
  intake, но оставить review gap. Исключения должен явным образом задать владелец.
- Основание A: применимость и качество важнее общего числа ссылок; не превращает
  source count в truth/scoring rule. B проще как checklist, но может исключать
  уникальные первичные свидетельства и увеличивать ручную работу.
- Последствия: новый profile описывает research admission/действия человека, не
  переписывает existing positive Check predicate, Q1/Q2 blockers и EVAL thresholds.
  Пять source axes раздельны; actual material bytes и reported digest не равны.
- RD-02 закрыт выбором A. Он не даёт automatic evidence verification или новых
  human findings; конкретное рассмотрение exact claim всё равно должно состояться.

## RD-03 — Первый исполняемый объём и граница SI/provider/persistence

**Статус: APPROVED / OWNER DECISION. RD-03 = A.**

- **A — УТВЕРЖДЕНО:** первый intake — локальный ручной ввод с приватным досье и
  snapshot export. Готовый EditorPreviewInputV1 может передаваться существующему
  02.2.2 **без изменения его схемы**. Без SI frame — только досье и действия редактора.
  Без проверенной correspondence нельзя утверждать, что SI evaluation охватывает
  текущее исследование; результат supplied frame показывается отдельно.
  Сеть, crawler, LLM provider, автоматический SI builder и authoritative storage
  **не разрешены**. Выбор scope не утверждает автоматически новые private wire schemas.
- **B — ИСТОРИЧЕСКИЙ ВАРИАНТ / НЕ ВЫБРАН:** потребовать ещё и новый SI builder/operation path до первого продукта.
  Тогда сначала отдельный closed provenance/operation/lifecycle contract и новое
  bounded задание; нельзя взять отсутствующий runtime из одного описания R1.
- Основание A: уже даёт полезный ввод реального исследования, не обходит SI-D03,
  SI-D09, закрытые H/stages/provider=null и EVAL-P05. B шире/дороже и задерживает intake.
- Последствия: A допускает future read-only/advisory orchestration, не обещает
  фактическую identity/source truth или автоматическое соответствие metadata SI-графу.
  Неподдержанные машинные outputs остаются research proposals; человеческое согласие
  не отмывает происхождение. Privacy/export ограничения 02.2.2 сохраняются.
- RD-03 закрыт выбором A. Scope выбран, но запуск кода ждёт отдельного задания;
  credentials, модели, поисковые API, durable/authoritative storage не разрешены.

## RD-04 — Admission предварительных ratings и человеческих обоснований

**Статус: APPROVED / OWNER DECISION. RD-04 = A.**

- **A — УТВЕРЖДЕНО:** на первом этапе preliminary ratings выбираются человеком;
  допускается UNKNOWN. Модельные предложения могут сохраняться отдельно с указанием
  происхождения, но не импортируются автоматически в SI ratings. Девять существующих
  критериев, веса, eligibility и human findings не изменяются. Генерация предложений
  через provider этим решением не разрешена.
- **B — ИСТОРИЧЕСКИЙ ВАРИАНТ / НЕ ВЫБРАН:** в будущем отдельно разрешённый агент может предлагать девять значений и
  explanations; **все девять** допускаемых ratings всё равно явно выбирает/рассматривает
  человек, proposals и human rationale хранятся раздельно с exact scope/provenance.
- Основание A: позволяет реализовать intake без нового provider contract. B может
  экономить первичную аналитическую работу, но повышает риск automation bias и цену
  проверки. Это не blanket permission LLM; SI-D09 требует отдельного approval.
- В утверждённом A: фиксированные 0..5/UNKNOWN/order/weights и единственный
  aggregate остаются existing evaluator. Никакого нового cutoff, среднего мнений,
  model-generated SUFFICIENT/DISTINCT/freshness или переименования proposal-1 tags.
- RD-04 закрыт выбором A. Автоматического admission модельных ratings нет;
  это не повторный выбор весов и не доказательство review конкретных входов.

## Не блокирует проектирование intake, но нужно до quality-claims

План 24 тем и метрики заданы [контрактом §9](SI_PRODUCT_02_3_0_RESEARCH_CONTRACT.md).
Размер 20–30 и необходимость human labels уже утверждены. Владельцу предстоит
назначить реальных независимых raters, определить holdout roster и заранее утвердить
численные критерии качества после изучения доступных данных. Сейчас labels, метрики,
стоимость и пороги — NOT_MEASURED/NOT_SET, не синтетический PASS. Это не повод
раздувать 02.3.1 или вводить ещё один evaluator/итоговый score.

## Gate после решений

RD-01–RD-04 окончательно закрыты выбором A; повторный выбор не требуется.
Регистрация не запускает код автоматически. Нужны независимая приёмка
02.3.0, публикация owner decision в согласованном порядке и отдельное задание
02.3.1 с точным base SHA, allowlist, fixtures/tests и критериями приёмки.
Документ регистрирует только четыре явно переданных owner decisions. Прочие
предложения и полная приёмка 02.3.0 автоматически не утверждены.
**02.3.1: BLOCKED_BY_DEPENDENCY. STOP / WAIT FOR INDEPENDENT REVIEW.**
