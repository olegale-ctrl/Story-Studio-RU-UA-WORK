"""Finalize only after real matrix completion. No network or remote Git writes."""
from pathlib import Path
import subprocess,json,hashlib,zipfile,re
R=Path('/workspace/work/si-product-02-2-2');E=Path('/workspace/artifacts/si-product-02-2-2')
BASE='6ecc263ff4eefd5d6c419c36f8ad215540a1e6a4';BRANCH='feat/si-product-02-2-2-editor-preview'
paths=['scripts/editor_preview.py','tests/test_editor_preview.py','examples/editor_input_example.json','examples/editor_input_incomplete.json','docs/tasks/SI_PRODUCT_02_2_2_RESULT.md','project-log/WORKLOG.md']
def g(*args):return subprocess.check_output(['git','-C',str(R),*args],text=True).strip()
def digest(b):return hashlib.sha256(b).hexdigest()
results=json.loads((E/'CHECK_RESULTS.json').read_text());assert len(results)==2 and all(len(group)==5 for group in results)
assert all(row['exit_code']==0 for group in results for row in group),'Do not claim READY with test failures'
assert g('rev-parse','HEAD')==BASE and g('branch','--show-current')==BRANCH
for path,sha in json.loads((E/'TESTED_SOURCE_HASHES.json').read_text()).items():assert digest((R/path).read_bytes())==sha,path
report=R/'docs/tasks/SI_PRODUCT_02_2_2_RESULT.md';text=report.read_text();rows=['Final actual execution on Linux (full commands/streams/exit metadata in the evidence ZIP):','','| Python | Check | Count | Failures/errors/skips | Exit | Wall seconds |','|---|---|---:|---|---:|---:|']
for group in results:
 for row in group:
  if row['label']=='environment':continue
  if row['label']=='pytest':
   stdout=(E/row['stdout']).read_text();counts={k:(int(m[1]) if (m:=re.search(r'(\d+) '+k,stdout)) else 0) for k in ('passed','failed','error','skipped')};assert not counts['failed'] and not counts['error']
   count=counts['passed'];stats=f"{counts['failed']}/{counts['error']}/{counts['skipped']}"
  elif row['label'] in ('target','unittest'):count=row['tests'];stats='/'.join(str(row[k]) for k in ('failures','errors','skipped'))
  else:count='n/a';stats='n/a'
  rows.append(f"| {row['version']} | {row['label']} | {count} | {stats} | {row['exit_code']} | {row['wall_seconds']:.3f} |")
subcounts={}
for group in results:
 for row in group:
  if row['label']=='pytest':
   match=re.search(r'(\d+) subtests passed',(E/row['stdout']).read_text())
   subcounts[row['version']]=int(match[1]) if match else 0
rows+=['','Additional executed pytest subtests (not added to the method/test counts): '+json.dumps(subcounts)+'.']
rows+=['','Commands (each venv Python separately):','','```text','python -m unittest tests.test_editor_preview tests.test_topic_to_video_d1 -v','python -m compileall -q scripts tests','python -m unittest discover -s tests -v','python -m pytest -q tests','git diff --check','```','','Python 310 = CPython 3.10.22; Python 313 = CPython 3.13.5. pytest 9.2.0; exact environment/package versions in the corresponding environment logs. Target count is 16 new + 3 unchanged D1 tests. Repeated full suites overlap and are not summed as unique tests. Both complete unittest and complete pytest ran on each Python version. No source changes after the frozen tested-source hash snapshot.','', 'Remote GitHub Actions: NOT_RUN. The existing workflow remains unchanged with Python 3.10/3.13 and both test commands. The local matching matrix above is compatibility evidence, not a claim of an executed GitHub job. No push or PR was performed.','', 'Final scoped diff checks and staged diff check passed (exit 0); exact six paths verified before commit. All existing source/contract/test files other than the append-only WORKLOG are unchanged. Final working tree is checked clean after local commit.']
text=text.replace('Final actual results are recorded below after the Python 3.10/3.13 matrix finishes.','\n'.join(rows));report.write_text(text,encoding='utf-8')
log=R/'project-log/WORKLOG.md';addition='''\n\n## 2026-11-16 — SI-PRODUCT-02.2.2 Editor Preview\n\n- Exact base `6ecc263ff4eefd5d6c419c36f8ad215540a1e6a4`; feature\n  `feat/si-product-02-2-2-editor-preview`. Added a local PREVIEW_ONLY editor JSON\n  adapter, real evaluator/Projection cards, independent exact RU/UK draft plans,\n  safe bilingual diagnostics and NOT_ASSESSED production state with no permissions.\n- Added two explicit synthetic/incomplete input examples and 16 new tests.\n  No fabricated SI inputs, translations, production project, render/TTS/network\n  calls or D1 permit use in the new adapter. Existing evaluator/Projection/SI/1,\n  Storage, A14, D1 and media code remain unchanged.\n- Actual Python 3.10.22 / 3.13.5 full unittest and pytest, new+D1 target tests,\n  syntax and diff results are recorded in `docs/tasks/SI_PRODUCT_02_2_2_RESULT.md`\n  and the external evidence logs. Local compatibility matrix; remote CI NOT_RUN.\n- Local commit and review archive only. No push/PR/merge/tag/release/main changes.\n  STOP for independent review; SI-PRODUCT-02.3 not started.\n'''
original_log=log.read_bytes()
assert '2026-11-16 — SI-PRODUCT-02.2.2' not in original_log.decode('utf-8')
assert original_log==subprocess.check_output(['git','-C',str(R),'show',BASE+':project-log/WORKLOG.md'])
with log.open('ab') as stream:stream.write(addition.encode('utf-8'))
assert log.read_bytes().startswith(original_log)
actual=set(g('ls-files','--others','--exclude-standard').splitlines())|set(g('diff','--name-only').splitlines());assert actual==set(paths),(actual,paths)
subprocess.run(['git','-C',str(R),'add','--',*paths],check=True)
subprocess.run(['git','-C',str(R),'diff','--cached','--check'],check=True)
assert set(g('diff','--cached','--name-only').splitlines())==set(paths)
subprocess.run(['git','-C',str(R),'commit','-m','feat: add preview-only editor input and bilingual draft plans'],check=True)
HEAD=g('rev-parse','HEAD');assert g('rev-parse','HEAD^')==BASE and not g('status','--porcelain=v1')
subprocess.run(['git','-C',str(R),'diff','--check',BASE,HEAD],check=True)
identity=dict(status='READY_FOR_INDEPENDENT_REVIEW',repository='olegale-ctrl/Story-Studio-RU-UA-WORK',branch=BRANCH,base_sha=BASE,commit_sha=HEAD,parent_sha=g('rev-parse','HEAD^'),tree_sha=g('rev-parse','HEAD^{tree}'),remote_ci='NOT_RUN',publication='LOCAL_ONLY',worktree_clean=True,files=[])
members={}
for p in paths:
 b=subprocess.check_output(['git','-C',str(R),'show',HEAD+':'+p]);blob=g('rev-parse',HEAD+':'+p)
 identity['files'].append(dict(path=p,git_blob_sha=blob,sha256=digest(b),bytes=len(b)));members['changed/'+p]=b
(E/'HANDOFF.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2)+'\n')
outputs=[]
for name in ('full-preview','incomplete-preview'):
 for p in sorted((E/name).iterdir()):
  assert p.suffix=='.json';b=p.read_bytes();outputs.append(dict(path=p.relative_to(E).as_posix(),bytes=len(b),sha256=digest(b)))
(E/'EXAMPLE_OUTPUTS_MANIFEST.json').write_text(json.dumps(outputs,indent=2)+'\n')
for p in sorted(E.rglob('*')):
 if p.is_file() and p.name not in ('editor-preview.zip','editor-preview.zip.sha256'):
  members['evidence/'+p.relative_to(E).as_posix()]=p.read_bytes()
manifest=[]
blobs={'changed/'+f['path']:f['git_blob_sha'] for f in identity['files']}
for name,b in sorted(members.items()):manifest.append(dict(path=name,bytes=len(b),sha256=digest(b),git_blob_sha=blobs.get(name)))
members['MANIFEST.json']=(json.dumps(dict(commit_sha=HEAD,base_sha=BASE,files=manifest,self_excluded=True),indent=2)+'\n').encode()
archive=E/'editor-preview.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in manifest:assert digest(z.read(row['path']))==row['sha256']
sha=digest(archive.read_bytes());(E/'editor-preview.zip.sha256').write_text(sha+'  editor-preview.zip\n')
assert not g('status','--porcelain=v1')
print(json.dumps(dict(identity=identity,archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=sha,diff_stat=g('diff','--stat',BASE,HEAD)),indent=2))
