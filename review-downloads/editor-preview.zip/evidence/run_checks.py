from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,json,time,os,sys,re,platform
ROOT=Path('/workspace/work/si-product-02-2-2');E=Path('/workspace/artifacts/si-product-02-2-2')
def check(version,python,label,tail):
 args=[python]+tail;start=time.time();env=os.environ.copy();env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None);env['PYTHONNOUSERSITE']='1';env['PATH']=str(Path(python).parent)+os.pathsep+env['PATH']
 with (E/f'{version}-{label}.stdout.log').open('wb') as o,(E/f'{version}-{label}.stderr.log').open('wb') as e:
  p=subprocess.run(args,cwd=ROOT,env=env,stdout=o,stderr=e)
 text=(E/f'{version}-{label}.stderr.log').read_text(errors='replace')+(E/f'{version}-{label}.stdout.log').read_text(errors='replace');m=re.search(r'Ran (\d+) tests? in ([\d.]+)s',text)
 v=dict(version=version,label=label,argv=args,exit_code=p.returncode,wall_seconds=time.time()-start,tests=int(m[1]) if m else None,stdout=f'{version}-{label}.stdout.log',stderr=f'{version}-{label}.stderr.log')
 if m:
  for key in ('failures','errors','skipped'):
   hit=re.search(key+r'=(\d+)',text);v[key]=int(hit[1]) if hit else 0
 if label=='pytest':
  hit=re.search(r'(\d+) passed',text);v['passed']=int(hit[1]) if hit else None
 (E/f'{version}-{label}.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True);return v

def suite(version):
 python=f'/workspace/work/editor-preview-venv{version}/bin/python'
 commands=[('environment',['-c','import sys,platform,json,importlib.metadata as m;print(json.dumps(dict(python=sys.version,os=platform.platform(),packages={d.metadata["Name"]:d.version for d in m.distributions()}),indent=2))']),('target',['-m','unittest','tests.test_editor_preview','tests.test_topic_to_video_d1','-v']),('compile',['-m','compileall','-q','scripts','tests']),('unittest',['-m','unittest','discover','-s','tests','-v']),('pytest',['-m','pytest','-q','tests'])]
 results=[]
 for label,tail in commands:
  r=check(version,python,label,tail);results.append(r)
  if r['exit_code'] and label in ('environment','target'):break
 return results
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(suite,('310','313')))
(E/'CHECK_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');sys.exit(int(any(r['exit_code'] for group in results for r in group)))
