# SI-PRODUCT-02.3.0 — Owner Decisions

Дата: 2026-11-16. **PROPOSAL / NOT APPROVED.**
У каждого решения начальное значение **NOT_APPROVED**. Рекомендация не становится
решением автоматически, по молчанию или после документационных проверок.
[Контракт](SI_PRODUCT_02_3_0_RESEARCH_CONTRACT.md) и
[матрица](SI_PRODUCT_02_3_0_INTEGRATION_MATRIX.md) действуют как предложения.

## Уже принято — не выносится на повторное утверждение

SI-PRODUCT-02: реальные источники/получение/фрагменты, четыре разные роли, эталон
20–30 тем с человеческими оценками, human editorial decision, сохранение SI/evaluator/
Projection/Storage. SI-PRODUCT-01: private RU/UK Card, mandatory evaluator verification,
30 families, девять критериев/веса, no authority. SI/1/R1/R1a/R1b и EVAL/RC/Q:
Known/UNKNOWN, exact hashes/refs, provenance/currentness, blockers, human findings,
no washing, all applicable reasons. A14, D1 synthetic-only и PREVIEW_ONLY 02.2.2
не пересматриваются. SR-P01–04 уже требуют семь областей человеческого рассмотрения;
нового ScientificApproval быть не должно. Эти решения не требуют новых голосований.

## RD-01 — Когда и как обязательна независимая критика

**Статус: PROPOSAL / NOT APPROVED. Default: NOT_APPROVED.**

- **A, рекомендуется:** отдельный короткий критический проход для каждой темы перед
  окончательной human-reviewable рекомендацией; для существенных научных/правовых
  разногласий и essential unsupported claims — escalation человеку. В manual-first
  scope отдельный human critic; тот же человек не маркируется независимым. Будущий
  agent pass отдельно, без заявления, что независимая сессия доказывает истину.
- **B:** обязательна только по explicit risk/trigger: contested/causal/scientific
  central claim, существенное counter-evidence, слабая traceability, sensational
  framing, essential rights/usage gap, неразрешённое disagreement. Отсутствие
  первичной разметки не должно становиться автоматическим “низкий риск”.
- Основание рекомендации: A меньше зависит от распознавания риска первым исследователем.
  Цена — дополнительный проход/редакторское время на каждую тему; B дешевле, но
  может пропускать неизвестные заранее проблемы. Численные затраты не измерены.
- Последствия: оформить отсутствие/independence/разногласия в досье; не менять
  evaluator eligibility или научные blockers. Возможность раннего incomplete intake
  сохраняется при обоих вариантах; “не было критики” не равно “критика пройдена”.
- Без решения: нельзя объявлять один режим обязательным/выполненным или переходить
  к реализации; 02.3.1 ждёт окончательный scope. Provider/network этим не разрешаются.

## RD-02 — Минимальный evidence admission profile для исследовательского досье

**Статус: PROPOSAL / NOT APPROVED. Default: NOT_APPROVED.**

- **A, рекомендуется:** claim-specific sufficiency. Exact source/fragment/context,
  доступная traceability, сведения о методе/периоде/ограничениях и отдельный human
  review; для contested/causal central claims отдельно рассмотреть независимую
  corroboration либо явно обосновать её отсутствие и оставить uncertainty/escalation.
  Наличие одного первичного документа не отвергается механически; mirror не второй source.
- **B:** дополнительно требовать независимое corroboration для каждого central
  factual claim до положительного research recommendation; если её нет — продолжить
  intake, но оставить review gap. Исключения должен явным образом задать владелец.
- Основание A: применимость и качество важнее общего числа ссылок; не превращает
  source count в truth/scoring rule. B проще как checklist, но может исключать
  уникальные первичные свидетельства и увеличивать ручную работу.
- Последствия: новый profile описывает research admission/действия человека, не
  переписывает existing positive Check predicate, Q1/Q2 blockers и EVAL thresholds.
  Пять source axes раздельны; actual material bytes и reported digest не равны.
- Без решения: нет утверждённого minimum-quality profile для 02.3.1, никаких
  автоматических “evidence sufficient”, semantic verification или новых human findings.

## RD-03 — Первый исполняемый объём и граница SI/provider/persistence

**Статус: PROPOSAL / NOT APPROVED. Default: NOT_APPROVED.**

- **A, рекомендуется:** принять предлагаемые private research структуры как основу
  manual local intake/dossier и explicit snapshot export в новый частный каталог.
  Опционально принимать **готовый** existing EditorPreviewInputV1/SI frame и вызывать
  неизменённый 02.2.2. Нет frame — честные dossier/actions, без вымышленной оценки.
  Без рассмотренной exact research↔SI correspondence результат supplied frame
  показывается отдельно, не как оценка полноты текущего досье.
  Research поля не добавляются в closed EditorPreviewInputV1. Нет material crawler,
  network/provider, automatic SI builder, authoritative/durable SI workspace.
- **B:** потребовать ещё и новый SI builder/operation path до первого продукта.
  Тогда сначала отдельный closed provenance/operation/lifecycle contract и новое
  bounded задание; нельзя взять отсутствующий runtime из одного описания R1.
- Основание A: уже даёт полезный ввод реального исследования, не обходит SI-D03,
  SI-D09, закрытые H/stages/provider=null и EVAL-P05. B шире/дороже и задерживает intake.
- Последствия: A допускает future read-only/advisory orchestration, не обещает
  фактическую identity/source truth или автоматическое соответствие metadata SI-графу.
  Неподдержанные машинные outputs остаются research proposals; человеческое согласие
  не отмывает происхождение. Privacy/export ограничения 02.2.2 сохраняются.
- Без решения: конкретный executable scope 02.3.1 не утверждён. Новые credentials,
  модели, поисковые API, формы durable storage или write authority не разрешаются.

## RD-04 — Admission предварительных ratings и человеческих обоснований

**Статус: PROPOSAL / NOT APPROVED. Default: NOT_APPROVED.**

- **A, рекомендуется для первого шага:** только вручную выбранные предварительные
  значения/UNKNOWN и обоснования; модельные предложения можно хранить как внешние
  явно помеченные данные, но не генерировать или автоматически импортировать в SI ratings.
- **B:** в будущем отдельно разрешённый агент может предлагать девять значений и
  explanations; **все девять** допускаемых ratings всё равно явно выбирает/рассматривает
  человек, proposals и human rationale хранятся раздельно с exact scope/provenance.
- Основание A: позволяет реализовать intake без нового provider contract. B может
  экономить первичную аналитическую работу, но повышает риск automation bias и цену
  проверки. Это не blanket permission LLM; SI-D09 требует отдельного approval.
- При обоих вариантах: фиксированные 0..5/UNKNOWN/order/weights и единственный
  aggregate остаются existing evaluator. Никакого нового cutoff, среднего мнений,
  model-generated SUFFICIENT/DISTINCT/freshness или переименования proposal-1 tags.
- Без решения: research ratings остаются неподтверждёнными proposals; автоматического
  admission нет. Это уточнение нового product bridge, не повторный выбор девяти весов.

## Не блокирует проектирование intake, но нужно до quality-claims

План 24 тем и метрики заданы [контрактом §9](SI_PRODUCT_02_3_0_RESEARCH_CONTRACT.md).
Размер 20–30 и необходимость human labels уже утверждены. Владельцу предстоит
назначить реальных независимых raters, определить holdout roster и заранее утвердить
численные критерии качества после изучения доступных данных. Сейчас labels, метрики,
стоимость и пороги — NOT_MEASURED/NOT_SET, не синтетический PASS. Это не повод
раздувать 02.3.1 или вводить ещё один evaluator/итоговый score.

## Gate после решений

Даже явный выбор RD-01–04 не запускает код автоматически. Нужны независимая приёмка
02.3.0, публикация owner decision в согласованном порядке и отдельное задание
02.3.1 с точным base SHA, allowlist, fixtures/tests и критериями приёмки.
Этот документ ничего не утверждает от имени владельца.
**02.3.1: BLOCKED_BY_DEPENDENCY. STOP / WAIT FOR INDEPENDENT REVIEW.**
