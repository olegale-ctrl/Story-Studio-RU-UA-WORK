# SI-PRODUCT-02.3.0 — Result

Дата: 2026-11-16. **READY_FOR_INDEPENDENT_REVIEW — DOCS ONLY.**
Новые research contracts и RD-01–RD-04: **PROPOSAL / NOT APPROVED**.
SI-PRODUCT-02.3.1: **BLOCKED_BY_DEPENDENCY**.

## Git identity и scope

- Repository: `olegale-ctrl/Story-Studio-RU-UA-WORK`.
- Branch: `docs/si-product-02-3-0-research-contract`.
- Exact base / parent: `e0a9f63640c147365b17f1fe9d3b8d4b5f23986b`.
- Result commit: commit, содержащий эти документы. Полный SHA после создания
  локального commit передаётся во внешнем HANDOFF и финальном сообщении:
  собственный SHA невозможно включить в bytes самого коммита без self-reference.
- Исходное дерево проверено чистым; незавершённого merge нет. Работа выполнена
  в отдельном worktree от exact base, без подстановки main или другой RFC-ветки.
- Зависимость 02.2.2 считается ACCEPTED по текущему явному owner task. Историческое
  pending-review wording её RESULT на базе не переписывается и не трактуется
  как разрешение дополнительного runtime/provider/production scope.

Изменены только:

1. [RESEARCH_CONTRACT](SI_PRODUCT_02_3_0_RESEARCH_CONTRACT.md) — новый файл.
2. [INTEGRATION_MATRIX](SI_PRODUCT_02_3_0_INTEGRATION_MATRIX.md) — новый файл.
3. [OWNER_DECISIONS](SI_PRODUCT_02_3_0_OWNER_DECISIONS.md) — новый файл.
4. Настоящий `SI_PRODUCT_02_3_0_RESULT.md` — новый файл.
5. [WORKLOG](../../project-log/WORKLOG.md) — только добавление записи, прежние bytes сохранены.

## Подготовлено

- Минимальный manual-first private intake/export proposal: ResearchSourceV1,
  ResearchClaimV1, ResearchCritiqueV1, TopicRecommendationV1 и их отдельные
  ResearchIntakeV1/ResearchDossierV1 контейнеры. Это не новые SI RecordTypes.
- Пять независимых source axes: link existence, retrieval, integrity, content,
  editor confirmation. URL, hash, quote и человеческий label не замещают друг друга.
- Source/claim/evidence/check correspondence без изменения SI/1; coarse dates,
  UNKNOWN и conflicts сохраняются; неподдержанное машинное происхождение остаётся
  в research. Нет model→verified Evidence/ClaimCheck/human findings преобразования.
- Отдельные Researcher, Independent Critic, deterministic evaluator и Human Editor;
  режим критики и practical evidence profile предложены, не утверждены.
- Девять существующих критериев в прежнем порядке/весах, единственный existing
  aggregate и все eligibility/validation/currentness boundaries без изменений.
- Точная матрица M01–M08, граница human findings и 18 future oracle requirements.
- План 24 различных benchmark topics в восьми стратах, independent human labels,
  source-family holdout и отдельные метрики качества. Labels/источники/цитаты,
  результаты качества, измерения стоимости и runtime golden vectors не созданы.

## Сверка с фактической архитектурой

Прочитаны обязательные owner decision, 02.2 integration map, 02.2.2 RESULT,
actual evaluator/Projection/editor_preview, SI schemas/header/provenance,
применимые SI/1/R1/R1a/R1b approvals, EVAL/RC/Q, Scientific Review и A14/D1.
Проверка опирается на код exact base, не только исторические proposals.

Установленные ограничения, отражённые в предложении:

1. `evaluate_si` возвращает plain dict OK/INVALID/STALE; **не** создаёт RunRecord
   или EvaluationReport. INVALID/STALE содержат null eligibility/aggregate.
2. Source/Evidence/ClaimCheck не содержат произвольных research fields. Date-only
   нельзя превращать в UTC timestamp; reported digest не verified material.
3. Native MODEL_DERIVED/provider путь сейчас недоступен; Source/Claim/Evidence/Check
   допускают truthful manual/import input и approved revision ancestry. Generic
   USER_IMPORT не разрешает отмывание известных machine origins.
4. Public SI operation runners/writer отсутствуют. Proposed mapping — граница,
   не доказательство уже реализованного RECORD_INPUT/REVISE_INPUT. Рекомендованный
   первый scope не требует имитации этих операций или synthetic SI графа.
5. EditorPreviewInputV1 имеет закрытые семь top-level keys; research dossier нельзя
   вложить новым полем или скрытым JSON в topic/audience. Preview сам вызывает
   evaluator и две Projection; передавать ему готовый result как новый input нельзя.
6. Supplied SI view не доказывает полноты нового research. До exact рассмотренной
   correspondence показывается отдельная оценка supplied context, не “досье оценено”.
   Новый counter-evidence не выбрасывается ради старого eligible результата.
7. Existing 02.2.2 не создаёт card при INVALID; STALE использует genuine freshness
   Card; UNAVAILABLE не имеет поддельной замены. Required-current/ERef/semantic
   versus audit ancestry и privacy boundaries сохраняются.
8. SR human checklist обязателен в approved scope, но machine completion mapping
   не утверждён. A14 editorial HANDOFF не production readiness; D1 разрешает лишь
   зарегистрированный synthetic test, не реальное исследование или его планы.

**Блокирующих противоречий между существующими approved contracts и предложенным
консервативным manual-first scope не обнаружено.** Отсутствующие provider/SI writer/
SR-machine/persistence механизмы не объявлены существующими. Широкая автоматическая
research→SI/provider реализация потребовала бы отдельного контракта; здесь она
явно недоступна. Поэтому документационный результат готов к независимому ревью,
а не к автоматическому началу кода.

## Проверки

- Exact base и чистота initial tree — проверены; отдельная docs branch от этой базы.
- API names/signatures, девять criteria/weights/order, поля Source/Evidence/Check и
  closure/provenance/currentness boundaries — статически сверены с actual Python AST/code.
- Все M01–M08 имеют input/output/ответственного/основание полномочий/states/refusal/
  проверки/compatibility; R-T01–R-T18 и RD-01–04 полны и уникальны.
- Новые policy/форматы помечены PROPOSAL; RD defaults NOT_APPROVED. Принятые
  SI/1/EVAL/Projection/продуктовые решения не выдаются за новые proposals.
- Локальные Markdown-ссылки и структура таблиц проверены; checklist/benchmark
  cases указаны как future requirements, не выполненные тесты.
- `git diff --check` / staged diff check — PASS, exit 0.
- Exact changed-file scope — четыре новых Markdown + append-only WORKLOG.
  Изменения кода/тестов/CI/зависимостей/утверждённых контрактов — отсутствуют.
- Unit tests / pytest / full suite / CI / native Windows: **NOT_RUN — DOCS ONLY**.
  Исторический CI 02.2.2 не заявляется новым test execution 02.3.0.
- После локального commit повторно проверяются exact parent, состав commit,
  чистота worktree и отсутствие изменений исходного implementation worktree.

## Открытые решения и STOP

RD-01: обязательность/independence/эскалация критики.
RD-02: concrete evidence quality admission profile.
RD-03: manual-first dossier + supplied frame или отдельный более широкий builder contract.
RD-04: manual-only initial ratings или future agent proposals с отдельным human admission.
Все четыре имеют варианты, рекомендацию, цену/последствия и default NOT_APPROVED.
Новые numerical quality thresholds/real raters ещё не заданы; это не второй scoring engine.

Никаких реальных исследований, модели/поиска, источников/дат/цитат/human labels
не сфабриковано. RU/UK и Windows CPU-only ограничения сохранены. Production/rights/
scientific authority не предоставлена; PUBLISH_REVISION DISABLED, partial COMMIT
reconstruction OFF; S3.2b остаётся BLOCKED_HOST_NOT_PROVIDED.

Только локальный commit. **Без push, PR, merge, tag, release или main changes.**
**STOP — WAIT FOR INDEPENDENT REVIEW. 02.3.1 не начинать.**
