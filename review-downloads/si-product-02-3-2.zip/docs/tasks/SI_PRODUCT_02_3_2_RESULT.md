# SI-PRODUCT-02.3.2 — Evidence & Critique — Manual-First MVP

Дата: 2026-11-16. **READY_FOR_INDEPENDENT_REVIEW.**
Объём: **PRIVATE_READ_ONLY_EVIDENCE_INVENTORY**, без scoring/authority.

## Identity

- Repository: `olegale-ctrl/Story-Studio-RU-UA-WORK`.
- Exact base / parent: `4deac1511165fb72a7496c3b82341c6da5786a77`.
- Branch: `feat/si-product-02-3-2-evidence-critique`.
- Owner authorization: полное задание 02.3.2, OWNER_AUTHORIZED_FOR_IMPLEMENTATION.
- Result SHA — commit, содержащий этот отчёт; полный SHA передаётся в HANDOFF.json
  архива и финальном сообщении, без self-reference в bytes самого commit.
- Source worktree был чистым, base существует, новая ветка создана от exact SHA.

## Изменения — ровно пять разрешённых путей

1. [scripts/evidence_critique.py](../../scripts/evidence_critique.py) — новый read-only API.
2. [tests/test_evidence_critique.py](../../tests/test_evidence_critique.py) — 20 новых tests.
3. [examples/evidence_critique_example.json](../../examples/evidence_critique_example.json) —
   воспроизводимый SYNTHETIC_ONLY пример: accepted dossier, actual status и actual report.
4. Этот RESULT.
5. [WORKLOG](../../project-log/WORKLOG.md) — только append, base prefix byte-exact.

Существующие source/test/schema/contracts/goldens/CI/dependencies не изменены.
ResearchIntakeV1, ResearchDossierV1, RRef/SHA, RD-01–04 и HIST-01=A сохранены.
Нового SI schema, operation, ERef adapter, persistence или scoring engine нет.
Новый отдельный EvidenceCritiqueReportV1 прямо предусмотрен §3 текущего задания;
он не расширяет закрытые intake/dossier/SI структуры и не объявляется принятым
контрактом до независимого ревью.

## API и проверка входа

```python
from scripts.evidence_critique import analyze
status, report = analyze(dossier, locale="ru")  # также "uk"
```

- Успех: `status={state:OK,diagnostics:[]}`, отдельный detached report.
- Отказ: `status={state:INVALID,diagnostics:[{code:INPUT_INVALID,action:{ru,uk}}]}`,
  `report=None`. Не частично положительный report и не repaired dossier.
- Типы/Unicode/глубина проверяются до deepcopy/serialization. Два дополнительных
  wrapper levels учитывают вложение accepted intake snapshot в dossier.
- Pinned `scripts.research_intake.intake` повторно проверяет полный input_snapshot:
  закрытую форму, exact refs/hashes, revisions/previous, fragments и HIST-01.
  Затем canonical bytes всего supplied dossier сравниваются с воспроизведённым
  dossier. Проверяются intake_sha256, diagnostics/actions, preview status,
  association, production state; внешнее `already_verified` не принимается.
- Optional supplied Preview повторяется настоящим существующим pure Preview,
  без доверия к сохранённым внешним evaluation/card claims и без обхода verifier.
- Это reproducible consistency, не подпись или доказательство фактического первого
  запуска intake, личности автора, получения bytes или смысловой полноты исследования.
- `locale` только ru/uk, без fallback. Controlled actions/limitations содержат обе
  локали; raw supplied quotes/notes не переводятся и не интерпретируются как команды.
  Поэтому один snapshot даёт одинаковые canonical report bytes для ru/uk.

## Новый отдельный output

Root fields: `schema_version=EvidenceCritiqueReportV1`, `purpose=RESEARCH_ONLY`,
`dossier_sha256`, `intake_sha256`, `claim_review`, `source_review`, `critique_review`,
`reused_materials`, `evidence_gaps`, `editor_actions`, `research_readiness`,
`production_state=NOT_ASSESSED`, `limitations`.

- Claim review: exact claim RRef, materiality/claim_kind Known unions, исходный
  verification_state, declared provenance/editor_review, все supporting,
  contradicting/contextual links, uncertainty и связанные gap entries.
- Source review: exact source RRef, provenance, пять observations без изменения их
  states, applicability_limits и fragment ids/presence states/reported material hashes.
- Critique review: exact critique/target refs, severity/delivery, declared independence,
  provenance/basis, исходные issue/counterargument/alternative и editor_action.
  `resolution_state=NOT_RECORDED`: в принятом input нет structured disposition.
  Текст «всё решено» не создаёт resolution. LOW/MEDIUM замечания тоже остаются видимыми.
- `reused_materials`: равные **заявленные** material hashes, exact source refs.
  Это кандидаты на общий материал, не независимые подтверждения и не доказанная
  byte identity: модуль не читает source files. Разные hashes/URLs не доказывают
  независимость. Старые revisions не становятся дополнительными подтверждениями.
- Gap: `{code,level:INPUT|REVIEW,section,record_refs[,fragment_id]}`.
  На валидном dossier refs точные. Повреждённые refs/hash/graph отклоняют весь вход,
  а не превращаются в обычный missing-evidence gap или partial positive report.
- Editor action: `{code,record_refs,action:{ru,uk}[,fragment_id]}`.
  Сначала все относящиеся к gaps действия в input order, затем всегда
  EDITOR_REVIEW_REQUIRED перед Topic Scoring. Нет автозапуска следующего этапа.
- Шесть обязательных limitations: recorded evidence не truth; labels не identity/
  completed verification; URLs/hashes не independence; snapshot не global completeness;
  report не SI evaluation/human findings/Topic Scoring permit; нет scientific,
  editorial, rights или production approval.

### Детерминированные advisory readiness rules

| Состояние | Проверяемое основание |
|---|---|
| NEEDS_INPUT | Есть INPUT gap: неизвестны topic wording/audience/question/angle; отсутствуют sources/claims/supporting; материал не retrieved; отсутствует точный текст и pointer либо fragments |
| NEEDS_REVIEW | INPUT gaps нет, но есть REVIEW gap: записанные observations/reviews/limits/uncertainty нуждаются в рассмотрении; противоречия, reused material; нет delivered independent human critique; HIGH/CRITICAL или UNKNOWN severity |
| READY_FOR_EDITOR_REVIEW | Нет этих inventory gaps; всё равно требуется отдельное решение редактора, все ограничения остаются |

Precedence: INPUT → REVIEW → READY, без баллов/численных thresholds, confidence
aggregation или изменения существующей eligibility. Проверки охватывают supplied
record set, не выбирают implicit latest и не заявляют текущую истину.

Для source review ожидаемые положительные **записанные** observations:
RESOLVED / RETRIEVED / BYTES_HASH_MATCHED / CONTEXT_REVIEW_REPORTED /
CONFIRMED_AS_RECORDED с basis/origin/exact material hash. HASH_REPORTED не повышается
до BYTES_HASH_MATCHED; исходное значение сохраняется и возникает review gap.
Неизвестные/непустые applicability_limits требуют рассмотрения без NLP-вывода об
их безвредности. Unknown authors/dates не заполняются; весь original остаётся в dossier.

Claim review учитывает declared review scope всех supplied links, unknown kind/
materiality/expectation/uncertainty и записанную потребность дальнейшего исследования.
Пустой supporting list отмечает отсутствие записанных оснований, не научную ложность.
Contradicting никогда не устраняются числом supporting entries или preliminary rating.

Independent critique проверяется только как consistency заявления: SEPARATE_HUMAN,
EDITOR_DECLARED, Known разные producer labels и basis; известный self-review
(включая совпадающий target reviewer label) и MODEL_PROPOSED не проходят этот check.
Это не authentication. UNKNOWN severity получает отдельный
CRITIQUE_SEVERITY_UNKNOWN, не превращается в HIGH. HIGH/CRITICAL требуют human review.
Разрешение замечаний не выдумывается. READY_FOR_EDITOR_REVIEW может содержать
LOW/MEDIUM notes с NOT_RECORDED resolution: это готовность **передать редактору**,
а не окончательное закрытие замечаний или разрешение Topic Scoring.

## Реальный пример вывода

Пример JSON содержит настоящий результат `analyze` над accepted synthetic dossier.
Ожидаемый status — OK; readiness — NEEDS_REVIEW. Сохранены точные claim/source/critique
refs, synthetic source limitations, original HIGH critique и NOT_RECORDED resolution.
Есть конкретные actions по source/claim/critique refs и финальное действие редактора.
Это не верифицированные исторические данные и не реальный независимый human review.

```python
import json
from scripts.evidence_critique import analyze
with open("examples/evidence_critique_example.json", encoding="utf-8") as stream:
    example = json.load(stream)  # только committed synthetic demonstration
status, report = analyze(example["dossier"], "uk")
assert status == example["status"]
assert report == example["report"]
```

Report private: exact RRefs/hashes и supplied critic text предназначены редактору,
не public Projection. Invalid status не раскрывает private input/paths/exception text.
Реальные исследовательские материалы в пример/архив/GitHub не помещались.

## Фактически выполненные проверки

Linux/Python 3.12.14, проектная `.venv`; новых зависимостей нет.

| Suite/check | Tests | Exit |
|---|---:|---:|
| evidence | 20 | 0 |
| intake | 29 | 0 |
| preview | 16 | 0 |
| full | 1205 | 0 |
| compileall | — | 0 |
| diff-check | — | 0 |

Все завершённые unit suites: failures=0, errors=0, skips=0, expectedFailure=0.
Команды (`python` = проектный `.venv/bin/python`):

```text
python -m unittest tests.test_evidence_critique -v
python -m unittest tests.test_research_intake -v
python -m unittest tests.test_editor_preview -v
python -m unittest discover -s tests -v
python -m compileall -q scripts/evidence_critique.py tests/test_evidence_critique.py
git diff --check
```

20 новых tests включают все сценарии §6: synthetic/full/incomplete, central claim
без supporting, contradictions, reused material, все пять source axes, fragment
capture gaps, missing/self/model/failed critique, HIGH/CRITICAL/UNKNOWN, unknown
values, SHA/RRef/snapshot corruption, external verified flags, detachment/determinism,
RU/UK, real optional Preview re-verification, ignored high ratings и prompt data.
Success paths используют настоящий intake/Preview, без mocked positive results.
Запрещённые socket/HTTP/subprocess/TTS/render/wave calls patch-to-raise и assert-not-called
в каждом новом test. Оригинальные source/test/golden files сохранены byte-exact.

Первый development full run остановлен SIGTERM (-15) для добавления обязательного
финального editor action; PASS ему не присваивался. Финальный full run выполнен на
замороженных source/test/example bytes; их hashes проверены перед упаковкой.
Full discovery включает старые D1 synthetic integration tests с временными
PROJECT/RENDER/VIDEO outputs. Это прежняя D1 regression, не запуск production или
research render из нового модуля. Временные медиа не входят в архив.

## Ограничения и STOP

Нет scientific/causal/credibility inference, новых claims/цитат/источников, нового
score или human findings. Preliminary ratings и optional SI eligibility не определяют
эту inventory readiness. Нет LLM/provider/network acquisition, material-file reads,
TTS/FFmpeg/production из analyze, persistence, rights clearance или reviewer authority.
Authenticity личности/bytes/review и semantic completeness требуют человека.
Нового blocking contract gap не найдено; существующие схемы не изменены.

Локальный implementation commit, полный список файлов/статистика и точные SHA —
в HANDOFF.json. Архив `si-product-02-3-2.zip`, SHA-256, результаты и logs передаются
в существующую ветку `artifacts/si-product-02-3-0-research-contract`, `review-downloads/`.
Только review artifacts публикуются. Нет PR/merge/tag/release/main changes.
PUBLISH_REVISION DISABLED; partial COMMIT reconstruction OFF; S3.2b не запускается.

**STOP — WAIT FOR INDEPENDENT REVIEW.**
