"""Private deterministic evidence inventory; no truth, score or production authority."""
from copy import deepcopy
from hashlib import sha256
from scripts import research_intake as intake

VERSION = 'EvidenceCritiqueReportV1'
ACTIONS = {
    'EDITOR_REVIEW_REQUIRED': ('Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.', 'Перед Topic Scoring передайте точний звіт редактору та розгляньте всі збережені зауваження; автоматичного допуску немає.'),
    'INPUT_INVALID': ('Восстановите точный dossier из принятого intake.', 'Відновіть точне досьє з прийнятого intake.'),
    'INPUT_MISSING': ('Предоставьте отсутствующие исследовательские данные.', 'Надайте відсутні дослідницькі дані.'),
    'EVIDENCE_MISSING': ('Добавьте точные основания утверждения; не заменяйте их рейтингом.', 'Додайте точні підстави твердження; не замінюйте їх рейтингом.'),
    'FRAGMENT_UNCONFIRMED': ('Получите точный фрагмент и отдельно рассмотрите его контекст.', 'Отримайте точний фрагмент і окремо розгляньте його контекст.'),
    'SOURCE_NOT_RETRIEVED': ('Получите материал вручную; URL не подтверждает получение.', 'Отримайте матеріал вручну; URL не підтверджує отримання.'),
    'SOURCE_REVIEW_MISSING': ('Отдельно рассмотрите основания пяти наблюдений и ограничения источника.', 'Окремо розгляньте підстави п’яти спостережень та обмеження джерела.'),
    'CLAIM_REVIEW_MISSING': ('Запишите рассмотрение точных материалов и неопределённости утверждения.', 'Запишіть розгляд точних матеріалів та невизначеності твердження.'),
    'CONTRADICTION_UNRESOLVED': ('Рассмотрите все контрдоказательства; не устраняйте их голосованием.', 'Розгляньте всі контрдокази; не усувайте їх голосуванням.'),
    'MATERIAL_REUSED': ('Установите происхождение общего материала; не считайте его независимым подтверждением.', 'Встановіть походження спільного матеріалу; не вважайте його незалежним підтвердженням.'),
    'CRITIQUE_NOT_PERFORMED': ('Получите отдельный критический разбор другим человеком.', 'Отримайте окремий критичний розбір іншою людиною.'),
    'CRITIQUE_INDEPENDENCE_UNKNOWN': ('Уточните независимость критика; labels не удостоверяют личность.', 'Уточніть незалежність критика; labels не засвідчують особу.'),
    'CRITIQUE_SEVERITY_UNKNOWN': ('Уточните серьёзность замечания; UNKNOWN не означает HIGH.', 'Уточніть серйозність зауваження; UNKNOWN не означає HIGH.'),
    'CRITIQUE_HIGH': ('Передайте существенные замечания человеку; сохраните разногласия.', 'Передайте суттєві зауваження людині; збережіть розбіжності.'),
}
LIMITATIONS = [
    ('Записанные основания не доказывают истинность утверждения.', 'Записані підстави не доводять істинність твердження.'),
    ('Labels и review states не удостоверяют личность или фактическое выполнение проверки.', 'Labels і review states не засвідчують особу або фактичне виконання перевірки.'),
    ('Разные URL и разные hashes не доказывают независимость источников.', 'Різні URL і різні hashes не доводять незалежність джерел.'),
    ('Readiness относится только к переданному snapshot, не к полноте исследования.', 'Readiness стосується лише переданого snapshot, а не повноти дослідження.'),
    ('Это не SI evaluation, human findings или разрешение Topic Scoring.', 'Це не SI evaluation, human findings або дозвіл Topic Scoring.'),
    ('Нет научного, редакционного, правового или производственного одобрения.', 'Немає наукового, редакційного, правового або виробничого схвалення.'),
]


def localized(pair):
    return dict(ru=pair[0], uk=pair[1])


def analyze(dossier: dict, locale: str = 'ru'):
    """Return (status, private report), or (controlled INVALID, None).

    Reproduce the accepted intake including optional real Preview; never trust an
    external 'validated' flag. No file/network/provider/production operations.
    Readiness is an inventory workflow label, never a quality/scoring threshold.
    """
    invalid = dict(state='INVALID', diagnostics=[dict(code='INPUT_INVALID', action=localized(ACTIONS['INPUT_INVALID']))])
    try:
        if type(locale) is not str or locale not in ('ru', 'uk'):
            return invalid, None
        # Two wrapper levels beyond the accepted intake snapshot's depth bound.
        intake.bounded(dossier, depth=-2)
        data = deepcopy(dossier)
        if type(data) is not dict or 'input_snapshot' not in data:
            return invalid, None
        status, files = intake.intake(data['input_snapshot'], locale)
        expected = files.get('dossier.json')
        if status['state'] == 'INVALID' or expected is None or intake.wire(data) != intake.wire(expected):
            return invalid, None
    except (ValueError, TypeError, UnicodeError, RecursionError, KeyError):
        return invalid, None

    snapshot = data['input_snapshot']
    sources = intake.value(snapshot['sources']) or []
    claims = intake.value(snapshot['claims']) or []
    critiques = intake.value(snapshot['critiques']) or []
    records = sources + claims + critiques
    index = {intake.ref_key(intake.record_ref(r)): r for r in records}
    gaps, actions = [], []

    def gap(code, level, section, refs=(), fragment_id=None):
        item = dict(code=code, level=level, section=section, record_refs=deepcopy(list(refs)))
        if fragment_id is not None:
            item['fragment_id'] = fragment_id
        if item not in gaps:
            gaps.append(item)
        action = dict(code=code, record_refs=deepcopy(list(refs)), action=localized(ACTIONS[code]))
        if fragment_id is not None:
            action['fragment_id'] = fragment_id
        if action not in actions:
            actions.append(action)

    for name in ('audience', 'research_question', 'proposed_angle'):
        if intake.value(snapshot[name]) is None:
            gap('INPUT_MISSING', 'INPUT', name)
    if intake.value(snapshot['topic']['wording']) is None:
        gap('INPUT_MISSING', 'INPUT', 'topic')
    if not sources:
        gap('INPUT_MISSING', 'INPUT', 'sources')
    if not claims:
        gap('INPUT_MISSING', 'INPUT', 'claims')

    source_reviews, materials = [], {}
    for source in sources:
        p, ref = source['payload'], intake.record_ref(source)
        h = intake.value(p['material_sha256'])
        if h is not None:
            materials.setdefault(h, []).append(ref)
        if p['checks']['retrieval']['state'] != 'RETRIEVED':
            gap('SOURCE_NOT_RETRIEVED', 'INPUT', 'sources', [ref])
        if h is None:
            gap('SOURCE_REVIEW_MISSING', 'REVIEW', 'sources', [ref])
        if not p['fragments']:
            gap('FRAGMENT_UNCONFIRMED', 'INPUT', 'sources', [ref])
        fragment_reviews = []
        for f in p['fragments']:
            present = intake.value(f['exact_text']) is not None or intake.value(f['pointer']) is not None
            if not present:
                gap('FRAGMENT_UNCONFIRMED', 'INPUT', 'sources', [ref], f['fragment_id'])
            elif intake.value(f['exact_text']) is None or h is None or intake.value(f['material_sha256']) != h:
                gap('FRAGMENT_UNCONFIRMED', 'REVIEW', 'sources', [ref], f['fragment_id'])
            fragment_reviews.append(dict(fragment_id=f['fragment_id'], exact_text_state=f['exact_text']['state'],
                pointer_state=f['pointer']['state'], material_sha256=deepcopy(f['material_sha256'])))
        positives = dict(link_existence='RESOLVED', retrieval='RETRIEVED', integrity='BYTES_HASH_MATCHED',
                         content='CONTEXT_REVIEW_REPORTED', editor_confirmation='CONFIRMED_AS_RECORDED')
        for name, positive in positives.items():
            o = p['checks'][name]
            if (o['state'] != positive or intake.value(o['basis']) is None
                    or intake.value(o['origin']) is None or h is None
                    or intake.value(o['reviewed_material_sha256']) != h
                    or (name == 'editor_confirmation' and intake.value(o['origin']) != 'EDITOR_DECLARED')):
                gap('SOURCE_REVIEW_MISSING', 'REVIEW', 'sources', [ref])
        if intake.value(p['applicability_limits']) is None or intake.value(p['applicability_limits']):
            # Supplied limitations require consideration; no NLP inference that they are harmless.
            gap('SOURCE_REVIEW_MISSING', 'REVIEW', 'sources', [ref])
        source_reviews.append(dict(source_ref=ref, provenance=deepcopy(source['provenance']),
            observations=deepcopy(p['checks']), applicability_limits=deepcopy(p['applicability_limits']),
            fragments=fragment_reviews))
    reused = []
    for h, refs in materials.items():
        # Revisions of the same source do not become extra independent sources either.
        if len(refs) > 1:
            reused.append(dict(material_sha256=h, source_refs=deepcopy(refs)))
            gap('MATERIAL_REUSED', 'REVIEW', 'sources', refs)

    claim_reviews = []
    for claim in claims:
        p, ref = claim['payload'], intake.record_ref(claim)
        before = len(gaps)
        if not p['supporting']:
            gap('EVIDENCE_MISSING', 'INPUT', 'claims', [ref])
        if p['contradicting'] or p['verification_state'] == 'DISAGREEMENT_RECORDED':
            gap('CONTRADICTION_UNRESOLVED', 'REVIEW', 'claims', [ref])
        review = intake.value(p['editor_review'])
        links = p['supporting'] + p['contradicting'] + p['contextual']
        reviewed = {intake.wire(r) for r in review['reviewed_source_refs']} if review else set()
        if (p['verification_state'] != 'EDITOR_REVIEW_RECORDED' or review is None
                or any(intake.wire(link['source_ref']) not in reviewed for link in links)
                or p['uncertainty']['level'] == 'UNKNOWN' or intake.value(p['uncertainty']['reasons']) is None
                or intake.value(p['claim_kind']) is None or intake.value(p['materiality']) is None
                or intake.value(p['evidence_expectation']) is None or p['further_research']['needed'] != 'NO'):
            gap('CLAIM_REVIEW_MISSING', 'REVIEW', 'claims', [ref])
        for link in links:
            source = index[intake.ref_key(link['source_ref'])]['payload']
            f = next(x for x in source['fragments'] if x['fragment_id'] == link['fragment_id'])
            if intake.value(f['exact_text']) is None or intake.value(f['material_sha256']) is None:
                gap('FRAGMENT_UNCONFIRMED', 'REVIEW', 'claims', [ref, link['source_ref']], f['fragment_id'])
        claim_reviews.append(dict(claim_ref=ref, materiality=deepcopy(p['materiality']),
            claim_kind=deepcopy(p['claim_kind']), verification_state=p['verification_state'],
            provenance=deepcopy(claim['provenance']), editor_review=deepcopy(p['editor_review']),
            supporting=deepcopy(p['supporting']), contradicting=deepcopy(p['contradicting']),
            contextual=deepcopy(p['contextual']), uncertainty=deepcopy(p['uncertainty']), gaps=deepcopy(gaps[before:])))

    critique_reviews = []
    delivered = False
    for critique in critiques:
        p, ref = critique['payload'], intake.record_ref(critique)
        target = index[intake.ref_key(p['target'])]
        critic = intake.value(critique['provenance']['producer_label'])
        researcher = intake.value(target['provenance']['producer_label'])
        target_review = intake.value(target['payload']['editor_review'])
        independent_declaration = (p['independence'] == 'SEPARATE_HUMAN'
            and critique['provenance']['kind'] == 'EDITOR_DECLARED'
            and critic is not None and researcher is not None and critic != researcher
            and (target_review is None or critic != target_review['reviewer_label'])
            and intake.value(p['independence_basis']) is not None)
        delivered_here = (p['delivery'] == 'DELIVERED' and intake.value(p['checklist_notes']) is not None
            and any(intake.value(p[x]) is not None for x in ('issue','counterargument','alternative')))
        delivered = delivered or delivered_here
        if not delivered_here:
            gap('CRITIQUE_NOT_PERFORMED', 'REVIEW', 'critiques', [ref, p['target']])
        if not independent_declaration:
            gap('CRITIQUE_INDEPENDENCE_UNKNOWN', 'REVIEW', 'critiques', [ref, p['target']])
        if p['severity'] in ('HIGH','CRITICAL'):
            gap('CRITIQUE_HIGH', 'REVIEW', 'critiques', [ref, p['target']])
        elif p['severity'] == 'UNKNOWN':
            gap('CRITIQUE_SEVERITY_UNKNOWN', 'REVIEW', 'critiques', [ref, p['target']])
        # There is no accepted disposition/resolution field. Never infer resolution from prose.
        critique_reviews.append(dict(critique_ref=ref, target=deepcopy(p['target']),
            severity=p['severity'], delivery=p['delivery'], declared_independence=p['independence'],
            provenance=deepcopy(critique['provenance']), independence_basis=deepcopy(p['independence_basis']),
            unresolved_issues={x:deepcopy(p[x]) for x in ('issue','counterargument','alternative')},
            resolution_state='NOT_RECORDED', editor_action=p['editor_action']))
    if not delivered:
        gap('CRITIQUE_NOT_PERFORMED', 'REVIEW', 'critiques')
    actions.append(dict(code='EDITOR_REVIEW_REQUIRED', record_refs=[], action=localized(ACTIONS['EDITOR_REVIEW_REQUIRED'])))
    readiness = ('NEEDS_INPUT' if any(g['level']=='INPUT' for g in gaps)
                 else 'NEEDS_REVIEW' if gaps else 'READY_FOR_EDITOR_REVIEW')
    report = dict(schema_version=VERSION, purpose='RESEARCH_ONLY', dossier_sha256=sha256(intake.wire(data)).hexdigest(),
        intake_sha256=data['intake_sha256'], claim_review=claim_reviews, source_review=source_reviews,
        critique_review=critique_reviews, reused_materials=reused, evidence_gaps=gaps,
        editor_actions=actions, research_readiness=readiness, production_state='NOT_ASSESSED',
        limitations=[localized(x) for x in LIMITATIONS])
    return dict(state='OK', diagnostics=[]), report
