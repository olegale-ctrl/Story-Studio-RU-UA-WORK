"""Manual-first RESEARCH_ONLY intake; private snapshots, no acquisition or authority.

CLI: python -m scripts.research_intake --input PATH --out-dir PATH --locale ru|uk
HIST-01=A excludes revised recommendations and recommendation-targeted critiques.
All human/tool/model labels are declarations, never authenticated observations.
"""
import argparse
from copy import deepcopy
from datetime import date, datetime
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import stat
import sys
from urllib.parse import urlsplit

from scripts import editor_preview
from story_intelligence.model_v1 import validate_si_ref, SIValidationError
from story_intelligence.records_v1 import si_record_ref

MAX_BYTES = 2 * 1024 * 1024
MAX_DEPTH = 64
TYPES = ('ResearchSourceV1', 'ResearchClaimV1', 'ResearchCritiqueV1', 'TopicRecommendationV1')
CRITERIA = ('audience_interest', 'channel_fit', 'angle_novelty', 'evidence_quality',
            'narrative_potential', 'visual_feasibility', 'resource_fit',
            'risk_manageability', 'portfolio_distinctness')
FIELDS = {'schema_version', 'purpose', 'topic', 'audience', 'research_question',
          'proposed_angle', 'sources', 'claims', 'critiques', 'preliminary_assessments',
          'recommendation', 'editor_notes', 'existing_preview_input', 'evaluation_correspondence'}
# Closed, bilingual actions; no user text, URLs, paths, labels or exception messages.
TEXT = {
    'INPUT_MISSING': ('Дополните неизвестные сведения; не подставляйте предположения.', 'Доповніть невідомі відомості; не підставляйте припущення.'),
    'INPUT_INVALID': ('Исправьте структуру, точные ссылки или неподдерживаемую историю.', 'Виправте структуру, точні посилання або непідтримувану історію.'),
    'SOURCE_NOT_RETRIEVED': ('Получите материал вручную; ссылка не доказывает получение.', 'Отримайте матеріал вручну; посилання не доводить отримання.'),
    'FRAGMENT_MISSING': ('Уточните точный фрагмент и его контекст.', 'Уточніть точний фрагмент та його контекст.'),
    'SOURCE_REVIEW_MISSING': ('Проверьте материал, основания наблюдений и ограничения отдельно.', 'Перевірте матеріал, підстави спостережень та обмеження окремо.'),
    'CLAIM_REVIEW_MISSING': ('Рассмотрите доказательства и неопределённость каждого утверждения.', 'Розгляньте докази та невизначеність кожного твердження.'),
    'CONTRADICTION_UNRESOLVED': ('Сохраните противоречия; передайте разногласия человеку.', 'Збережіть суперечності; передайте розбіжності людині.'),
    'CRITIQUE_NOT_PERFORMED': ('До окончательной рекомендации получите отдельный разбор другим человеком.', 'До остаточної рекомендації отримайте окремий розбір іншою людиною.'),
    'CRITIQUE_INDEPENDENCE_UNKNOWN': ('Отдельно установите независимость критика; повторный self-review не независим.', 'Окремо встановіть незалежність критика; повторний self-review не незалежний.'),
    'SI_BRIDGE_UNAVAILABLE': ('При необходимости предоставьте готовый SI frame; досье само по себе не оценка SI.', 'За потреби надайте готовий SI frame; досьє саме по собі не оцінка SI.'),
    'SCOPE_UNVERIFIED': ('Рассмотрите точное соответствие исследования и SI; текущий охват не доказан.', 'Розгляньте точну відповідність дослідження та SI; поточне охоплення не доведено.'),
    'EVALUATION_INVALID': ('Исправьте SI frame; результат не подтверждает исследование.', 'Виправте SI frame; результат не підтверджує дослідження.'),
    'EVALUATION_STALE': ('Явно согласуйте актуальные SI-данные и повторите оценку.', 'Явно узгодьте актуальні SI-дані та повторіть оцінювання.'),
    'PROJECTION_UNAVAILABLE': ('Карточка недоступна; не заменяйте её вымышленной оценкой.', 'Картка недоступна; не замінюйте її вигаданою оцінкою.'),
}


class IntakeError(ValueError):
    """Only controlled sections are exposed; never include input values."""
    def __init__(self, section='input'):
        self.section = section
        super().__init__('INPUT_INVALID')


def wire(value):
    """Exact Unicode, sorted keys, compact UTF-8; input must first pass bounds."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def bounded(value, depth=0):
    if depth > MAX_DEPTH:
        raise IntakeError()
    if type(value) is dict:
        for k, v in value.items():
            if type(k) is not str:
                raise IntakeError()
            k.encode('utf-8')
            bounded(v, depth + 1)
    elif type(value) is list:
        for v in value:
            bounded(v, depth + 1)
    elif type(value) is str:
        value.encode('utf-8')
    elif value is not None and type(value) is not bool and not (type(value) is int and value.bit_length() <= 64):
        raise IntakeError()


def digest(value):
    bounded(value)
    return sha256(wire(value)).hexdigest()


def obj(value, fields, section):
    if type(value) is not dict or set(value) != set(fields):
        raise IntakeError(section)


def text(value, section):
    if type(value) is not str or not value.strip():
        raise IntakeError(section)


def enum(*choices):
    def check(v, p):
        if type(v) is not str or v not in choices:
            raise IntakeError(p)
    return check


def integer(v, p):
    if type(v) is not int or not 0 <= v <= 5:
        raise IntakeError(p)


def pattern(expr):
    def check(v, p):
        if type(v) is not str or re.fullmatch(expr, v) is None:
            raise IntakeError(p)
    return check


hash_value = pattern(r'[0-9a-f]{64}')
uuid = pattern(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')


def utc(v, p):
    pattern(r'[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z')(v, p)
    try:
        datetime.strptime(v, '%Y-%m-%dT%H:%M:%SZ')
    except ValueError:
        raise IntakeError(p) from None


def date_value(v, p):
    obj(v, ('precision', 'value'), p)
    enum('YEAR', 'DATE', 'INSTANT')(v['precision'], p)
    try:
        if v['precision'] == 'YEAR':
            pattern(r'[0-9]{4}')(v['value'], p)
            date(int(v['value']), 1, 1)
        elif v['precision'] == 'DATE':
            pattern(r'[0-9]{4}-[0-9]{2}-[0-9]{2}')(v['value'], p)
            date.fromisoformat(v['value'])
        else:
            utc(v['value'], p)
    except (ValueError, TypeError):
        raise IntakeError(p) from None


def known(check):
    def validate(v, p):
        if type(v) is not dict:
            raise IntakeError(p)
        if v.get('state') == 'UNKNOWN':
            obj(v, ('state', 'reason'), p)
            text(v['reason'], p)
        elif v.get('state') == 'KNOWN':
            obj(v, ('state', 'value'), p)
            check(v['value'], p)
        else:
            raise IntakeError(p)
    return validate


def many(check, limit=2000):
    def validate(v, p):
        if type(v) is not list or len(v) > limit:
            raise IntakeError(p)
        for i, item in enumerate(v):
            check(item, p + f'[{i}]')
    return validate


def shape(**fields):
    def validate(v, p):
        obj(v, fields, p)
        for name, check in fields.items():
            check(v[name], p + '.' + name)
    return validate


def rref(*allowed):
    return shape(research_type=enum(*(allowed or TYPES)), id=uuid,
                 revision=lambda v, p: positive(v, p), content_sha256=hash_value)


def positive(v, p):
    if type(v) is not int or v < 1:
        raise IntakeError(p)


def optional_ref(v, p):
    if v is not None:
        rref()(v, p)


def si_ref(v, p):
    try:
        validate_si_ref(v)
    except SIValidationError:
        raise IntakeError(p) from None


def locator(v, p):
    obj(v, ('kind', 'value'), p)
    enum('URL', 'LOCAL_ID')(v['kind'], p)
    text(v['value'], p)
    if v['kind'] == 'URL':
        try:
            u = urlsplit(v['value'])
            if (u.scheme not in ('http', 'https') or not u.hostname or u.username is not None
                    or u.password is not None or any(ord(c) <= 32 for c in v['value'])):
                raise IntakeError(p)
            _ = u.port
        except ValueError:
            raise IntakeError(p) from None


def observation(*states):
    return shape(state=enum(*states), basis=known(text), reviewed_material_sha256=known(hash_value),
                 origin=known(enum('EDITOR_DECLARED', 'TOOL_OBSERVED')))


AXES = {
    'link_existence': ('NOT_CHECKED', 'RESOLVED', 'NOT_RESOLVED'),
    'retrieval': ('NOT_RETRIEVED', 'RETRIEVED', 'FAILED'),
    'integrity': ('NOT_STORED', 'HASH_REPORTED', 'BYTES_HASH_MATCHED'),
    'content': ('NOT_REVIEWED', 'FRAGMENT_MATCH_REPORTED', 'CONTEXT_REVIEW_REPORTED'),
    'editor_confirmation': ('NOT_REVIEWED', 'CONFIRMED_AS_RECORDED', 'CONTESTED'),
}
CONFIDENCE = shape(level=enum('LOW', 'MEDIUM', 'HIGH', 'UNKNOWN'), basis=text)
LINK = shape(source_ref=rref('ResearchSourceV1'), fragment_id=text, relation_reason=text)
CONTEXT_LINK = shape(source_ref=rref('ResearchSourceV1'), fragment_id=text,
                     relation_reason=text, relation=enum('context', 'insufficient'))
FRAGMENT = shape(fragment_id=text, exact_text=known(text), pointer=known(text), material_sha256=known(hash_value))
PROVENANCE = shape(kind=enum('EDITOR_DECLARED', 'TOOL_OBSERVED', 'MODEL_PROPOSED'),
                   producer_label=known(text), method_label=known(text), upstream_refs=many(rref()))
REASON = shape(text=text, basis_claim_refs=many(rref('ResearchClaimV1')),
               kind=enum('FACTUAL_CONCLUSION', 'INTERPRETATION', 'RESEARCH_GAP'))
PROPOSAL = shape(text=text, basis_claim_refs=many(rref('ResearchClaimV1')),
                 label=enum('CREATIVE_PROPOSAL'), limitations=many(text))
PAYLOADS = {
    'ResearchSourceV1': shape(title=known(text), author=known(text), organization=known(text),
        locator=locator, published_at=known(date_value), retrieved_at=known(utc),
        material_sha256=known(hash_value), source_type=known(enum('PRIMARY_DOCUMENT',
            'RESEARCH_PUBLICATION', 'DATASET', 'INSTITUTIONAL', 'REPORTING', 'PERSONAL_ACCOUNT', 'OTHER')),
        fragments=many(FRAGMENT), applicability_limits=known(many(text)),
        checks=shape(**{name: observation(*states) for name, states in AXES.items()})),
    'ResearchClaimV1': shape(statement=text, research_question=text,
        claim_kind=known(enum('factual', 'interpretation', 'fictional')),
        materiality=known(enum('CENTRAL', 'SUPPORTING', 'CONTEXT')), evidence_expectation=known(text),
        supporting=many(LINK), contradicting=many(LINK), contextual=many(CONTEXT_LINK),
        verification_state=enum('NOT_REVIEWED', 'EDITOR_REVIEW_RECORDED', 'DISAGREEMENT_RECORDED', 'WITHDRAWN_FROM_DRAFT'),
        uncertainty=shape(level=enum('LOW', 'MEDIUM', 'HIGH', 'UNKNOWN'), reasons=known(many(text))),
        further_research=shape(needed=enum('YES', 'NO', 'UNDETERMINED'), actions=many(text)),
        editor_review=known(shape(reviewer_label=text, reviewed_at=known(utc), reason=text,
                                  reviewed_source_refs=many(rref('ResearchSourceV1'))))),
    'ResearchCritiqueV1': shape(target=rref('ResearchClaimV1'), issue=known(text), counterargument=known(text),
        alternative=known(text), evidence_links=many(LINK), severity=enum('LOW', 'MEDIUM', 'HIGH', 'CRITICAL', 'UNKNOWN'),
        editor_action=text, delivery=enum('NOT_PERFORMED', 'DELIVERED', 'FAILED'),
        independence=enum('NOT_ESTABLISHED', 'SEPARATE_HUMAN', 'SEPARATE_RUN_SAME_PROVIDER', 'SEPARATE_PROVIDER'),
        independence_basis=known(text), checklist_notes=known(text)),
    'TopicRecommendationV1': shape(research_snapshot_refs=many(rref(*TYPES[:3])),
        prospect=enum('RESEARCH_MORE', 'EDITOR_REVIEW', 'DEFER_PROPOSAL', 'DO_NOT_DEVELOP_PROPOSAL'),
        reasons=many(REASON), audience=known(text), main_angle=known(text), alternative_angles=many(PROPOSAL),
        emotional_hooks=many(PROPOSAL), intellectual_hooks=many(PROPOSAL), narrative_potential=known(text),
        visual_needs=many(text), scientific_risks=many(REASON), editorial_risks=many(REASON),
        production_limits=known(many(text)), gaps=many(text), next_actions=many(text),
        evaluation_binding=known(hash_value), production_state=enum('NOT_ASSESSED')),
}
ASSESSMENT = shape(criterion_key=enum(*CRITERIA), proposed_value=known(integer), basis_refs=many(rref()),
    rationale=text, confidence=CONFIDENCE, origin=enum('EDITOR_DECLARED', 'MODEL_PROPOSED'),
    editor_choice=known(shape(chosen_value=known(integer), reason=text, reviewer_label=text,
                              reviewed_at=known(utc), reviewed_refs=many(rref()))))
CORRESPONDENCE = shape(research_snapshot_refs=many(rref()), evaluation_inputs_sha256=hash_value,
    correspondence=many(shape(research_ref=rref(), si_ref=si_ref)), editor_scope_note=text)


def record(v, p, expected):
    obj(v, ('schema_version', 'id', 'revision', 'previous', 'provenance', 'payload'), p)
    enum(expected)(v['schema_version'], p)
    uuid(v['id'], p)
    positive(v['revision'], p)
    optional_ref(v['previous'], p + '.previous')
    if (v['revision'] == 1) != (v['previous'] is None):
        raise IntakeError(p + '.previous')
    if expected == 'TopicRecommendationV1' and v['revision'] != 1:
        raise IntakeError('recommendation.unsupported_history')
    PROVENANCE(v['provenance'], p + '.provenance')
    if (expected == 'ResearchCritiqueV1' and type(v['payload']) is dict
            and type(v['payload'].get('target')) is dict
            and v['payload']['target'].get('research_type') == 'TopicRecommendationV1'):
        raise IntakeError('critiques.unsupported_history')
    PAYLOADS[expected](v['payload'], p + '.payload')
    if expected == 'ResearchSourceV1':
        ids = [f['fragment_id'] for f in v['payload']['fragments']]
        if len(ids) != len(set(ids)):
            raise IntakeError(p + '.payload.fragments')
        material = value(v['payload']['material_sha256'])
        if material is not None and any(value(f['material_sha256']) not in (None, material)
                                        for f in v['payload']['fragments']):
            raise IntakeError(p + '.payload.fragments')


def ref_key(r):
    return r['research_type'], r['id'], r['revision']


def record_ref(v):
    return dict(research_type=v['schema_version'], id=v['id'], revision=v['revision'], content_sha256=digest(v))


def refs(v):
    if type(v) is dict:
        if set(v) == {'research_type', 'id', 'revision', 'content_sha256'}:
            yield v
        else:
            for x in v.values():
                yield from refs(x)
    elif type(v) is list:
        for x in v:
            yield from refs(x)


def value(v):
    return v['value'] if v['state'] == 'KNOWN' else None


def validate(data):
    # Reject oversized section counts before walking or hashing individual records.
    if type(data) is dict:
        for name, limit in (('sources', 100), ('claims', 200), ('critiques', 200),
                            ('preliminary_assessments', 9)):
            section = data.get(name)
            if type(section) is dict and type(section.get('value')) is list and len(section['value']) > limit:
                raise IntakeError(name)
        if type(data.get('editor_notes')) is list and len(data['editor_notes']) > 200:
            raise IntakeError('editor_notes')
    bounded(data)
    if len(wire(data)) > MAX_BYTES:
        raise IntakeError()
    obj(data, FIELDS, 'input')
    enum('ResearchIntakeV1')(data['schema_version'], 'schema_version')
    enum('RESEARCH_ONLY')(data['purpose'], 'purpose')
    shape(id=uuid, wording=known(text), source_locale=enum('ru', 'uk'))(data['topic'], 'topic')
    for name in ('audience', 'research_question', 'proposed_angle'):
        known(text)(data[name], name)
    many(text, 200)(data['editor_notes'], 'editor_notes')
    records = []
    for field, kind, limit in [('sources', TYPES[0], 100), ('claims', TYPES[1], 200), ('critiques', TYPES[2], 200)]:
        known(many(lambda v, p: record(v, p, kind), limit))(data[field], field)
        records.extend(value(data[field]) or [])
    known(lambda v, p: record(v, p, TYPES[3]))(data['recommendation'], 'recommendation')
    if value(data['recommendation']) is not None:
        records.append(value(data['recommendation']))
    known(many(ASSESSMENT, 9))(data['preliminary_assessments'], 'preliminary_assessments')
    ratings = value(data['preliminary_assessments']) or []
    keys = [r['criterion_key'] for r in ratings]
    # A supplied rating subset stays incomplete; duplicates and reordered criteria are invalid.
    if keys != [k for k in CRITERIA if k in keys]:
        raise IntakeError('preliminary_assessments')
    known(CORRESPONDENCE)(data['evaluation_correspondence'], 'evaluation_correspondence')
    known(lambda v, p: preview_shape(v, p))(data['existing_preview_input'], 'existing_preview_input')
    index, identity_types = {}, {}
    for r in records:
        k = (r['schema_version'], r['id'], r['revision'])
        if k in index or identity_types.get(r['id'], r['schema_version']) != r['schema_version']:
            raise IntakeError('records.identifiers')
        identity_types[r['id']] = r['schema_version']
        index[k] = r
    hashes = {k: digest(r) for k, r in index.items()}
    def resolve(ref):
        r = index.get(ref_key(ref))
        if r is None or hashes[ref_key(ref)] != ref['content_sha256']:
            raise IntakeError('records.references')
        return r
    for ref in refs({k: v for k, v in data.items() if k != 'existing_preview_input'}):
        resolve(ref)
    # Revisions must be contiguous from 1; the dictionary key is not a proof.
    for r in records:
        if r['previous'] is not None:
            prev = resolve(r['previous'])
            if (prev['schema_version'], prev['id'], prev['revision']) != (r['schema_version'], r['id'], r['revision'] - 1):
                raise IntakeError('records.previous')
    visiting, visited = set(), set()
    def visit(k):
        if k in visiting:
            raise IntakeError('records.cycle')
        if k in visited:
            return
        visiting.add(k)
        for ref in refs(index[k]):
            visit(ref_key(ref))
        visiting.remove(k)
        visited.add(k)
    for k in index:
        visit(k)
    # Resolve typed fragment links against their exact source revision.
    for r in records:
        p = r['payload']
        links = ([link for name in ('supporting', 'contradicting', 'contextual') for link in p[name]]
                 if r['schema_version'] == TYPES[1] else p['evidence_links'] if r['schema_version'] == TYPES[2] else [])
        for link in links:
            s = resolve(link['source_ref'])
            if link['fragment_id'] not in [f['fragment_id'] for f in s['payload']['fragments']]:
                raise IntakeError('records.fragments')
    # An unsupported factual conclusion is not relabelled or admitted as a fact.
    # These are recorded consistency checks, not proof of reading/scientific truth.
    for rec in records:
        if rec['schema_version'] != TYPES[3]:
            continue
        p = rec['payload']
        for reason in p['reasons'] + p['scientific_risks'] + p['editorial_risks']:
            if reason['kind'] != 'FACTUAL_CONCLUSION':
                continue
            if not reason['basis_claim_refs']:
                raise IntakeError('recommendation.factual_basis')
            for cr in reason['basis_claim_refs']:
                claim = resolve(cr)['payload']
                review = value(claim['editor_review'])
                if (claim['verification_state'] != 'EDITOR_REVIEW_RECORDED' or review is None
                        or value(claim['claim_kind']) != 'factual'
                        or not claim['supporting'] or claim['contradicting']):
                    raise IntakeError('recommendation.factual_basis')
                reviewed = {wire(r) for r in review['reviewed_source_refs']}
                for link in claim['supporting']:
                    source = resolve(link['source_ref'])['payload']
                    fragment = next(f for f in source['fragments'] if f['fragment_id'] == link['fragment_id'])
                    confirmation = source['checks']['editor_confirmation']
                    material = value(source['material_sha256'])
                    if (wire(link['source_ref']) not in reviewed or material is None
                            or (value(fragment['exact_text']) is None and value(fragment['pointer']) is None)
                            or source['checks']['retrieval']['state'] != 'RETRIEVED'
                            or confirmation['state'] != 'CONFIRMED_AS_RECORDED'
                            or value(confirmation['basis']) is None
                            or value(confirmation['origin']) != 'EDITOR_DECLARED'
                            or value(confirmation['reviewed_material_sha256']) != material):
                        raise IntakeError('recommendation.factual_basis')
    return records, resolve


def preview_shape(v, p):
    if type(v) is not dict or set(v) - editor_preview.FIELDS:
        raise IntakeError(p)
    if v.get('schema_version') != editor_preview.VERSION or v.get('purpose') != 'PREVIEW_ONLY':
        raise IntakeError(p)


def action(code):
    a, b = TEXT[code]
    return dict(ru=a, uk=b)


def intake(data, locale='ru'):
    """Return (controlled status, detached private artifacts), with no I/O or mutation."""
    status = dict(state='INVALID', diagnostics=[])
    def note(code, section):
        d = dict(code=code, section=section, action=action(code))
        if d not in status['diagnostics']:
            status['diagnostics'].append(d)
    try:
        enum('ru', 'uk')(locale, 'locale')
        records, resolve = validate(data)
    except (IntakeError, UnicodeError, ValueError, TypeError, RecursionError) as e:
        note('INPUT_INVALID', e.section if isinstance(e, IntakeError) else 'input')
        return status, {}
    data = deepcopy(data)
    for name in ('topic', 'audience', 'research_question', 'proposed_angle', 'sources', 'claims',
                 'critiques', 'preliminary_assessments', 'recommendation'):
        v = data[name]['wording'] if name == 'topic' else data[name]
        if value(v) is None or value(v) == []:
            note('INPUT_MISSING', name)
    assessments = value(data['preliminary_assessments']) or []
    if len(assessments) != 9:
        note('INPUT_MISSING', 'preliminary_assessments')
    for r in assessments:
        if value(r['proposed_value']) is None or r['origin'] == 'MODEL_PROPOSED' or value(r['editor_choice']) is None:
            note('INPUT_MISSING', 'preliminary_assessments')
        elif value(value(r['editor_choice'])['chosen_value']) is None:
            note('INPUT_MISSING', 'preliminary_assessments')
    sources = value(data['sources']) or []
    claims = value(data['claims']) or []
    critiques = value(data['critiques']) or []
    for s in sources:
        p = s['payload']
        if p['checks']['retrieval']['state'] != 'RETRIEVED':
            note('SOURCE_NOT_RETRIEVED', 'sources')
        if not p['fragments'] or any(value(f['exact_text']) is None and value(f['pointer']) is None for f in p['fragments']):
            note('FRAGMENT_MISSING', 'sources')
        for name, states in AXES.items():
            o = p['checks'][name]
            positive_state = o['state'] in states[1:]
            if (o['state'] == states[0] or value(o['basis']) is None or value(o['origin']) is None
                    or (positive_state and value(o['reviewed_material_sha256']) is None)
                    or (name == 'editor_confirmation' and o['state'] == 'CONFIRMED_AS_RECORDED'
                        and value(o['origin']) != 'EDITOR_DECLARED')
                    or (positive_state and value(o['reviewed_material_sha256']) != value(p['material_sha256']))):
                note('SOURCE_REVIEW_MISSING', 'sources')
    # Same material is never counted as independent corroboration. Leave originals intact.
    for c in claims:
        p = c['payload']
        if (p['verification_state'] != 'EDITOR_REVIEW_RECORDED' or value(p['editor_review']) is None
                or not p['supporting'] or p['uncertainty']['level'] == 'UNKNOWN'):
            note('CLAIM_REVIEW_MISSING', 'claims')
        if p['contradicting'] or p['verification_state'] == 'DISAGREEMENT_RECORDED':
            note('CONTRADICTION_UNRESOLVED', 'claims')
        # Sufficiency is a per-claim human consideration, never a URL-count predicate.
        hashes = [value(resolve(x['source_ref'])['payload']['material_sha256']) for x in p['supporting']]
        if len(hashes) != len(set(hashes)):
            note('CLAIM_REVIEW_MISSING', 'claims')
    delivered = [c for c in critiques if c['payload']['delivery'] == 'DELIVERED']
    if not delivered:
        note('CRITIQUE_NOT_PERFORMED', 'critiques')
    for c in delivered:
        p, origin = c['payload'], c['provenance']
        target = resolve(p['target'])
        researcher = value(target['provenance']['producer_label'])
        critic = value(origin['producer_label'])
        if not (p['independence'] == 'SEPARATE_HUMAN' and value(p['independence_basis']) is not None
                and origin['kind'] == 'EDITOR_DECLARED' and critic is not None and researcher is not None
                and critic != researcher):
            note('CRITIQUE_INDEPENDENCE_UNKNOWN', 'critiques')
        if all(value(p[x]) is None for x in ('issue', 'counterargument', 'alternative')) or value(p['checklist_notes']) is None:
            note('CRITIQUE_NOT_PERFORMED', 'critiques')
        if p['severity'] in ('HIGH', 'CRITICAL'):
            note('CONTRADICTION_UNRESOLVED', 'critiques')
    # No assertion of authentication, final approval or verified truth is generated.
    frame = value(data['existing_preview_input'])
    correspondence = value(data['evaluation_correspondence'])
    association = 'NO_FRAME' if frame is None else 'UNVERIFIED_SCOPE'
    preview_status = dict(state='UNKNOWN', reason='NOT_RUN')
    files = {}
    if frame is None:
        note('SI_BRIDGE_UNAVAILABLE', 'existing_preview_input')
        if correspondence is not None:
            note('SCOPE_UNVERIFIED', 'evaluation_correspondence')
    else:
        reviewed = False
        if correspondence is not None and type(frame.get('evaluation_inputs')) is dict:
            si_records = frame['evaluation_inputs'].get('records', [])
            try:
                exact_si = {wire(si_record_ref(r)) for r in si_records}
                snapshot = {wire(record_ref(r)) for r in records if r['schema_version'] != TYPES[3]}
                provided = [wire(r) for r in correspondence['research_snapshot_refs']]
                mapped = {wire(x['research_ref']) for x in correspondence['correspondence']}
                reviewed = (digest(frame['evaluation_inputs']) == correspondence['evaluation_inputs_sha256']
                    and len(provided) == len(set(provided)) and set(provided) == snapshot
                    and mapped == snapshot and all(wire(x['si_ref']) in exact_si for x in correspondence['correspondence']))
            except (SIValidationError, ValueError, TypeError, KeyError):
                reviewed = False
        if reviewed:
            association = 'SCOPE_REVIEW_RECORDED'
        else:
            note('SCOPE_UNVERIFIED', 'evaluation_correspondence')
        # The unchanged preview re-evaluates the unchanged supplied frame.
        try:
            actual, artifacts = editor_preview.preview(deepcopy(frame))
            preview_status = dict(state='KNOWN', value=actual)
            files.update({'preview/' + n: v for n, v in artifacts.items()})
            files['preview/preview-status.json'] = actual
            state = actual['evaluation']['state']
            if state in ('INVALID', 'STALE'):
                note('EVALUATION_' + state, 'existing_preview_input')
            if state not in ('OK', 'STALE', 'INVALID'):
                note('SI_BRIDGE_UNAVAILABLE', 'existing_preview_input')
            if any(v['state'] != 'DISPLAYABLE' for v in actual['cards'].values()):
                note('PROJECTION_UNAVAILABLE', 'existing_preview_input')
        except Exception:
            # Never echo exception values; failure cannot become a successful card.
            note('PROJECTION_UNAVAILABLE', 'existing_preview_input')
    recommendation = value(data['recommendation'])
    if recommendation is not None:
        binding = value(recommendation['payload']['evaluation_binding'])
        if binding is not None and (association != 'SCOPE_REVIEW_RECORDED' or binding != digest(correspondence)):
            note('SCOPE_UNVERIFIED', 'recommendation.evaluation_binding')
    next_actions = []
    for d in status['diagnostics']:
        if d['action'] not in next_actions:
            next_actions.append(deepcopy(d['action']))
    dossier = dict(schema_version='ResearchDossierV1', purpose='RESEARCH_ONLY', intake_sha256=digest(data),
        input_snapshot=data, diagnostics=deepcopy(status['diagnostics']), next_actions=next_actions,
        preview_association=association, preview_status=preview_status, production_state='NOT_ASSESSED')
    files['dossier.json'] = dossier
    status['state'] = 'NEEDS_INPUT' if status['diagnostics'] else 'READY'
    return status, files


def pairs(items):
    result = {}
    for k, v in items:
        if k in result:
            raise IntakeError()
        result[k] = v
    return result


def reject_number(_):
    raise IntakeError()


def load(source):
    if '://' in str(source) or str(source).startswith(('//', '\\\\')):
        raise IntakeError('input')
    source = Path(source)
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0)
    if source.is_symlink():
        raise IntakeError('input')
    with os.fdopen(os.open(source, flags), 'rb') as f:
        if not stat.S_ISREG(os.fstat(f.fileno()).st_mode):
            raise IntakeError('input')
        raw = f.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise IntakeError('input')
    data = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs,
                      parse_float=reject_number, parse_constant=reject_number)
    bounded(data)
    return data


def private_output(output):
    output = Path(output).absolute()
    if output.exists() or output.is_symlink():
        raise FileExistsError('OUTPUT_EXISTS')
    # Explicit export outside Git, never through a symlinked ancestor.
    for p in (output.parent, *output.parent.parents):
        if p.is_symlink() or (p / '.git').exists():
            raise IntakeError('output')
    if not output.parent.is_dir():
        raise IntakeError('output')
    return output


def run(source, output, locale='ru'):
    enum('ru', 'uk')(locale, 'locale')
    output = private_output(output)
    try:
        data = load(source)
        status, files = intake(data, locale)
    except (OSError, ValueError, UnicodeError, RecursionError):
        status = dict(state='INVALID', diagnostics=[dict(code='INPUT_INVALID', section='input', action=action('INPUT_INVALID'))])
        files = {}
    # Exclusive mkdir is the no-overwrite claim; not a durability/recovery protocol.
    output.mkdir(mode=0o700)
    for name, obj_value in sorted({**files, 'intake-status.json': status}.items()):
        path = output / name
        if path.parent != output:
            path.parent.mkdir(mode=0o700, exist_ok=True)
        with os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'wb') as f:
            f.write(wire(obj_value))
    return status


class LocalParser(argparse.ArgumentParser):
    def error(self, message):
        # argparse's default includes arbitrary rejected values in stderr.
        self.exit(2, 'INPUT_INVALID\n')


def main(argv=None):
    p = LocalParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--out-dir', type=Path, required=True)
    p.add_argument('--locale', choices=('ru', 'uk'), required=True)
    a = p.parse_args(argv)
    try:
        status = run(a.input, a.out_dir, a.locale)
    except (OSError, ValueError, UnicodeError, RecursionError):
        print('INPUT_INVALID', file=sys.stderr)
        return 2
    # Only controlled diagnostics; raw originals are confined to the private snapshot.
    print(json.dumps(dict(state=status['state'], actions=[d['action'][a.locale] for d in status['diagnostics']]), ensure_ascii=False))
    return 2 if status['state'] == 'INVALID' else 0


if __name__ == '__main__':
    raise SystemExit(main())
