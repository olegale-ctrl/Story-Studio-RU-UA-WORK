# SI-PRODUCT-02.3.1-RESUME — Manual-First Research Intake

Дата: 2026-11-16. **READY_FOR_INDEPENDENT_REVIEW.**
Квалификация: **LOCAL_MANUAL_INTAKE_ONLY**, не production authority.

## Основание и Git

- Repository: `olegale-ctrl/Story-Studio-RU-UA-WORK`.
- Branch: `feat/si-product-02-3-1-research-intake`.
- Exact base / parent: `dbf5052f6c6b5721d17f672e78f40df13824b8f3`.
- Владелец явно утвердил **HIST-01=A** и разрешил RESUME от этого SHA.
  RD-01–RD-04 остаются **A / APPROVED**, без пересмотра.
- Предыдущий BLOCKED_CONTRACT report сохранён в Git на exact base. Этот отчёт
  заменяет его после разрешения RI-G01 владельцем; нет самостоятельного изменения
  контрактов или удаления истории. R-T05/R-T12 реализованы в допустимых пределах.
- Result commit — commit, содержащий этот отчёт. Его полный SHA находится в
  `HANDOFF.json` архива и финальной передаче: собственный hash не встраивается
  в сам commit. Parent проверен после commit, worktree clean.

## Точный allowlist

Созданы:

1. [scripts/research_intake.py](../../scripts/research_intake.py).
2. [tests/test_research_intake.py](../../tests/test_research_intake.py).
3. [examples/research_intake_example.json](../../examples/research_intake_example.json).
4. [examples/research_intake_incomplete.json](../../examples/research_intake_incomplete.json).

Обновлён только этот отчёт; в [WORKLOG](../../project-log/WORKLOG.md) — только append.
Итого шесть путей. SI/1, evaluator, Projection, Editor Preview, Storage, утверждённые
контракты, прежние тесты/golden vectors, CI и зависимости не изменены.

## Что работает

- `intake(data, locale='ru') -> (status, files)` — detached результат без файловых
  операций/мутации входа. `load(path)` — bounded local JSON. `run(source, output,
  locale)` — явный приватный экспорт; `main(argv=None)` — CLI.
- Закрытые ResearchIntakeV1, четыре research envelope/payload, K/UNKNOWN, RRef,
  observation axes, ratings и correspondence из [контракта](SI_PRODUCT_02_3_0_RESEARCH_CONTRACT.md).
  `contextual` использует явно предусмотренную relation `context|insufficient`.
  previous — exact RRef прежней версии, не загрузка файла или implicit latest.
- Канонические bytes: compact sorted-key UTF-8, exact Unicode, no normalization.
  SHA-256 всего envelope; порядок списков сохраняется. Duplicate JSON keys,
  floats/NaN/Infinity, surrogates, oversized/deep values отклоняются, не исправляются.
- 2 MiB input, 100 sources, 200 claims, 200 critiques, 200 notes. Лимиты counts
  проверяются до хеширования графа; глубина JSON ограничена 64. Hash каждого record
  кэшируется на validation, а не пересчитывается для каждого ребра.
- Точные UUID/type/revision/hash, uniqueness, contiguous previous chains от revision 1,
  отсутствующие refs, typed source→fragment links, material/fragment hash consistency
  и cycles fail closed. Разные типы не занимают один UUID. Source/claim/critique
  revisions допустимы только с полными exact predecessors внутри входа.
- HIST-01: только recommendation revision=1/previous=null; critique targets — только
  присутствующие ResearchClaimV1. Последующие рекомендации и recommendation-targeted
  critiques дают `INPUT_INVALID`, section `*.unsupported_history`, без dossier.
- Валидное неполное исследование сохраняется как ResearchDossierV1 с UNKNOWN/gaps,
  exact private input_snapshot, bilingual diagnostics/actions, `NOT_ASSESSED`.
  KNOWN [] не подменяет UNKNOWN, нет выдуманных дат/цитат/источников/авторов/рейтингов.
- Пять source observations не продвигают друг друга. Нет acquisition/hash verification
  произвольного материала: reported digest, pointer, retrieved/review labels — только
  записанные заявления. Необоснованные observations остаются видимыми с review gap.
- Supporting/contradicting/contextual связи и review scope сохраняются без majority
  rule. Одинаковый материал не превращается в независимое corroboration. Неподдержанный
  FACTUAL_CONCLUSION отклоняется: нужна exact цепочка recorded claim/source/fragment
  review, а не только label или число URL. Сама цепочка не доказывает научную истину.
- RD-01: отсутствие/неисполнение/неустановленная независимость критики видимы;
  одинаковые/неизвестные producer labels, MODEL_PROPOSED critic либо отсутствующее
  independence_basis не считаются независимым review. Значимые разногласия эскалируются
  действием для человека. Ни одно состояние не выдаётся за окончательное одобрение.
- RD-04: ручные preliminary values/UNKNOWN и отдельные model proposals/editor_choice
  сохраняются как данные. Нет второго score, автоматического SI ratings import,
  human findings, SUFFICIENT/DISTINCT/freshness synthesis или изменения evaluator.
- RD-03: без frame — только dossier/actions, `NO_FRAME`, preview UNKNOWN/NOT_RUN.
  С frame вызывается неизменённый `editor_preview.preview` с неизменённой копией
  supplied input. Genuine evaluation/Card/plan artifacts отделены в `preview/`.
  Current research coverage не наследует SI eligibility.
- Correspondence проверяет exact research snapshot coverage, full evaluation-input
  digest, существование exact SIRefs и binding. Только согласованная записанная
  связь даёт `SCOPE_REVIEW_RECORDED`; иначе `UNVERIFIED_SCOPE`/SCOPE_UNVERIFIED.
  Даже SCOPE_REVIEW_RECORDED не доказывает semantic equivalence или human identity.
- Все diagnostic/action строки контролируемые, RU/UK без fallback. Цитаты, qualifiers,
  private source text/URL и исходный язык не переводятся и не отражаются в error text.
  Исходные тексты, provenance и отдельные editor declarations остаются в private snapshot.

## Экспорт и CLI

```bash
python -m scripts.research_intake --input examples/research_intake_example.json --out-dir /PRIVATE/NEW/ru --locale ru
python -m scripts.research_intake --input examples/research_intake_incomplete.json --out-dir /PRIVATE/NEW/uk --locale uk
```

Parent output directory должен существовать. Output — новый каталог вне Git,
без symlink ancestors; существующий каталог/ссылка отклоняется до чтения input.
Input — regular local JSON, не URL/UNC/symlink/FIFO и не crawler path. Явные remote
paths отклоняются до os.open; выбор локального filesystem/mount остаётся за оператором.
Нет обхода директорий, получения файлов source.locator или material hashing с диска.

На валидном input: canonical `dossier.json`, controlled `intake-status.json`, а при
actual Preview — отдельные `preview/*` JSON. На структурной ошибке: только controlled
status, без positive dossier/поддельного snapshot. Исходный invalid draft остаётся
в supplied input file; модуль его не чинит и не переносит в валидный envelope.
CLI exit 0 — snapshot валидного, в том числе неполного, исследования, **не approval**;
exit 2 — invalid input/output/I/O. Ошибки argparse также не раскрывают rejected values.

Smoke RU/UK реально выполнен на Linux/Python 3.12.14: оба exit 0, NEEDS_INPUT,
NO_FRAME, NOT_ASSESSED. Это ожидаемо: примеры явно синтетические, ratings UNKNOWN,
реальные исторические материалы не представлены. Оба примера не выдаются за
проверенное исследование «Почему исчезли древние цивилизации?».
Файлы output 0600, каталоги 0700 на протестированном POSIX; данные не помещались в Git.
Нет обещания NTFS ACL qualification, atomic transaction, crash-safe/power-loss
persistence. Ошибка I/O может оставить частичный новый export; повторный запуск
не перезаписывает его. Это snapshot export, не authoritative storage.

## Проверки

Среда: Linux x86_64, Python 3.12.14, проектная `.venv`, без новых зависимостей.
`python` в командах ниже — `/workspace/Story-Studio-RU-UA-WORK/.venv/bin/python`.

| Проверка | Tests | Exit | Failures / errors / skips |
|---|---:|---:|---|
| intake | 29 | 0 | 0 / 0 / 0 |
| preview | 16 | 0 | 0 / 0 / 0 |
| si | 295 | 0 | 0 / 0 / 0 |
| full | 1185 | 0 | 0 / 0 / 0 |
| compileall | — | 0 | — |
| diff-check | — | 0 | — |

Команды:

```text
python -m unittest tests.test_research_intake -v
python -m unittest tests.test_editor_preview -v
python -m unittest discover -s tests -p 'test_story_intelligence_*.py' -v
python -m unittest discover -s tests -v
python -m compileall -q scripts/research_intake.py tests/test_research_intake.py
git diff --check
```

Указаны финальные запуски после hardening. Первые промежуточные intake runs имели
27/28 tests; итоговый запуск включает все 29. Два промежуточных full runs были явно остановлены SIGTERM (exit -15) после
UNC/factual-kind hardening; им не присвоен PASS. Они заменены финальным full run
на окончательных Python bytes; все соответствующие logs/exit приложены.
Нет пропущенных/expectedFailure тестов. Статические проверки не посчитаны unit tests.

Full discovery также исполнил неизменённые legacy D1 synthetic integration tests:
их stdout содержит временные PROJECT/RENDER/VIDEO paths. Это существующая синтетическая
регрессия D1, не вызов research intake и не разрешение рендера исследуемых материалов.
Эти временные медиа не включены в архив. Новые intake tests отдельно блокируют и
проверяют отсутствие сетевых/TTS/render/subprocess эффектов во всех своих сценариях.


### R-T01–R-T18: соответствие независимым oracles

| ID | Реальный oracle в test_research_intake.py |
|---|---|
| R-T01 | Exact source/fragment dossier; реальный публичный URL как supplied lead, без fetch/ложной цитаты |
| R-T02 | UNKNOWN/incomplete, no frame; preview не вызван, NOT_RUN сохранён |
| R-T03 | URL/retrieval/content/editor confirmation независимо; missing fragment видим |
| R-T04 | Supporting+contradicting сохранены; genuine supplied SI frame даёт BLOCKED |
| R-T05 | Missing/type/hash/fragment/unknown-ref-field — INVALID, без dossier |
| R-T06 | UNKNOWN/YEAR/DATE/INSTANT не достраиваются; invalid dates отклоняются |
| R-T07 | Duplicate identities отвергаются; same-material sources сохраняются без corroboration count |
| R-T08 | MODEL_PROPOSED не отмывается; human choice отдельно, нет SI import |
| R-T09 | Missing/same-human/unknown/model critic диагностируются, declared separate human не аутентифицируется |
| R-T10 | Текст SUFFICIENT/DISTINCT/fresh не создаёт human findings/premise |
| R-T11 | UNKNOWN ratings не0; никаких средних; bool/float/out-of-range отвергаются |
| R-T12 | Exact source previous допустим; missing predecessor/hash change отвергается, no rebase |
| R-T13 | Genuine INVALID/STALE, injected Projection failure; нет counterfeit Card |
| R-T14 | Exact RU/UK original text, fixed actions, determinism/nonmutation, Unicode distinctness |
| R-T15 | Private identifiers/URL/text остаются в snapshot, не в controlled errors |
| R-T16 | Prompt instructions — данные; forbidden socket/HTTP/subprocess/render/TTS/wave calls не вызваны |
| R-T17 | Genuine ELIGIBLE/high score не даёт production permissions, NOT_ASSESSED |
| R-T18 | Unchanged Preview API/results + actual full existing suite, включая 02.2.1/SI/S2/goldens |

Дополнительные tests: HIST-01, exact correspondence/stale binding/new research data,
closed nested schemas, count/depth/byte limits, first/previous/cyclic-reference refusals,
invalid JSON, reproducible canonical export, no-overwrite/Git/symlink/remote-path guard,
CLI privacy, factual-basis admission и literal SHA oracles. У cycle witness с фиктивными
hashes отказ происходит уже на exact-ref validation; это не заявление о построении
криптографически самосогласованного SHA-256 cycle.

Literal independent fixtures:

- Full input canonical SHA-256: `6c07902a8dbd0ddf999ed0d8070317066c77f104b0888c17f746b55159087295`.
- Incomplete input canonical SHA-256: `40762da2e67433b0eb380dba8393785a3c8c1de6a9dc451082bcb5abf80904e4`.
- Exact synthetic source envelope SHA-256: `aca239651e95df8a60fdd012851afb277c043dbda68d17c91bcd78e37c2c7824`.

Hashes/reference construction in tests use independent hashlib/json expressions;
expected values above are literals. Existing golden files remain byte-exact.
Success evaluation paths use actual evaluator results, not mocked positive results.
Only negative fault test replaces Projection with UNAVAILABLE; prohibited effects
are patched to raise and asserted not called.

## Ограничения и передача

Человеческие labels/observations/scope-note в JSON — заявления, не identity/rights/
reading/scientific verification. Per-claim качество, метод/период/контекст, обоснование
отсутствия независимого подтверждения и значимые разногласия рассматривает человек;
модуль не делает NLP/scientific judgment или автоматический допуск на основе URL count.
Нет реальных human quality labels/benchmark measurements, Windows native qualification,
provider/network/automatic SI builder/storage или production execution. HIST-01 остаётся
явным ограничением, а не скрытым обходом истории. Новых blocking contract gaps не найдено.

Изменённые файлы, итоговые test logs/exit codes, smoke metadata, HANDOFF и SHA manifest
передаются в `si-product-02-3-1-resume.zip` с внешним `.sha256` в существующей ветке
`artifacts/si-product-02-3-0-research-contract`, `review-downloads/`.
Архив содержит только review package; реальных приватных источников/ключей в нём нет.
Implementation commit локальный. Не создавались PR, merge, tag, release; main не менялся.
`PUBLISH_REVISION` DISABLED, partial COMMIT reconstruction OFF; Windows S3.2b не запускается.

**STOP — WAIT FOR INDEPENDENT REVIEW.** Никакой следующий этап не начат.
