"""Pure private editorial presentation; explicit export only, no decision/authority."""
from copy import deepcopy
from hashlib import sha256
import json
import os
import re

from scripts import research_intake as ri, topic_scoring_bridge as bridge

LABELS = {
 'heading':('Редакторское рассмотрение','Редакторський розгляд'),
 'banner':('Приватные записанные данные, не инструкции к выполнению. Структура/labels не доказывают истину, личность, права или допуск. Окончательное решение принимает человек.',
           'Приватні записані дані, а не інструкції до виконання. Структура/labels не доводять істини, особи, прав або допуску. Остаточне рішення ухвалює людина.'),
 'topic':('Тема и отдельные состояния','Тема та окремі стани'),
 'title':('Название темы','Назва теми'), 'question':('Исследовательский вопрос','Дослідницьке питання'),
 'audience':('Аудитория','Аудиторія'), 'angle':('Записанный основной ракурс','Записаний основний ракурс'),
 'research':('Исследовательская готовность','Дослідницька готовність'),
 'eligibility':('SI eligibility — только supplied SI view','SI eligibility — лише supplied SI view'),
 'production':('Производственное состояние — не допуск','Виробничий стан — не допуск'),
 'scope':('Связь Research ↔ SI не доказана; recorded scope — заявление','Зв’язок Research ↔ SI не доведено; recorded scope — заява'),
 'evidence':('Утверждения и доказательные связи','Твердження та доказові зв’язки'),
 'claim':('Утверждение','Твердження'), 'statement':('Исходный текст утверждения','Початковий текст твердження'),
 'ref':('Точный RRef','Точний RRef'), 'kind':('Тип и центральность (записано)','Тип і центральність (записано)'),
 'review':('Записанная проверка — не удостоверенный факт review','Записана перевірка — не засвідчений факт review'),
 'uncertainty':('Неопределённость','Невизначеність'),
 'supporting':('Поддерживающие связи — не proof истины','Підтримувальні зв’язки — не proof істини'),
 'contradicting':('Противоречащие связи','Суперечні зв’язки'),
 'contextual':('Контекстные/недостаточные связи','Контекстні/недостатні зв’язки'),
 'source':('Источник','Джерело'), 'fragment':('Фрагмент','Фрагмент'),
 'reason':('Записанное основание связи','Записана підстава зв’язку'),
 'gaps':('Пробелы и недостающие подтверждения','Прогалини та відсутні підтвердження'),
 'critiques':('Критические замечания — unresolved/declared','Критичні зауваження — unresolved/declared'),
 'sources':('Источники, фрагменты и ограничения','Джерела, фрагменти та обмеження'),
 'locator':('Локатор как данные (не активная ссылка)','Локатор як дані (не активне посилання)'),
 'author':('Автор / организация / даты — как предоставлены','Автор / організація / дати — як надано'),
 'limits':('Ограничения','Обмеження'), 'observations':('Пять независимых записанных observations','П’ять незалежних записаних observations'),
 'quote':('Точный предоставленный текст — не verified quote','Точний наданий текст — не verified quote'),
 'pointer':('Предоставленный указатель','Наданий покажчик'),
 'actions':('Действия редактора — порядок источников, не новый приоритет','Дії редактора — порядок джерел, а не новий пріоритет'),
 'origin':('Происхождение действия и все ссылки','Походження дії та всі посилання'),
 'creative':('Только записанные творческие предложения','Лише записані творчі пропозиції'),
 'alternative_angles':('Альтернативные ракурсы','Альтернативні ракурси'),
 'emotional_hooks':('Эмоциональные хуки','Емоційні хуки'),
 'intellectual_hooks':('Интеллектуальные хуки','Інтелектуальні хуки'),
 'narrative':('Записанный повествовательный потенциал','Записаний оповідний потенціал'),
 'narrative_alternatives':('Структурированные narrative alternatives — поля нет в принятом input','Структуровані narrative alternatives — поля немає в прийнятому input'),
 'visuals':('Записанные визуальные потребности — не готовые assets/права','Записані візуальні потреби — не готові assets/права'),
 'si':('Неизменённая SI оценка supplied frame','Незмінене SI оцінювання supplied frame'),
 'aggregate':('Исходный aggregate_tenths — без пересчёта шкалы','Початковий aggregate_tenths — без перерахунку шкали'),
 'preliminary':('Research preliminary ratings — НЕ SI ratings','Research preliminary ratings — НЕ SI ratings'),
 'worksheet':('Незаполненный бланк решения человека','Незаповнений бланк рішення людини'),
 'worksheet_note':('Бланк не подтверждает состоявшийся review. Ничего не выбрано и не датировано программой.',
                    'Бланк не підтверджує здійснений review. Нічого не обрано й не датовано програмою.'),
 'recorded_context':('Записанное предложение и риски из input — не новое решение','Записана пропозиція та ризики з input — не нове рішення'),
 'si_result':('Существующий результат evaluator (не решение человека)','Наявний результат evaluator (не рішення людини)'),
 'si_card':('Существующая Projection card — только supplied SI view','Наявна Projection card — лише supplied SI view'),
 'invalid':('Входы не согласованы; представление не создано.','Входи не узгоджені; представлення не створено.'),
 'output_invalid':('Экспорт не завершён: нужен новый приватный каталог без перезаписи.','Експорт не завершено: потрібен новий приватний каталог без перезапису.'),
}
CRITERION_LABELS = {
 'audience_interest':('Интерес аудитории','Інтерес аудиторії'),
 'channel_fit':('Соответствие каналу','Відповідність каналу'),
 'angle_novelty':('Новизна ракурса','Новизна ракурсу'),
 'evidence_quality':('Качество оснований','Якість підстав'),
 'narrative_potential':('Повествовательный потенциал','Оповідний потенціал'),
 'visual_feasibility':('Визуальная осуществимость','Візуальна здійсненність'),
 'resource_fit':('Соответствие ресурсам','Відповідність ресурсам'),
 'risk_manageability':('Управляемость рисков','Керованість ризиками'),
 'portfolio_distinctness':('Отличие от портфеля','Відмінність від портфеля'),
}
CHOICES = ('Develop','Research Further','Reframe','Reject','Defer')


def digest(value):return sha256(ri.wire(value)).hexdigest()


def failure(code='INPUT_INVALID'):
    pair=LABELS['invalid' if code=='INPUT_INVALID' else 'output_invalid']
    return dict(state='INVALID',diagnostics=[dict(code=code,action=dict(ru=pair[0],uk=pair[1]))]),{}


def build_view(dossier,evidence_report,bridge_report,*,existing_preview_input=None,locale='ru'):
    """Return (status, {'view.json': EditorialReviewViewV1, 'review.md': text}).

    Pinned bridge replay validates all inputs. No I/O and no generated human decision.
    Re-verification uses the existing evaluator; no own score computation.
    """
    try:
        if type(locale) is not str or locale not in ('ru','uk'):return failure()
        ri.bounded(dossier,depth=-2);ri.bounded(evidence_report,depth=-4);ri.bounded(bridge_report,depth=-8)
        if existing_preview_input is not None:ri.bounded(existing_preview_input)
        d,e,b,frame=deepcopy((dossier,evidence_report,bridge_report,existing_preview_input))
        status,expected=bridge.integrate(d,e,existing_preview_input=frame,locale=locale)
        if status['state']!='OK' or expected is None or ri.wire(b)!=ri.wire(expected):return failure()
        snapshot=d['input_snapshot'];bh=digest(b);dh=digest(d)
        sources=ri.value(snapshot['sources']) or [];claims=ri.value(snapshot['claims']) or []
        critiques=ri.value(snapshot['critiques']) or [];rec=ri.value(snapshot['recommendation'])
        source_index={ri.wire(ri.record_ref(r)):(i,r) for i,r in enumerate(sources,1)}
        registry=[dict(source_number=i,source_ref=ri.record_ref(r),provenance=deepcopy(r['provenance']),**deepcopy(r['payload'])) for i,r in enumerate(sources,1)]
        claim_items=[]
        for c in claims:
            ref=ri.record_ref(c);p=c['payload'];links={}
            linked_refs=[ref]
            for field in ('supporting','contradicting','contextual'):
                links[field]=[]
                for link in p[field]:
                    number,source=source_index[ri.wire(link['source_ref'])]
                    links[field].append(dict(source_number=number,source_title=deepcopy(source['payload']['title']),link=deepcopy(link)))
                    linked_refs.append(link['source_ref'])
            relevant=[g for g in e['evidence_gaps'] if any(r in linked_refs for r in g['record_refs'])]
            claim_items.append(dict(claim_ref=ref,statement=p['statement'],claim_kind=deepcopy(p['claim_kind']),
                materiality=deepcopy(p['materiality']),verification_state=p['verification_state'],
                editor_review=deepcopy(p['editor_review']),uncertainty=deepcopy(p['uncertainty']),
                evidence_expectation=deepcopy(p['evidence_expectation']),further_research=deepcopy(p['further_research']),
                provenance=deepcopy(c['provenance']),**links,gaps=deepcopy(relevant),
                critiques=deepcopy([q for q in e['critique_review'] if q['target']==ref])))
        actions=[];action_index={}
        def add(kind,text,origin,refs=(),code=None,fragment_id=None):
            # Only identical kind/code/text/fragment combine; no paraphrase/similarity/priority.
            key=ri.wire(dict(kind=kind,code=code,text=text,fragment_id=fragment_id))
            if key not in action_index:
                action_index[key]=len(actions);actions.append(dict(kind=kind,code=code,text=text,fragment_id=fragment_id,record_refs=[],origins=[]))
            item=actions[action_index[key]]
            if origin not in item['origins']:item['origins'].append(deepcopy(origin))
            for ref in refs:
                if ref not in item['record_refs']:item['record_refs'].append(deepcopy(ref))
        for i,a in enumerate(b['editorial_decision_support']['next_actions']):
            add('CONTROLLED_ACTION',a['action'][locale],dict(artifact='TopicScoringBridgeReportV1',sha256=bh,
                field_path=f'$.editorial_decision_support.next_actions[{i}]',record_refs=deepcopy(a['record_refs']),source_action=deepcopy(a)),a['record_refs'],a['code'],a.get('fragment_id'))
        if rec is not None:
            rr=ri.record_ref(rec)
            for field,kind in (('gaps','RECORDED_GAP'),('next_actions','RECORDED_ACTION')):
                for i,text in enumerate(rec['payload'][field]):
                    add(kind,text,dict(artifact='TopicRecommendationV1',record_ref=rr,field_path=f'$.payload.{field}[{i}]'),[rr])
        for c in critiques:
            rr=ri.record_ref(c);add('RECORDED_ACTION',c['payload']['editor_action'],
                dict(artifact='ResearchCritiqueV1',record_ref=rr,field_path='$.payload.editor_action'),[rr,c['payload']['target']])
        for c in claims:
            rr=ri.record_ref(c)
            for i,text in enumerate(c['payload']['further_research']['actions']):
                add('RECORDED_ACTION',text,dict(artifact='ResearchClaimV1',record_ref=rr,field_path=f'$.payload.further_research.actions[{i}]'),[rr])
        fields=('main_angle','alternative_angles','emotional_hooks','intellectual_hooks','narrative_potential','visual_needs','production_limits')
        cp=rec['payload'] if rec else None
        creative=dict(state='NOT_RECORDED',source_ref=None if rec is None else ri.record_ref(rec),
            provenance=None if rec is None else deepcopy(rec['provenance']),recorded={},field_states={},
            narrative_alternatives=dict(state='NOT_RECORDED',reason='NO_STRUCTURED_FIELD_IN_ACCEPTED_INPUT'))
        if cp is not None:
            creative['recorded']={f:deepcopy(cp[f]) for f in fields}
            for field in fields:
                v=cp[field];present=ri.value(v) is not None if type(v) is dict else bool(v)
                creative['field_states'][field]='RECORDED' if present else 'NOT_RECORDED'
            if any(creative['field_states'][f]=='RECORDED' for f in fields if f!='production_limits'):creative['state']='RECORDED'
        si=deepcopy(b['si_scoring_context']);si['projection_card']=deepcopy(b['preview']['artifacts'].get('private-card-'+locale+'.json'));si['display_state']='SI_NOT_RUN' if si['state'] in ('NO_FRAME','NOT_RUN') else si['state']
        result=si['evaluation_result']
        worksheet=dict(allowed_decisions=list(CHOICES),decision=None,rationale=None,unresolved_risks=None,
            selected_angle=None,next_actions=None,reviewer_identity=None,review_date=None,completed_by_program=False)
        recorded_context=dict(state='NOT_RECORDED',source_ref=None,provenance=None,recorded={})
        if rec is not None:
            recorded_context=dict(state='RECORDED',source_ref=ri.record_ref(rec),provenance=deepcopy(rec['provenance']),
                recorded={k:deepcopy(cp[k]) for k in ('prospect','reasons','scientific_risks','editorial_risks','gaps','production_limits')})
        view=dict(schema_version='EditorialReviewViewV1',purpose='PRIVATE_READ_ONLY_PRESENTATION',display_locale=locale,
            source_identity=dict(**deepcopy(b['research_identity']),bridge_report_sha256=bh),
            topic_overview=dict(recorded_editorial_context=recorded_context,title=deepcopy(snapshot['topic']['wording']),research_question=deepcopy(snapshot['research_question']),
                audience=deepcopy(snapshot['audience']),research_readiness=e['research_readiness'],
                si_eligibility=None if result is None else deepcopy(result['eligibility']),production_state='NOT_ASSESSED',
                correspondence=deepcopy(b['research_identity']),critical_review=deepcopy(e['critique_review']),
                unresolved_gaps=deepcopy(e['evidence_gaps']),editor_notes=deepcopy(snapshot['editor_notes'])),
            evidence_overview=claim_items,source_inventory=registry,editorial_actions=actions,
            creative_options=creative,si_evaluation_context=si,
            preliminary_research_assessments=deepcopy(snapshot['preliminary_assessments']),
            decision_worksheet=worksheet,recommendation_generated=False,human_pilot_status='HUMAN_PILOT_PENDING',production_state='NOT_ASSESSED',
            limitations=deepcopy(b['limitations']))
        return dict(state='OK',diagnostics=[]),{'view.json':view,'review.md':_markdown(view)}
    except Exception:
        # No caller values/paths/exception text and no partial positive presentation.
        return failure()


def _block(value):
    text=value if type(value) is str else json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)
    # Neutralize invisible terminal/bidi controls only in Markdown; JSON stays exact.
    text=''.join(f'\\u{ord(c):04x}' if (ord(c)<32 and c not in '\n\t') or ord(c)==127 or
                 0x202a<=ord(c)<=0x202e or 0x2066<=ord(c)<=0x2069 else c for c in text)
    fence='`'*max(3,max((len(x) for x in re.findall(r'`+',text)),default=0)+1)
    return fence+'text\n'+text+'\n'+fence+'\n\n'


def _markdown(v):
    lang=0 if v['display_locale']=='ru' else 1
    def label(k):return LABELS[k][lang]
    out=['# '+label('heading')+' — V1\n\n',label('banner')+'\n\n']
    def section(k):out.append('## '+label(k)+'\n\n')
    def field(k,value):out.append('**'+label(k)+'**\n\n'+_block(value))
    def known(k,value):
        out.append('**'+label(k)+'**\n\n')
        if value['state']=='KNOWN':out.append(_block(value['value']))
        else:out.append('UNKNOWN\n\n'+_block(value['reason']))
    t=v['topic_overview'];section('topic');known('title',t['title']);known('question',t['research_question']);known('audience',t['audience'])
    field('research',t['research_readiness']);field('eligibility',t['si_eligibility'] if t['si_eligibility'] is not None else v['si_evaluation_context']['display_state'])
    field('production',t['production_state']);field('scope',t['correspondence']);field('critiques',t['critical_review']);field('gaps',t['unresolved_gaps']);field('recorded_context',t['recorded_editorial_context'])
    legends={
        'NEEDS_INPUT':('Не хватает записанных данных; это не вердикт об истинности.','Бракує записаних даних; це не вердикт щодо істинності.'),
        'NEEDS_REVIEW':('Предоставленные данные требуют рассмотрения человеком.','Надані дані потребують розгляду людиною.'),
        'READY_FOR_EDITOR_REVIEW':('Готово для рассмотрения редактором; решение ещё не принято.','Готове для розгляду редактором; рішення ще не ухвалено.')}
    out.append(legends[t['research_readiness']][lang]+'\n\n')
    section('evidence')
    if not v['evidence_overview']:out.append('NOT_RECORDED\n\n')
    for i,c in enumerate(v['evidence_overview'],1):
        out.append('### '+label('claim')+' '+str(i)+'\n\n');field('statement',c['statement']);field('ref',c['claim_ref'])
        field('kind',dict(kind=c['claim_kind'],materiality=c['materiality']));field('review',dict(state=c['verification_state'],details=c['editor_review'],provenance=c['provenance']))
        field('uncertainty',c['uncertainty'])
        for group in ('supporting','contradicting','contextual'):
            out.append('#### '+label(group)+'\n\n')
            if not c[group]:out.append('NOT_RECORDED\n\n')
            for item in c[group]:
                n=item['source_number'];out.append(f'[{label("source")} {n}](#source-{n})\n\n')
                known('source',item['source_title']);field('ref',item['link']['source_ref']);field('fragment',item['link']['fragment_id']);field('reason',item['link']['relation_reason'])
        field('gaps',c['gaps']);field('critiques',c['critiques'])
    section('sources')
    if not v['source_inventory']:out.append('NOT_RECORDED\n\n')
    for s in v['source_inventory']:
        # Trusted numeric headings are the only link targets; no user-derived hrefs.
        out.append('### Source '+str(s['source_number'])+'\n\n');known('source',s['title']);field('ref',s['source_ref']);field('locator',s['locator'])
        field('author',{k:s[k] for k in ('author','organization','published_at','retrieved_at')});field('review',s['provenance'])
        field('observations',s['checks']);known('limits',s['applicability_limits'])
        for f in s['fragments']:
            field('fragment',f['fragment_id']);known('quote',f['exact_text']);known('pointer',f['pointer']);field('ref',f['material_sha256'])
    section('actions')
    for i,a in enumerate(v['editorial_actions'],1):
        out.append('### '+str(i)+' — '+a['kind']+'\n\n'+_block(a['text']));field('origin',dict(record_refs=a['record_refs'],origins=a['origins']))
    section('creative');c=v['creative_options'];out.append(c['state']+'\n\n');field('ref',dict(source_ref=c['source_ref'],provenance=c['provenance']))
    if c['recorded']:
        known('angle',c['recorded']['main_angle'])
        for name in ('alternative_angles','emotional_hooks','intellectual_hooks'):
            out.append('### '+label(name)+'\n\n')
            if not c['recorded'][name]:out.append('NOT_RECORDED\n\n')
            for p in c['recorded'][name]:
                out.append(_block(p['text']));field('ref',p['basis_claim_refs']);field('limits',p['limitations'])
        known('narrative',c['recorded']['narrative_potential']);field('visuals',c['recorded']['visual_needs'] or 'NOT_RECORDED');known('limits',c['recorded']['production_limits'])
    field('narrative_alternatives',c['narrative_alternatives'])
    section('si');si=v['si_evaluation_context'];out.append(_block(si['display_state']))
    card=si['projection_card']
    out.append('### '+label('si_card')+'\n\n')
    if card is None:out.append('NOT_RECORDED\n\n')
    else:
        for name,value in card['sections'].items():
            out.append('**'+name+'**\n\n')
            for text in value if type(value) is list else [value]:out.append(_block(text))
    result=si['evaluation_result'];ratings=result['ratings'] if result is not None and result['status']=='OK' else []
    table_head=('Критерий | Вес | Исходная SI оценка | Confidence' if lang==0 else 'Критерій | Вага | Початкова SI оцінка | Confidence')
    out.append('| '+table_head+' |\n|---|---:|---|---|\n')
    for i,c in enumerate(si['criteria']):
        rating=ratings[i] if ratings else None
        number=('NOT_ACCEPTED' if result is not None else 'SI_NOT_RUN') if rating is None else (
            str(rating['value']['value']) if rating['value']['state']=='KNOWN' else 'UNKNOWN')
        confidence='—' if rating is None else rating['confidence']['level']
        out.append('| '+CRITERION_LABELS[c['criterion_key']][lang]+' | '+str(c['weight'])+' | '+number+' | '+confidence+' |\n')
    out.append('\n')
    for rating in ratings:
        out.append('**'+CRITERION_LABELS[rating['criterion_key']][lang]+'**\n\n'+_block(rating['explanation']))
    field('aggregate',None if result is None else result['aggregate_tenths'])
    field('si_result',None if result is None else {k:result[k] for k in ('status','currentness','eligibility','diagnostics')})
    if not ratings and si['supplied_si_ratings'] is not None:out.append(_block(si['supplied_si_ratings']))
    known('preliminary',v['preliminary_research_assessments']);section('limits')
    for limit in v['limitations']:out.append('- '+limit[v['display_locale']]+'\n')
    out.append('\n');section('worksheet');out.append(label('worksheet_note')+'\n\n')
    for decision in CHOICES:out.append('- [ ] '+decision+'\n')
    blanks=(('Обоснование','Обґрунтування'),('Нерешённые риски','Невирішені ризики'),
        ('Выбранный ракурс','Обраний ракурс'),('Следующие действия','Наступні дії'),
        ('Личность редактора (заполнить вручную)','Особа редактора (заповнити вручну)'),('Дата review','Дата review'))
    for pair in blanks:out.append('\n**'+pair[lang]+':** ____________________\n')
    out.append('\nHUMAN_PILOT_PENDING\n')
    return ''.join(out)


def export_view(output_dir,dossier,evidence_report,bridge_report,*,existing_preview_input=None,locale='ru'):
    """Explicit private snapshot export; exclusive new directory, no overwrites.

    No crash/power-loss/NTFS ACL qualification. I/O failure can leave a partial new
    export, which is never overwritten. Invalid input creates no output directory.
    """
    status,files=build_view(dossier,evidence_report,bridge_report,existing_preview_input=existing_preview_input,locale=locale)
    if status['state']!='OK':return status
    try:
        if '://' in str(output_dir) or str(output_dir).startswith(('//','\\\\')):return failure('OUTPUT_INVALID')[0]
        output=ri.private_output(output_dir);output.mkdir(mode=0o700)
        for name,value in files.items():
            data=ri.wire(value) if name.endswith('.json') else value.encode('utf-8')
            with os.fdopen(os.open(output/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'wb') as f:f.write(data)
        return status
    except (OSError,ValueError,TypeError):return failure('OUTPUT_INVALID')[0]
