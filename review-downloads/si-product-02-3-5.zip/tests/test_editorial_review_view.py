"""Read-only editorial joins, safe literal Markdown, exact source provenance; no pilot fiction."""
from contextlib import ExitStack
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import os
import re
import unittest
from unittest.mock import patch

from scripts import editorial_review_view as view, research_intake as ri, evidence_critique, topic_scoring_bridge
from tests.test_si_product_02_3_4_e2e import cases,run_path,canonical,reference,FORBIDDEN
from tests.test_story_intelligence_decision_projection_v1 import stale_args

ROOT=Path(__file__).resolve().parents[1]


def triplet(case=0,mode='A',locale='ru'):
    o=run_path(cases()[case],mode,locale)
    return o['intake']['dossier'],o['evidence']['report'],o['bridge']['report'],o['supplied_si_frame']


def from_input(data,frame=None):
    s,f=ri.intake(data);assert s['state']!='INVALID',s
    d=f['dossier.json'];s,e=evidence_critique.analyze(d);assert s['state']=='OK'
    s,b=topic_scoring_bridge.integrate(d,e,existing_preview_input=frame);assert s['state']=='OK'
    return d,e,b,frame


def without_literal_blocks(md):
    """Independent CommonMark fence scanner for injection assertions."""
    fence=None;outside=[]
    for line in md.splitlines():
        if fence is None:
            m=re.fullmatch(r'(`{3,})text',line)
            if m:fence=m.group(1)
            else:outside.append(line)
        elif re.fullmatch(r'`{'+str(len(fence))+r',}\s*',line):fence=None
    assert fence is None
    return '\n'.join(outside)


class EditorialReviewView(unittest.TestCase):
    def setUp(self):
        self.stack=ExitStack();self.denied=[self.stack.enter_context(patch(n,side_effect=AssertionError('forbidden effect'))) for n in FORBIDDEN]
        self.addCleanup(self.stack.close)

    def tearDown(self):
        for m in self.denied:m.assert_not_called()

    def build(self,args,locale='ru'):
        d,e,b,f=args;before=deepcopy(args)
        s,files=view.build_view(d,e,b,existing_preview_input=f,locale=locale)
        self.assertEqual(args,before);self.assertEqual(s,dict(state='OK',diagnostics=[]))
        v=files['view.json'];self.assertEqual(v['schema_version'],'EditorialReviewViewV1')
        self.assertEqual(v['human_pilot_status'],'HUMAN_PILOT_PENDING');self.assertEqual(v['production_state'],'NOT_ASSESSED')
        self.assertFalse(v['recommendation_generated'])
        w=v['decision_worksheet'];self.assertEqual(w['allowed_decisions'],['Develop','Research Further','Reframe','Reject','Defer'])
        for name in ('decision','rationale','unresolved_risks','selected_angle','next_actions','reviewer_identity','review_date'):self.assertIsNone(w[name])
        self.assertFalse(w['completed_by_program'])
        self.assertFalse(v['source_identity']['semantic_coverage_verified'])
        self.assertEqual(v['source_identity']['bridge_report_sha256'],sha256(canonical(b)).hexdigest())
        self.assertEqual(v['si_evaluation_context']['evaluation_result'],b['si_scoring_context']['evaluation_result'])
        self.assertEqual(v['si_evaluation_context']['supplied_si_ratings'],b['si_scoring_context']['supplied_si_ratings'])
        self.assertNotIn('priority',v)
        outside=without_literal_blocks(files['review.md'])
        self.assertNotIn('javascript:',outside);self.assertNotIn('<script',outside);self.assertNotIn('<img',outside)
        return files

    def reject(self,args):
        d,e,b,f=args;before=deepcopy(args);s,files=view.build_view(d,e,b,existing_preview_input=f)
        self.assertEqual(args,before);self.assertEqual(s['state'],'INVALID');self.assertEqual(files,{})
        return s

    def test_01_five_cases_both_modes_and_locales(self):
        for i in range(5):
            for mode in ('A','B'):
                args=triplet(i,mode)
                for locale in ('ru','uk'):
                    with self.subTest(case=i+1,mode=mode,locale=locale):
                        files=self.build(args,locale);v=files['view.json']
                        self.assertEqual(v['display_locale'],locale)
                        self.assertEqual(v['topic_overview']['title'],cases()[i]['research_input']['topic']['wording'])
                        self.assertIn(cases()[i]['topic'],files['review.md'])
                        self.assertIn('Незаполненный бланк' if locale=='ru' else 'Незаповнений бланк',files['review.md'])

    def test_02_exact_claim_source_fragment_joins_readable_without_input_json(self):
        args=triplet(0);files=self.build(args);v=files['view.json'];d=args[0]['input_snapshot']
        for i,c in enumerate(v['evidence_overview']):
            self.assertEqual(c['statement'],d['claims']['value'][i]['payload']['statement'])
            self.assertEqual(c['claim_ref'],reference(d['claims']['value'][i]))
            self.assertIn(c['statement'],files['review.md'])
            for group in ('supporting','contradicting','contextual'):
                for link in c[group]:
                    source=v['source_inventory'][link['source_number']-1]
                    self.assertEqual(source['source_ref'],link['link']['source_ref'])
                    self.assertEqual(link['source_title'],source['title'])
                    self.assertIn(source['title']['value'],files['review.md'])
                    self.assertIn(f"#source-{source['source_number']}",files['review.md'])
                    frag=next(x for x in source['fragments'] if x['fragment_id']==link['link']['fragment_id'])
                    if frag['exact_text']['state']=='KNOWN':self.assertIn(frag['exact_text']['value'],files['review.md'])

    def test_03_research_si_production_states_separate(self):
        files=self.build(triplet(0,'B'));v=files['view.json']
        self.assertEqual(v['topic_overview']['research_readiness'],'NEEDS_INPUT')
        self.assertEqual(v['topic_overview']['si_eligibility']['state'],'ELIGIBLE_FOR_CREATIVE')
        self.assertEqual(v['topic_overview']['production_state'],'NOT_ASSESSED')
        self.assertNotIn('overall_status',v)

    def test_04_no_frame_and_unknown_not_zero(self):
        a=self.build(triplet(3,'A'));self.assertEqual(a['view.json']['si_evaluation_context']['display_state'],'SI_NOT_RUN')
        self.assertIn('SI_NOT_RUN',a['review.md'])
        b=self.build(triplet(3,'B'));result=b['view.json']['si_evaluation_context']['evaluation_result']
        self.assertEqual(result['aggregate_tenths']['state'],'UNKNOWN')
        self.assertEqual(result['eligibility']['state'],'NEEDS_RESEARCH') # approved R1, not the original OR-01 oracle mistake
        self.assertEqual(b['view.json']['preliminary_research_assessments'],triplet(3,'B')[0]['input_snapshot']['preliminary_assessments'])
        self.assertIn('UNKNOWN',b['review.md'])

    def test_05_stale_and_invalid(self):
        d,e,_,_=triplet(2,'A');frame=deepcopy(cases()[2]['supplied_si_frame']);frame['evaluation_inputs']=stale_args()
        s,b=topic_scoring_bridge.integrate(d,e,existing_preview_input=frame);self.assertEqual(s['state'],'OK')
        files=self.build((d,e,b,frame));self.assertEqual(files['view.json']['si_evaluation_context']['state'],'STALE')
        self.assertIsNone(files['view.json']['topic_overview']['si_eligibility'])
        frame['evaluation_inputs']['records']=[];self.reject((d,e,b,frame))

    def test_06_dossier_evidence_and_bridge_tampering_refused(self):
        args=triplet(0)
        for bad in ('dossier','evidence','bridge','unknown-field'):
            with self.subTest(bad=bad):
                d,e,b,f=deepcopy(args)
                if bad=='dossier':d['intake_sha256']='0'*64
                elif bad=='evidence':e['research_readiness']='READY_FOR_EDITOR_REVIEW'
                elif bad=='bridge':b['production_state']='APPROVED'
                else:b['already_verified']=True
                self.reject((d,e,b,f))

    def test_07_missing_support_and_contrary_evidence_visible(self):
        a=self.build(triplet(0));self.assertEqual(a['view.json']['evidence_overview'][1]['supporting'],[])
        self.assertIn('NOT_RECORDED',a['review.md'])
        b=self.build(triplet(4));self.assertTrue(b['view.json']['evidence_overview'][0]['contradicting'])
        self.assertIn('Противоречащие связи',b['review.md'])

    def test_08_high_critical_model_self_review_not_hidden(self):
        for i,severity in ((0,'HIGH'),(1,'CRITICAL'),(3,'HIGH'),(4,'HIGH')):
            with self.subTest(case=i+1):
                files=self.build(triplet(i));crit=files['view.json']['topic_overview']['critical_review']
                self.assertEqual(crit[0]['severity'],severity);self.assertEqual(crit[0]['resolution_state'],'NOT_RECORDED')
                self.assertIn(severity,files['review.md'])
                if i in (3,4):self.assertTrue(any(g['code']=='CRITIQUE_INDEPENDENCE_UNKNOWN' for g in files['view.json']['topic_overview']['unresolved_gaps']))

    def test_09_repeated_sources_do_not_disappear(self):
        args=triplet(3);v=self.build(args)['view.json'];self.assertEqual(len(v['source_inventory']),2)
        a,b=v['source_inventory'];self.assertNotEqual(a['source_ref'],b['source_ref'])
        self.assertEqual(a['material_sha256'],b['material_sha256'])
        self.assertEqual(b['provenance']['upstream_refs'],[a['source_ref']])

    def test_10_recorded_creative_options_only(self):
        args=triplet(0);v=self.build(args)['view.json'];p=args[0]['input_snapshot']['recommendation']['value']['payload']
        self.assertEqual(v['creative_options']['recorded']['alternative_angles'],p['alternative_angles'])
        self.assertEqual(v['creative_options']['recorded']['emotional_hooks'],p['emotional_hooks'])
        self.assertEqual(v['creative_options']['narrative_alternatives']['state'],'NOT_RECORDED')
        data=deepcopy(cases()[1]['research_input']);r=data['recommendation']['value']['payload']
        r.update(main_angle=dict(state='UNKNOWN',reason='Not provided'),alternative_angles=[],emotional_hooks=[],intellectual_hooks=[],
                 narrative_potential=dict(state='UNKNOWN',reason='Not provided'),visual_needs=[])
        files=self.build(from_input(data));self.assertEqual(files['view.json']['creative_options']['state'],'NOT_RECORDED')
        self.assertIn('NOT_RECORDED',files['review.md'])

    def test_11_exact_action_duplicates_keep_all_provenance(self):
        data=deepcopy(cases()[0]['research_input']);r=data['recommendation']['value']['payload']
        r['next_actions']=['EXACT_SYNTHETIC_TASK','EXACT_SYNTHETIC_TASK','EXACT_SYNTHETIC_TASK ']
        v=self.build(from_input(data))['view.json']
        exact=[a for a in v['editorial_actions'] if a['kind']=='RECORDED_ACTION' and a['text']=='EXACT_SYNTHETIC_TASK']
        self.assertEqual(len(exact),1);self.assertEqual(len(exact[0]['origins']),2)
        self.assertEqual([o['field_path'] for o in exact[0]['origins']],['$.payload.next_actions[0]','$.payload.next_actions[1]'])
        self.assertEqual(len([a for a in v['editorial_actions'] if a['text']=='EXACT_SYNTHETIC_TASK ']),1)
        self.assertTrue(all('priority' not in a for a in v['editorial_actions']))

    def test_18_fragment_actions_do_not_merge_different_fragment_ids(self):
        data=deepcopy(cases()[2]['research_input']);p=data['sources']['value'][0]['payload']
        p['fragments'][0].update(exact_text=dict(state='UNKNOWN',reason='No capture'),pointer=dict(state='UNKNOWN',reason='No pointer'))
        second=deepcopy(p['fragments'][0]);second['fragment_id']='F2';p['fragments'].append(second)
        from tests.test_research_intake import rebind
        rebind(data);files=self.build(from_input(data));actions=[a for a in files['view.json']['editorial_actions'] if a['code']=='FRAGMENT_UNCONFIRMED']
        self.assertEqual(len(actions),2);self.assertEqual({a['fragment_id'] for a in actions},{'F1','F2'})
        for a in actions:
            self.assertTrue(all(o['source_action']['fragment_id']==a['fragment_id'] for o in a['origins']))
        self.assertIn('F2',files['review.md'])

    def test_12_actions_preserve_record_and_controlled_origins(self):
        args=triplet(0);v=self.build(args)['view.json'];actions=v['editorial_actions']
        self.assertTrue(all(a['origins'] for a in actions))
        self.assertTrue(any(o['artifact']=='TopicScoringBridgeReportV1' for a in actions for o in a['origins']))
        self.assertTrue(any(o['artifact']=='TopicRecommendationV1' for a in actions for o in a['origins']))
        self.assertTrue(any(o['artifact']=='ResearchClaimV1' for a in actions for o in a['origins']))
        self.assertTrue(any(o['artifact']=='ResearchCritiqueV1' for a in actions for o in a['origins']))
        for text in args[0]['input_snapshot']['recommendation']['value']['payload']['next_actions']:
            self.assertTrue(any(a['text']==text for a in actions))

    def test_13_markdown_literal_injection_fences_links_and_controls(self):
        payload='PRIVATE_SENTINEL\n# injected\n````\n<script>alert(1)</script>\n![x](https://evil.invalid/pixel)\n[x](javascript:alert(1))\nfile:///secret\n\x1b[2J\u202e'
        data=deepcopy(cases()[0]['research_input']);data['topic']['wording']['value']=payload
        data['claims']['value'][0]['payload']['statement']=payload
        # No incoming refs to the recommendation; record refs below must be rehashed for the claim.
        from tests.test_research_intake import rebind
        rebind(data)
        args=from_input(data);files=self.build(args);outside=without_literal_blocks(files['review.md'])
        self.assertNotIn('PRIVATE_SENTINEL',outside);self.assertNotIn('evil.invalid',outside)
        self.assertNotIn('javascript:',outside);self.assertNotIn('file://',outside)
        self.assertNotIn('\x1b',files['review.md']);self.assertNotIn('\u202e',files['review.md'])
        self.assertIn('\\u001b',files['review.md']);self.assertIn('\\u202e',files['review.md'])
        self.assertEqual(files['view.json']['topic_overview']['title']['value'],payload)
        self.assertTrue(all(link.startswith('#source-') for link in re.findall(r'\]\(([^)]+)\)',outside)))

    def test_14_determinism_detachment_and_locale_not_fallback(self):
        args=triplet(0);a=self.build(args);b=self.build(args);self.assertEqual(canonical(a),canonical(b))
        uk=self.build(args,'uk');self.assertNotEqual(a['review.md'],uk['review.md'])
        self.assertEqual(a['view.json']['evidence_overview'],uk['view.json']['evidence_overview'])
        a['view.json']['evidence_overview'][0]['statement']='MUTATE';self.assertNotEqual(args[0]['input_snapshot']['claims']['value'][0]['payload']['statement'],'MUTATE')
        s,f=view.build_view(*args[:3],existing_preview_input=args[3],locale='ua');self.assertEqual(s['state'],'INVALID');self.assertEqual(f,{})

    def test_15_no_default_file_io_or_automatic_human_decision(self):
        args=triplet(0)
        with patch('builtins.open',side_effect=AssertionError('no IO')) as a,patch.object(os,'open',side_effect=AssertionError('no IO')) as b:
            files=self.build(args)
        a.assert_not_called();b.assert_not_called()
        self.assertTrue(all('[ ] '+x in files['review.md'] for x in view.CHOICES))
        self.assertNotIn('[x]',without_literal_blocks(files['review.md']).lower())

    def test_16_explicit_export_private_fresh_no_overwrite(self):
        args=triplet(0)
        with TemporaryDirectory() as t:
            output=Path(t)/'private'
            s=view.export_view(output,*args[:3],existing_preview_input=args[3]);self.assertEqual(s['state'],'OK')
            before={p.name:p.read_bytes() for p in output.iterdir()};self.assertEqual(set(before),{'view.json','review.md'})
            s=view.export_view(output,*args[:3]);self.assertEqual(s['state'],'INVALID')
            self.assertEqual(before,{p.name:p.read_bytes() for p in output.iterdir()})
            if os.name=='posix':
                self.assertEqual(output.stat().st_mode & 0o777,0o700)
                self.assertEqual((output/'view.json').stat().st_mode & 0o777,0o600)
            corrupted=deepcopy(args);corrupted[2]['already_verified']=True
            s=view.export_view(Path(t)/'invalid',*corrupted[:3]);self.assertEqual(s['state'],'INVALID');self.assertFalse((Path(t)/'invalid').exists())
            for path in ('https://example.invalid/out','//server/share/out',r'\\server\share\out'):
                with patch.object(os,'open',side_effect=AssertionError('no remote file open')) as opened:s=view.export_view(path,*args[:3])
                self.assertEqual(s['state'],'INVALID');opened.assert_not_called()

    def test_17_example_reproduces(self):
        sample=json.loads((ROOT/'examples/editorial_review_view_example.json').read_text())
        s,f=view.build_view(sample['dossier'],sample['evidence_report'],sample['bridge_report'],existing_preview_input=sample['existing_preview_input'],locale=sample['locale'])
        self.assertEqual(s,sample['status']);self.assertEqual(f['view.json'],sample['view'])
        self.assertEqual(sample['example_kind'],'SYNTHETIC_ONLY')


if __name__=='__main__':unittest.main()
