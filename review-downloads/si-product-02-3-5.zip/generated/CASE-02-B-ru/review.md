# Редакторское рассмотрение — V1

Приватные записанные данные, не инструкции к выполнению. Структура/labels не доказывают истину, личность, права или допуск. Окончательное решение принимает человек.

## Тема и отдельные состояния

**Название темы**

```text
Можно ли доверять ИИ в медицинских советах?
```

**Исследовательский вопрос**

```text
Какие точные материалы нужны для рассмотрения обобщения о медицинских советах ИИ?
```

**Аудитория**

```text
Редактор учебного научно-популярного проекта
```

**Исследовательская готовность**

```text
NEEDS_INPUT
```

**SI eligibility — только supplied SI view**

```text
{
  "reason_codes": [
    "CENTRAL_CLAIM_UNSUPPORTED"
  ],
  "state": "BLOCKED"
}
```

**Производственное состояние — не допуск**

```text
NOT_ASSESSED
```

**Связь Research ↔ SI не доказана; recorded scope — заявление**

```text
{
  "correspondence_state": "UNVERIFIED_SCOPE",
  "declared_correspondence": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "dossier_sha256": "c90d6761d2113768f08e55f59007590776783c87e646ab5a69c2460ab782c8f5",
  "evidence_correspondence": "EXACT_REPLAY_MATCH",
  "evidence_report_sha256": "80be59617295f9bee3120f998b1c1a40a94caacb082e2c64a0ef81ad4e77f793",
  "frame_origin": "EXPLICIT",
  "frame_sha256": "024c3d14b7b43bf6530167129e681e5d16684540b5bf8ccdb1f0e84f32e582cf",
  "research_snapshot_sha256": "f50907ee3b7cf295f975c11b04897571ddc5f4a4a34cbf37380083a7f14163c0",
  "semantic_coverage_verified": false
}
```

**Критические замечания — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "081df937d43f5275b8d59a7e8ac9c8b9fcb5ac37ec4644f54846e454a4d58365",
      "id": "00000002-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_HUMAN",
    "delivery": "DELIVERED",
    "editor_action": "Передать точные источники и ограничения профильному человеку.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Два разных условных человека A и B в тестовой fixture."
    },
    "provenance": {
      "kind": "EDITOR_DECLARED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Critic B"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "CRITICAL",
    "target": {
      "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
      "id": "00000002-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какие точные материалы нужны для рассмотрения обобщения о медицинских советах ИИ?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Не использовать кейс как медицинскую рекомендацию."
      }
    }
  }
]
```

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "SOURCE_NOT_RETRIEVED",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
        "id": "00000002-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "FRAGMENT_UNCONFIRMED",
    "fragment_id": "F1",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
        "id": "00000002-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
        "id": "00000002-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "EVIDENCE_MISSING",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
        "id": "00000002-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
        "id": "00000002-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "081df937d43f5275b8d59a7e8ac9c8b9fcb5ac37ec4644f54846e454a4d58365",
        "id": "00000002-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
        "id": "00000002-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Записанное предложение и риски из input — не новое решение**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "recorded": {
    "editorial_risks": [],
    "gaps": [
      "Не использовать кейс как медицинскую рекомендацию.",
      "Передать точные источники и ограничения профильному человеку."
    ],
    "production_limits": {
      "state": "KNOWN",
      "value": [
        "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
      ]
    },
    "prospect": "RESEARCH_MORE",
    "reasons": [
      {
        "basis_claim_refs": [
          {
            "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
            "id": "00000002-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ],
        "kind": "RESEARCH_GAP",
        "text": "Требуется отдельное человеческое рассмотрение; данные только синтетические."
      }
    ],
    "scientific_risks": []
  },
  "source_ref": {
    "content_sha256": "e4a4f5600dee5208055b7e472eda8bce5b03aa3901e7d817d961b5634ddc66cd",
    "id": "00000002-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  },
  "state": "RECORDED"
}
```

Не хватает записанных данных; это не вердикт об истинности.

## Утверждения и доказательные связи

### Утверждение 1

**Исходный текст утверждения**

```text
Синтетический кейс 2: СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: тест содержит неподтверждённое обобщение о модели; это не клинические данные и не медицинский совет.
```

**Точный RRef**

```text
{
  "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
  "id": "00000002-0000-4000-8000-000000000002",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип и центральность (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "factual"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "details": {
    "reason": "Fixture: explicitly not supplied",
    "state": "UNKNOWN"
  },
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "NOT_REVIEWED"
}
```

**Неопределённость**

```text
{
  "level": "UNKNOWN",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Поддерживающие связи — не proof истины

NOT_RECORDED

#### Противоречащие связи

NOT_RECORDED

#### Контекстные/недостаточные связи

NOT_RECORDED

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "EVIDENCE_MISSING",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
        "id": "00000002-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
        "id": "00000002-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "081df937d43f5275b8d59a7e8ac9c8b9fcb5ac37ec4644f54846e454a4d58365",
        "id": "00000002-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
        "id": "00000002-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Критические замечания — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "081df937d43f5275b8d59a7e8ac9c8b9fcb5ac37ec4644f54846e454a4d58365",
      "id": "00000002-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_HUMAN",
    "delivery": "DELIVERED",
    "editor_action": "Передать точные источники и ограничения профильному человеку.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Два разных условных человека A и B в тестовой fixture."
    },
    "provenance": {
      "kind": "EDITOR_DECLARED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Critic B"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "CRITICAL",
    "target": {
      "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
      "id": "00000002-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какие точные материалы нужны для рассмотрения обобщения о медицинских советах ИИ?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Не использовать кейс как медицинскую рекомендацию."
      }
    }
  }
]
```

## Источники, фрагменты и ограничения

### Source 1

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точный RRef**

```text
{
  "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
  "id": "00000002-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Локатор как данные (не активная ссылка)**

```text
{
  "kind": "LOCAL_ID",
  "value": "synthetic-local-1"
}
```

**Автор / организация / даты — как предоставлены**

```text
{
  "author": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "organization": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "published_at": {
    "state": "KNOWN",
    "value": {
      "precision": "YEAR",
      "value": "2020"
    }
  },
  "retrieved_at": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "kind": "EDITOR_DECLARED",
  "method_label": {
    "state": "KNOWN",
    "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
  },
  "producer_label": {
    "state": "KNOWN",
    "value": "Researcher A"
  },
  "upstream_refs": []
}
```

**Пять независимых записанных observations**

```text
{
  "content": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "45c20db7e763fc05476194012d83a490b544ac1c13bf88f710920c4184bbb407"
    },
    "state": "NOT_REVIEWED"
  },
  "editor_confirmation": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "45c20db7e763fc05476194012d83a490b544ac1c13bf88f710920c4184bbb407"
    },
    "state": "NOT_REVIEWED"
  },
  "integrity": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "45c20db7e763fc05476194012d83a490b544ac1c13bf88f710920c4184bbb407"
    },
    "state": "HASH_REPORTED"
  },
  "link_existence": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "45c20db7e763fc05476194012d83a490b544ac1c13bf88f710920c4184bbb407"
    },
    "state": "NOT_CHECKED"
  },
  "retrieval": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "45c20db7e763fc05476194012d83a490b544ac1c13bf88f710920c4184bbb407"
    },
    "state": "NOT_RETRIEVED"
  }
}
```

**Ограничения**

```text
[
  "Искусственные данные для теста; не свидетельство о реальном мире."
]
```

**Фрагмент**

```text
F1
```

**Точный предоставленный текст — не verified quote**

UNKNOWN

```text
Fixture: explicitly not supplied
```

**Предоставленный указатель**

UNKNOWN

```text
Fixture: explicitly not supplied
```

**Точный RRef**

```text
{
  "state": "KNOWN",
  "value": "45c20db7e763fc05476194012d83a490b544ac1c13bf88f710920c4184bbb407"
}
```

## Действия редактора — порядок источников, не новый приоритет

### 1 — CONTROLLED_ACTION

```text
Получите материал вручную; URL не подтверждает получение.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[0]",
      "record_refs": [
        {
          "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
          "id": "00000002-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "579ce53860e4581f99a9b784341556690dea7f58180fbbbf0364347edd844a11",
      "source_action": {
        "action": {
          "ru": "Получите материал вручную; URL не подтверждает получение.",
          "uk": "Отримайте матеріал вручну; URL не підтверджує отримання."
        },
        "code": "SOURCE_NOT_RETRIEVED",
        "record_refs": [
          {
            "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
            "id": "00000002-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
      "id": "00000002-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 2 — CONTROLLED_ACTION

```text
Получите точный фрагмент и отдельно рассмотрите его контекст.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[1]",
      "record_refs": [
        {
          "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
          "id": "00000002-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "579ce53860e4581f99a9b784341556690dea7f58180fbbbf0364347edd844a11",
      "source_action": {
        "action": {
          "ru": "Получите точный фрагмент и отдельно рассмотрите его контекст.",
          "uk": "Отримайте точний фрагмент і окремо розгляньте його контекст."
        },
        "code": "FRAGMENT_UNCONFIRMED",
        "fragment_id": "F1",
        "record_refs": [
          {
            "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
            "id": "00000002-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
      "id": "00000002-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 3 — CONTROLLED_ACTION

```text
Отдельно рассмотрите основания пяти наблюдений и ограничения источника.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[2]",
      "record_refs": [
        {
          "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
          "id": "00000002-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "579ce53860e4581f99a9b784341556690dea7f58180fbbbf0364347edd844a11",
      "source_action": {
        "action": {
          "ru": "Отдельно рассмотрите основания пяти наблюдений и ограничения источника.",
          "uk": "Окремо розгляньте підстави п’яти спостережень та обмеження джерела."
        },
        "code": "SOURCE_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
            "id": "00000002-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "c438f07cdab7755100039d8cfbdb052cac0a55e74c6031359316d060ef1f79cc",
      "id": "00000002-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 4 — CONTROLLED_ACTION

```text
Добавьте точные основания утверждения; не заменяйте их рейтингом.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[3]",
      "record_refs": [
        {
          "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
          "id": "00000002-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "579ce53860e4581f99a9b784341556690dea7f58180fbbbf0364347edd844a11",
      "source_action": {
        "action": {
          "ru": "Добавьте точные основания утверждения; не заменяйте их рейтингом.",
          "uk": "Додайте точні підстави твердження; не замінюйте їх рейтингом."
        },
        "code": "EVIDENCE_MISSING",
        "record_refs": [
          {
            "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
            "id": "00000002-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
      "id": "00000002-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 5 — CONTROLLED_ACTION

```text
Запишите рассмотрение точных материалов и неопределённости утверждения.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[4]",
      "record_refs": [
        {
          "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
          "id": "00000002-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "579ce53860e4581f99a9b784341556690dea7f58180fbbbf0364347edd844a11",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
            "id": "00000002-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
      "id": "00000002-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 6 — CONTROLLED_ACTION

```text
Передайте существенные замечания человеку; сохраните разногласия.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[5]",
      "record_refs": [
        {
          "content_sha256": "081df937d43f5275b8d59a7e8ac9c8b9fcb5ac37ec4644f54846e454a4d58365",
          "id": "00000002-0000-4000-8000-000000000003",
          "research_type": "ResearchCritiqueV1",
          "revision": 1
        },
        {
          "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
          "id": "00000002-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "579ce53860e4581f99a9b784341556690dea7f58180fbbbf0364347edd844a11",
      "source_action": {
        "action": {
          "ru": "Передайте существенные замечания человеку; сохраните разногласия.",
          "uk": "Передайте суттєві зауваження людині; збережіть розбіжності."
        },
        "code": "CRITIQUE_HIGH",
        "record_refs": [
          {
            "content_sha256": "081df937d43f5275b8d59a7e8ac9c8b9fcb5ac37ec4644f54846e454a4d58365",
            "id": "00000002-0000-4000-8000-000000000003",
            "research_type": "ResearchCritiqueV1",
            "revision": 1
          },
          {
            "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
            "id": "00000002-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "081df937d43f5275b8d59a7e8ac9c8b9fcb5ac37ec4644f54846e454a4d58365",
      "id": "00000002-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
      "id": "00000002-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 7 — CONTROLLED_ACTION

```text
Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[6]",
      "record_refs": [],
      "sha256": "579ce53860e4581f99a9b784341556690dea7f58180fbbbf0364347edd844a11",
      "source_action": {
        "action": {
          "ru": "Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.",
          "uk": "Перед Topic Scoring передайте точний звіт редактору та розгляньте всі збережені зауваження; автоматичного допуску немає."
        },
        "code": "EDITOR_REVIEW_REQUIRED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 8 — CONTROLLED_ACTION

```text
Рассмотрите точное соответствие исследования и supplied SI; смысловой охват не доказан.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[7]",
      "record_refs": [],
      "sha256": "579ce53860e4581f99a9b784341556690dea7f58180fbbbf0364347edd844a11",
      "source_action": {
        "action": {
          "ru": "Рассмотрите точное соответствие исследования и supplied SI; смысловой охват не доказан.",
          "uk": "Розгляньте точну відповідність дослідження та supplied SI; змістове охоплення не доведено."
        },
        "code": "SCOPE_UNVERIFIED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 9 — CONTROLLED_ACTION

```text
Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[8]",
      "record_refs": [],
      "sha256": "579ce53860e4581f99a9b784341556690dea7f58180fbbbf0364347edd844a11",
      "source_action": {
        "action": {
          "ru": "Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.",
          "uk": "Людина розглядає всі дев’ять SI ratings і findings; preliminary ratings не імпортуються автоматично."
        },
        "code": "HUMAN_SI_REVIEW",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 10 — RECORDED_GAP

```text
Не использовать кейс как медицинскую рекомендацию.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[0]",
      "record_ref": {
        "content_sha256": "e4a4f5600dee5208055b7e472eda8bce5b03aa3901e7d817d961b5634ddc66cd",
        "id": "00000002-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "e4a4f5600dee5208055b7e472eda8bce5b03aa3901e7d817d961b5634ddc66cd",
      "id": "00000002-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 11 — RECORDED_GAP

```text
Передать точные источники и ограничения профильному человеку.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[1]",
      "record_ref": {
        "content_sha256": "e4a4f5600dee5208055b7e472eda8bce5b03aa3901e7d817d961b5634ddc66cd",
        "id": "00000002-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "e4a4f5600dee5208055b7e472eda8bce5b03aa3901e7d817d961b5634ddc66cd",
      "id": "00000002-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 12 — RECORDED_ACTION

```text
Не использовать кейс как медицинскую рекомендацию.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[0]",
      "record_ref": {
        "content_sha256": "e4a4f5600dee5208055b7e472eda8bce5b03aa3901e7d817d961b5634ddc66cd",
        "id": "00000002-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "e4a4f5600dee5208055b7e472eda8bce5b03aa3901e7d817d961b5634ddc66cd",
      "id": "00000002-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 13 — RECORDED_ACTION

```text
Передать точные источники и ограничения профильному человеку.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[1]",
      "record_ref": {
        "content_sha256": "e4a4f5600dee5208055b7e472eda8bce5b03aa3901e7d817d961b5634ddc66cd",
        "id": "00000002-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchCritiqueV1",
      "field_path": "$.payload.editor_action",
      "record_ref": {
        "content_sha256": "081df937d43f5275b8d59a7e8ac9c8b9fcb5ac37ec4644f54846e454a4d58365",
        "id": "00000002-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "e4a4f5600dee5208055b7e472eda8bce5b03aa3901e7d817d961b5634ddc66cd",
      "id": "00000002-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    },
    {
      "content_sha256": "081df937d43f5275b8d59a7e8ac9c8b9fcb5ac37ec4644f54846e454a4d58365",
      "id": "00000002-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
      "id": "00000002-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 14 — RECORDED_ACTION

```text
Получить реальные материалы вручную.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
        "id": "00000002-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "37df274edb1f8028b6f488f662498b3dc14f235af75a7126e60cd4c10b70c4bf",
      "id": "00000002-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

## Только записанные творческие предложения

RECORDED

**Точный RRef**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "source_ref": {
    "content_sha256": "e4a4f5600dee5208055b7e472eda8bce5b03aa3901e7d817d961b5634ddc66cd",
    "id": "00000002-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  }
}
```

**Записанный основной ракурс**

```text
Какие точные материалы нужны для рассмотрения обобщения о медицинских советах ИИ?
```

### Альтернативные ракурсы

NOT_RECORDED

### Эмоциональные хуки

NOT_RECORDED

### Интеллектуальные хуки

NOT_RECORDED

**Записанный повествовательный потенциал**

UNKNOWN

```text
Не предоставлено; не восстановлено автоматически.
```

**Записанные визуальные потребности — не готовые assets/права**

```text
NOT_RECORDED
```

**Ограничения**

```text
[
  "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
]
```

**Структурированные narrative alternatives — поля нет в принятом input**

```text
{
  "reason": "NO_STRUCTURED_FIELD_IN_ACCEPTED_INPUT",
  "state": "NOT_RECORDED"
}
```

## Неизменённая SI оценка supplied frame

```text
OK
```

### Существующая Projection card — только supplied SI view

**decision_summary**

```text
Продолжение творческой разработки заблокировано отмеченными условиями.
```

**reasons**

```text
Основание — условия, зафиксированные оценкой переданных данных.
```

```text
Баллы по заданной рубрике: 1000 из 1000.
```

```text
Проверка утверждения 1: Проверка центрального фактического утверждения остаётся нерешённой или недостаточной.
```

**blocking_risks_and_gaps**

```text
Проверка утверждения 1: Проверка центрального фактического утверждения остаётся нерешённой или недостаточной.
```

**next_actions**

```text
Проверка утверждения 1: Исследуйте утверждение и противоречащие данные; передайте существенные разногласия на рассмотрение человеку.
```

**limitations**

```text
Карточка поясняет только оценку переданного контекста; полнота внешних данных не установлена.
```

```text
Баллы и уверенность не доказывают научную истинность, достоверность источников или спрос аудитории.
```

```text
Рассмотрение научных выводов человеком и всех семи областей научной проверки этой карточкой не удостоверяется.
```

```text
Права на материалы, фактическая доступность и выполнимость производства требуют отдельной проверки.
```

```text
Карточка не удостоверяет личность, компетентность или полномочия проверяющего и не предоставляет редакционного утверждения.
```

```text
Допуск к творческой разработке не является разрешением на производство или публикацию.
```

| Критерий | Вес | Исходная SI оценка | Confidence |
|---|---:|---|---|
| Интерес аудитории | 15 | 5 | HIGH |
| Соответствие каналу | 10 | 5 | HIGH |
| Новизна ракурса | 10 | 5 | HIGH |
| Качество оснований | 20 | 5 | HIGH |
| Повествовательный потенциал | 15 | 5 | HIGH |
| Визуальная осуществимость | 10 | 5 | HIGH |
| Соответствие ресурсам | 10 | 5 | HIGH |
| Управляемость рисков | 5 | 5 | HIGH |
| Отличие от портфеля | 5 | 5 | HIGH |

**Интерес аудитории**

```text
Synthetic supplied rating
```

**Соответствие каналу**

```text
Synthetic supplied rating
```

**Новизна ракурса**

```text
Synthetic supplied rating
```

**Качество оснований**

```text
Synthetic supplied rating
```

**Повествовательный потенциал**

```text
Synthetic supplied rating
```

**Визуальная осуществимость**

```text
Synthetic supplied rating
```

**Соответствие ресурсам**

```text
Synthetic supplied rating
```

**Управляемость рисков**

```text
Synthetic supplied rating
```

**Отличие от портфеля**

```text
Synthetic supplied rating
```

**Исходный aggregate_tenths — без пересчёта шкалы**

```text
{
  "state": "KNOWN",
  "value": 1000
}
```

**Существующий результат evaluator (не решение человека)**

```text
{
  "currentness": "CURRENT",
  "diagnostics": [
    {
      "code": "CENTRAL_CLAIM_UNSUPPORTED",
      "field_path": "$.records[10].payload.state",
      "input_ref": {
        "id": "0000000b-2222-4222-8222-222222222222",
        "revision": 1,
        "sha256": "1999a36208c8ad15503833535cfb17583434ecf2673d1eb1c363058830cc31ee",
        "type": "ClaimCheck"
      },
      "message": "A central factual claim has unresolved review."
    }
  ],
  "eligibility": {
    "reason_codes": [
      "CENTRAL_CLAIM_UNSUPPORTED"
    ],
    "state": "BLOCKED"
  },
  "status": "OK"
}
```

**Research preliminary ratings — НЕ SI ratings**

```text
[
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "audience_interest",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "channel_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "angle_novelty",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "evidence_quality",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "narrative_potential",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "visual_feasibility",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "resource_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "risk_manageability",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "portfolio_distinctness",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  }
]
```

## Ограничения

- SI результат относится только к supplied SI view, не к доказанному охвату исследования.
- Correspondence фиксирует заявление, не semantic equivalence или авторство.
- Research readiness не является SI eligibility или разрешением Topic Scoring.
- Баллы и critique labels не доказывают научную истину, фактическую проверку или независимость человека.
- Редактор принимает решение; bridge не создаёт рекомендацию, human findings или approval.
- Нет правового, коммерческого, публикационного или производственного разрешения.

## Незаполненный бланк решения человека

Бланк не подтверждает состоявшийся review. Ничего не выбрано и не датировано программой.

- [ ] Develop
- [ ] Research Further
- [ ] Reframe
- [ ] Reject
- [ ] Defer

**Обоснование:** ____________________

**Нерешённые риски:** ____________________

**Выбранный ракурс:** ____________________

**Следующие действия:** ____________________

**Личность редактора (заполнить вручную):** ____________________

**Дата review:** ____________________

HUMAN_PILOT_PENDING
