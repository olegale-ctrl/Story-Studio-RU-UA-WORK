# Редакторское рассмотрение — V1

Приватные записанные данные, не инструкции к выполнению. Структура/labels не доказывают истину, личность, права или допуск. Окончательное решение принимает человек.

## Тема и отдельные состояния

**Название темы**

```text
Почему самолёты не падают при турбулентности?
```

**Исследовательский вопрос**

```text
Как заменить абсолютную формулировку ограниченным объяснительным вопросом?
```

**Аудитория**

```text
Редактор учебного научно-популярного проекта
```

**Исследовательская готовность**

```text
NEEDS_REVIEW
```

**SI eligibility — только supplied SI view**

```text
{
  "reason_codes": [],
  "state": "ELIGIBLE_FOR_CREATIVE"
}
```

**Производственное состояние — не допуск**

```text
NOT_ASSESSED
```

**Связь Research ↔ SI не доказана; recorded scope — заявление**

```text
{
  "correspondence_state": "UNVERIFIED_SCOPE",
  "declared_correspondence": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "dossier_sha256": "7bf5a0e005611599db61496bb317d55a118f260fe9579488abe9b33f01cf2b82",
  "evidence_correspondence": "EXACT_REPLAY_MATCH",
  "evidence_report_sha256": "a3331f1ae8b223279cf383bf0cf8f2f04f2a8d68731ca0efd1cf00c112051a2d",
  "frame_origin": "EXPLICIT",
  "frame_sha256": "a18caf09a04efffcf2b031e31bade9a68cb3a6372d7b003e37daf76b47405fbc",
  "research_snapshot_sha256": "20f4a4224f4684157ebae1c51d35893566457d7a1168610cfcf3acd843bbbd49",
  "semantic_coverage_verified": false
}
```

**Критические замечания — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "e70c7d893a9427b71ad7b2d7cbdccd3d15a63b29a89b87cb40a8aa690a0828a8",
      "id": "00000003-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_HUMAN",
    "delivery": "DELIVERED",
    "editor_action": "Отдельно рассмотреть применимость учебной аналогии и права на визуальные материалы.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Два разных условных человека A и B в тестовой fixture."
    },
    "provenance": {
      "kind": "EDITOR_DECLARED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Critic B"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
      "id": "00000003-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Как заменить абсолютную формулировку ограниченным объяснительным вопросом?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Уточнить абсолютную формулировку заголовка."
      }
    }
  }
]
```

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "02810e1768df23c8b4ddda24007087f50f7d26c1aaea4f4696d83bd46f5789c4",
        "id": "00000003-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
        "id": "00000003-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "e70c7d893a9427b71ad7b2d7cbdccd3d15a63b29a89b87cb40a8aa690a0828a8",
        "id": "00000003-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
        "id": "00000003-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Записанное предложение и риски из input — не новое решение**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "recorded": {
    "editorial_risks": [],
    "gaps": [
      "Уточнить абсолютную формулировку заголовка.",
      "Отдельно рассмотреть применимость учебной аналогии и права на визуальные материалы."
    ],
    "production_limits": {
      "state": "KNOWN",
      "value": [
        "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
      ]
    },
    "prospect": "RESEARCH_MORE",
    "reasons": [
      {
        "basis_claim_refs": [
          {
            "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
            "id": "00000003-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ],
        "kind": "RESEARCH_GAP",
        "text": "Требуется отдельное человеческое рассмотрение; данные только синтетические."
      }
    ],
    "scientific_risks": []
  },
  "source_ref": {
    "content_sha256": "98b321cefab6fc893c88754e11074f690ad54858921ca82304252850403a3591",
    "id": "00000003-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  },
  "state": "RECORDED"
}
```

Предоставленные данные требуют рассмотрения человеком.

## Утверждения и доказательные связи

### Утверждение 1

**Исходный текст утверждения**

```text
Синтетический кейс 3: СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: учебная аналогия колебаний требует ограничить формулировки; она не описывает реальный полёт.
```

**Точный RRef**

```text
{
  "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
  "id": "00000003-0000-4000-8000-000000000002",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип и центральность (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "factual"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "details": {
    "state": "KNOWN",
    "value": {
      "reason": "Учебная фиксация рассмотрения, не аутентификация.",
      "reviewed_at": {
        "reason": "Не предоставлено; не восстановлено автоматически.",
        "state": "UNKNOWN"
      },
      "reviewed_source_refs": [
        {
          "content_sha256": "02810e1768df23c8b4ddda24007087f50f7d26c1aaea4f4696d83bd46f5789c4",
          "id": "00000003-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "reviewer_label": "Researcher A"
    }
  },
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "EDITOR_REVIEW_RECORDED"
}
```

**Неопределённость**

```text
{
  "level": "HIGH",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Поддерживающие связи — не proof истины

[Источник 1](#source-1)

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точный RRef**

```text
{
  "content_sha256": "02810e1768df23c8b4ddda24007087f50f7d26c1aaea4f4696d83bd46f5789c4",
  "id": "00000003-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записанное основание связи**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Противоречащие связи

NOT_RECORDED

#### Контекстные/недостаточные связи

NOT_RECORDED

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "02810e1768df23c8b4ddda24007087f50f7d26c1aaea4f4696d83bd46f5789c4",
        "id": "00000003-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
        "id": "00000003-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "e70c7d893a9427b71ad7b2d7cbdccd3d15a63b29a89b87cb40a8aa690a0828a8",
        "id": "00000003-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
        "id": "00000003-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Критические замечания — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "e70c7d893a9427b71ad7b2d7cbdccd3d15a63b29a89b87cb40a8aa690a0828a8",
      "id": "00000003-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_HUMAN",
    "delivery": "DELIVERED",
    "editor_action": "Отдельно рассмотреть применимость учебной аналогии и права на визуальные материалы.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Два разных условных человека A и B в тестовой fixture."
    },
    "provenance": {
      "kind": "EDITOR_DECLARED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Critic B"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
      "id": "00000003-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Как заменить абсолютную формулировку ограниченным объяснительным вопросом?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Уточнить абсолютную формулировку заголовка."
      }
    }
  }
]
```

## Источники, фрагменты и ограничения

### Source 1

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точный RRef**

```text
{
  "content_sha256": "02810e1768df23c8b4ddda24007087f50f7d26c1aaea4f4696d83bd46f5789c4",
  "id": "00000003-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Локатор как данные (не активная ссылка)**

```text
{
  "kind": "LOCAL_ID",
  "value": "synthetic-local-1"
}
```

**Автор / организация / даты — как предоставлены**

```text
{
  "author": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "organization": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "published_at": {
    "state": "KNOWN",
    "value": {
      "precision": "YEAR",
      "value": "2020"
    }
  },
  "retrieved_at": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "kind": "EDITOR_DECLARED",
  "method_label": {
    "state": "KNOWN",
    "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
  },
  "producer_label": {
    "state": "KNOWN",
    "value": "Researcher A"
  },
  "upstream_refs": []
}
```

**Пять независимых записанных observations**

```text
{
  "content": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "eb34d081169c4fa27b323047953edbb295dbaf2ac7b0c1a25256b2a6119c8753"
    },
    "state": "CONTEXT_REVIEW_REPORTED"
  },
  "editor_confirmation": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "eb34d081169c4fa27b323047953edbb295dbaf2ac7b0c1a25256b2a6119c8753"
    },
    "state": "CONFIRMED_AS_RECORDED"
  },
  "integrity": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "eb34d081169c4fa27b323047953edbb295dbaf2ac7b0c1a25256b2a6119c8753"
    },
    "state": "HASH_REPORTED"
  },
  "link_existence": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "eb34d081169c4fa27b323047953edbb295dbaf2ac7b0c1a25256b2a6119c8753"
    },
    "state": "RESOLVED"
  },
  "retrieval": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "eb34d081169c4fa27b323047953edbb295dbaf2ac7b0c1a25256b2a6119c8753"
    },
    "state": "RETRIEVED"
  }
}
```

**Ограничения**

```text
[
  "Искусственные данные для теста; не свидетельство о реальном мире."
]
```

**Фрагмент**

```text
F1
```

**Точный предоставленный текст — не verified quote**

```text
СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: учебная аналогия колебаний требует ограничить формулировки; она не описывает реальный полёт.
```

**Предоставленный указатель**

```text
Синтетический параграф 1
```

**Точный RRef**

```text
{
  "state": "KNOWN",
  "value": "eb34d081169c4fa27b323047953edbb295dbaf2ac7b0c1a25256b2a6119c8753"
}
```

## Действия редактора — порядок источников, не новый приоритет

### 1 — CONTROLLED_ACTION

```text
Отдельно рассмотрите основания пяти наблюдений и ограничения источника.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[0]",
      "record_refs": [
        {
          "content_sha256": "02810e1768df23c8b4ddda24007087f50f7d26c1aaea4f4696d83bd46f5789c4",
          "id": "00000003-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "29df80678fd1546a62c4dfa7c1e733f71d0e62946327383acf08c9a598fd15ae",
      "source_action": {
        "action": {
          "ru": "Отдельно рассмотрите основания пяти наблюдений и ограничения источника.",
          "uk": "Окремо розгляньте підстави п’яти спостережень та обмеження джерела."
        },
        "code": "SOURCE_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "02810e1768df23c8b4ddda24007087f50f7d26c1aaea4f4696d83bd46f5789c4",
            "id": "00000003-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "02810e1768df23c8b4ddda24007087f50f7d26c1aaea4f4696d83bd46f5789c4",
      "id": "00000003-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 2 — CONTROLLED_ACTION

```text
Запишите рассмотрение точных материалов и неопределённости утверждения.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[1]",
      "record_refs": [
        {
          "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
          "id": "00000003-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "29df80678fd1546a62c4dfa7c1e733f71d0e62946327383acf08c9a598fd15ae",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
            "id": "00000003-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
      "id": "00000003-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 3 — CONTROLLED_ACTION

```text
Передайте существенные замечания человеку; сохраните разногласия.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[2]",
      "record_refs": [
        {
          "content_sha256": "e70c7d893a9427b71ad7b2d7cbdccd3d15a63b29a89b87cb40a8aa690a0828a8",
          "id": "00000003-0000-4000-8000-000000000003",
          "research_type": "ResearchCritiqueV1",
          "revision": 1
        },
        {
          "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
          "id": "00000003-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "29df80678fd1546a62c4dfa7c1e733f71d0e62946327383acf08c9a598fd15ae",
      "source_action": {
        "action": {
          "ru": "Передайте существенные замечания человеку; сохраните разногласия.",
          "uk": "Передайте суттєві зауваження людині; збережіть розбіжності."
        },
        "code": "CRITIQUE_HIGH",
        "record_refs": [
          {
            "content_sha256": "e70c7d893a9427b71ad7b2d7cbdccd3d15a63b29a89b87cb40a8aa690a0828a8",
            "id": "00000003-0000-4000-8000-000000000003",
            "research_type": "ResearchCritiqueV1",
            "revision": 1
          },
          {
            "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
            "id": "00000003-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "e70c7d893a9427b71ad7b2d7cbdccd3d15a63b29a89b87cb40a8aa690a0828a8",
      "id": "00000003-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
      "id": "00000003-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 4 — CONTROLLED_ACTION

```text
Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[3]",
      "record_refs": [],
      "sha256": "29df80678fd1546a62c4dfa7c1e733f71d0e62946327383acf08c9a598fd15ae",
      "source_action": {
        "action": {
          "ru": "Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.",
          "uk": "Перед Topic Scoring передайте точний звіт редактору та розгляньте всі збережені зауваження; автоматичного допуску немає."
        },
        "code": "EDITOR_REVIEW_REQUIRED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 5 — CONTROLLED_ACTION

```text
Рассмотрите точное соответствие исследования и supplied SI; смысловой охват не доказан.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[4]",
      "record_refs": [],
      "sha256": "29df80678fd1546a62c4dfa7c1e733f71d0e62946327383acf08c9a598fd15ae",
      "source_action": {
        "action": {
          "ru": "Рассмотрите точное соответствие исследования и supplied SI; смысловой охват не доказан.",
          "uk": "Розгляньте точну відповідність дослідження та supplied SI; змістове охоплення не доведено."
        },
        "code": "SCOPE_UNVERIFIED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 6 — CONTROLLED_ACTION

```text
Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[5]",
      "record_refs": [],
      "sha256": "29df80678fd1546a62c4dfa7c1e733f71d0e62946327383acf08c9a598fd15ae",
      "source_action": {
        "action": {
          "ru": "Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.",
          "uk": "Людина розглядає всі дев’ять SI ratings і findings; preliminary ratings не імпортуються автоматично."
        },
        "code": "HUMAN_SI_REVIEW",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 7 — RECORDED_GAP

```text
Уточнить абсолютную формулировку заголовка.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[0]",
      "record_ref": {
        "content_sha256": "98b321cefab6fc893c88754e11074f690ad54858921ca82304252850403a3591",
        "id": "00000003-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "98b321cefab6fc893c88754e11074f690ad54858921ca82304252850403a3591",
      "id": "00000003-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 8 — RECORDED_GAP

```text
Отдельно рассмотреть применимость учебной аналогии и права на визуальные материалы.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[1]",
      "record_ref": {
        "content_sha256": "98b321cefab6fc893c88754e11074f690ad54858921ca82304252850403a3591",
        "id": "00000003-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "98b321cefab6fc893c88754e11074f690ad54858921ca82304252850403a3591",
      "id": "00000003-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 9 — RECORDED_ACTION

```text
Уточнить абсолютную формулировку заголовка.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[0]",
      "record_ref": {
        "content_sha256": "98b321cefab6fc893c88754e11074f690ad54858921ca82304252850403a3591",
        "id": "00000003-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "98b321cefab6fc893c88754e11074f690ad54858921ca82304252850403a3591",
      "id": "00000003-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 10 — RECORDED_ACTION

```text
Отдельно рассмотреть применимость учебной аналогии и права на визуальные материалы.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[1]",
      "record_ref": {
        "content_sha256": "98b321cefab6fc893c88754e11074f690ad54858921ca82304252850403a3591",
        "id": "00000003-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchCritiqueV1",
      "field_path": "$.payload.editor_action",
      "record_ref": {
        "content_sha256": "e70c7d893a9427b71ad7b2d7cbdccd3d15a63b29a89b87cb40a8aa690a0828a8",
        "id": "00000003-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "98b321cefab6fc893c88754e11074f690ad54858921ca82304252850403a3591",
      "id": "00000003-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    },
    {
      "content_sha256": "e70c7d893a9427b71ad7b2d7cbdccd3d15a63b29a89b87cb40a8aa690a0828a8",
      "id": "00000003-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
      "id": "00000003-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 11 — RECORDED_ACTION

```text
Получить реальные материалы вручную.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
        "id": "00000003-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
      "id": "00000003-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

## Только записанные творческие предложения

RECORDED

**Точный RRef**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "source_ref": {
    "content_sha256": "98b321cefab6fc893c88754e11074f690ad54858921ca82304252850403a3591",
    "id": "00000003-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  }
}
```

**Записанный основной ракурс**

```text
Как заменить абсолютную формулировку ограниченным объяснительным вопросом?
```

### Альтернативные ракурсы

```text
Сузить вопрос до конкретного примера: Как заменить абсолютную формулировку ограниченным объяснительным вопросом?
```

**Точный RRef**

```text
[
  {
    "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
    "id": "00000003-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Ограничения**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

### Эмоциональные хуки

```text
Наблюдение и его объяснение — разные вопросы.
```

**Точный RRef**

```text
[
  {
    "content_sha256": "54ac76bb02c99ae55c586127ba9fdb4977c4f3863d2f40dd8d26dfd99b408db9",
    "id": "00000003-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Ограничения**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

### Интеллектуальные хуки

NOT_RECORDED

**Записанный повествовательный потенциал**

UNKNOWN

```text
Не предоставлено; не восстановлено автоматически.
```

**Записанные визуальные потребности — не готовые assets/права**

```text
[
  "Помеченная учебная схема; реальные материалы/права не предоставлены."
]
```

**Ограничения**

```text
[
  "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
]
```

**Структурированные narrative alternatives — поля нет в принятом input**

```text
{
  "reason": "NO_STRUCTURED_FIELD_IN_ACCEPTED_INPUT",
  "state": "NOT_RECORDED"
}
```

## Неизменённая SI оценка supplied frame

```text
OK
```

### Существующая Projection card — только supplied SI view

**decision_summary**

```text
Можно продолжить творческую разработку в пределах этой оценки. Эта оценка не предоставляет допуска к производству.
```

**reasons**

```text
Основание — условия, зафиксированные оценкой переданных данных.
```

```text
Баллы по заданной рубрике: 1000 из 1000.
```

```text
В этой оценке не осталось отмеченных условий, препятствующих творческой разработке.
```

**blocking_risks_and_gaps**

**next_actions**

```text
Редактору следует решить, продолжать ли творческую разработку.
```

**limitations**

```text
Карточка поясняет только оценку переданного контекста; полнота внешних данных не установлена.
```

```text
Баллы и уверенность не доказывают научную истинность, достоверность источников или спрос аудитории.
```

```text
Рассмотрение научных выводов человеком и всех семи областей научной проверки этой карточкой не удостоверяется.
```

```text
Права на материалы, фактическая доступность и выполнимость производства требуют отдельной проверки.
```

```text
Карточка не удостоверяет личность, компетентность или полномочия проверяющего и не предоставляет редакционного утверждения.
```

```text
Допуск к творческой разработке не является разрешением на производство или публикацию.
```

| Критерий | Вес | Исходная SI оценка | Confidence |
|---|---:|---|---|
| Интерес аудитории | 15 | 5 | HIGH |
| Соответствие каналу | 10 | 5 | HIGH |
| Новизна ракурса | 10 | 5 | HIGH |
| Качество оснований | 20 | 5 | HIGH |
| Повествовательный потенциал | 15 | 5 | HIGH |
| Визуальная осуществимость | 10 | 5 | HIGH |
| Соответствие ресурсам | 10 | 5 | HIGH |
| Управляемость рисков | 5 | 5 | HIGH |
| Отличие от портфеля | 5 | 5 | HIGH |

**Интерес аудитории**

```text
Synthetic supplied rating
```

**Соответствие каналу**

```text
Synthetic supplied rating
```

**Новизна ракурса**

```text
Synthetic supplied rating
```

**Качество оснований**

```text
Synthetic supplied rating
```

**Повествовательный потенциал**

```text
Synthetic supplied rating
```

**Визуальная осуществимость**

```text
Synthetic supplied rating
```

**Соответствие ресурсам**

```text
Synthetic supplied rating
```

**Управляемость рисков**

```text
Synthetic supplied rating
```

**Отличие от портфеля**

```text
Synthetic supplied rating
```

**Исходный aggregate_tenths — без пересчёта шкалы**

```text
{
  "state": "KNOWN",
  "value": 1000
}
```

**Существующий результат evaluator (не решение человека)**

```text
{
  "currentness": "CURRENT",
  "diagnostics": [],
  "eligibility": {
    "reason_codes": [],
    "state": "ELIGIBLE_FOR_CREATIVE"
  },
  "status": "OK"
}
```

**Research preliminary ratings — НЕ SI ratings**

```text
[
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "audience_interest",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "channel_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "angle_novelty",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "evidence_quality",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "narrative_potential",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "visual_feasibility",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "resource_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "risk_manageability",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "portfolio_distinctness",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  }
]
```

## Ограничения

- SI результат относится только к supplied SI view, не к доказанному охвату исследования.
- Correspondence фиксирует заявление, не semantic equivalence или авторство.
- Research readiness не является SI eligibility или разрешением Topic Scoring.
- Баллы и critique labels не доказывают научную истину, фактическую проверку или независимость человека.
- Редактор принимает решение; bridge не создаёт рекомендацию, human findings или approval.
- Нет правового, коммерческого, публикационного или производственного разрешения.

## Незаполненный бланк решения человека

Бланк не подтверждает состоявшийся review. Ничего не выбрано и не датировано программой.

- [ ] Develop
- [ ] Research Further
- [ ] Reframe
- [ ] Reject
- [ ] Defer

**Обоснование:** ____________________

**Нерешённые риски:** ____________________

**Выбранный ракурс:** ____________________

**Следующие действия:** ____________________

**Личность редактора (заполнить вручную):** ____________________

**Дата review:** ____________________

HUMAN_PILOT_PENDING
