# Редакторское рассмотрение — V1

Приватные записанные данные, не инструкции к выполнению. Структура/labels не доказывают истину, личность, права или допуск. Окончательное решение принимает человек.

## Тема и отдельные состояния

**Название темы**

```text
Загадочные сигналы из космоса
```

**Исследовательский вопрос**

```text
Какие объяснения условного наблюдения S допустимо сопоставлять без сенсационности?
```

**Аудитория**

```text
Редактор учебного научно-популярного проекта
```

**Исследовательская готовность**

```text
NEEDS_INPUT
```

**SI eligibility — только supplied SI view**

```text
{
  "reason_codes": [
    "EVIDENCE_NEEDED"
  ],
  "state": "NEEDS_RESEARCH"
}
```

**Производственное состояние — не допуск**

```text
NOT_ASSESSED
```

**Связь Research ↔ SI не доказана; recorded scope — заявление**

```text
{
  "correspondence_state": "UNVERIFIED_SCOPE",
  "declared_correspondence": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "dossier_sha256": "784c6bd399ac20cfdf070dbd4f3acd51cea07c7c9f0f037608fba9eb41ae3f8a",
  "evidence_correspondence": "EXACT_REPLAY_MATCH",
  "evidence_report_sha256": "24c03eaed0f4bf9228137690bd171f649cb6076b0c64b8b692baa1f32cfa38ad",
  "frame_origin": "EXPLICIT",
  "frame_sha256": "351fa31f21e76139290475c4f33620f954e5f634328b40b6695ef2ea26dc7938",
  "research_snapshot_sha256": "b869c5dcfd9e2368b2b6eb20859a03cefff48fefc341babf037eab4e9a097466",
  "semantic_coverage_verified": false
}
```

**Критические замечания — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
      "id": "00000004-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_RUN_SAME_PROVIDER",
    "delivery": "DELIVERED",
    "editor_action": "Получить отдельную человеческую критику гипотезы I.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Only synthetic metadata; no actual model run."
    },
    "provenance": {
      "kind": "MODEL_PROPOSED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Synthetic model proposal, NO provider execution"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какие объяснения условного наблюдения S допустимо сопоставлять без сенсационности?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Найти первичный материал вручную и отметить зависимости перепечаток."
      }
    }
  }
]
```

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "SOURCE_NOT_RETRIEVED",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_NOT_RETRIEVED",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "MATERIAL_REUSED",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      },
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
        "id": "00000004-0000-4000-8000-000000000007",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_INDEPENDENCE_UNKNOWN",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
        "id": "00000004-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
        "id": "00000004-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Записанное предложение и риски из input — не новое решение**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "recorded": {
    "editorial_risks": [],
    "gaps": [
      "Найти первичный материал вручную и отметить зависимости перепечаток.",
      "Получить отдельную человеческую критику гипотезы I."
    ],
    "production_limits": {
      "state": "KNOWN",
      "value": [
        "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
      ]
    },
    "prospect": "RESEARCH_MORE",
    "reasons": [
      {
        "basis_claim_refs": [
          {
            "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
            "id": "00000004-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ],
        "kind": "RESEARCH_GAP",
        "text": "Требуется отдельное человеческое рассмотрение; данные только синтетические."
      }
    ],
    "scientific_risks": []
  },
  "source_ref": {
    "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
    "id": "00000004-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  },
  "state": "RECORDED"
}
```

Не хватает записанных данных; это не вердикт об истинности.

## Утверждения и доказательные связи

### Утверждение 1

**Исходный текст утверждения**

```text
Синтетический кейс 4: СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: условное наблюдение S отделено от гипотезы I; происхождение реальных космических сигналов здесь не установлено.
```

**Точный RRef**

```text
{
  "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
  "id": "00000004-0000-4000-8000-000000000002",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип и центральность (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "factual"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "details": {
    "reason": "Fixture: explicitly not supplied",
    "state": "UNKNOWN"
  },
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "NOT_REVIEWED"
}
```

**Неопределённость**

```text
{
  "level": "UNKNOWN",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Поддерживающие связи — не proof истины

[Источник 1](#source-1)

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точный RRef**

```text
{
  "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
  "id": "00000004-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записанное основание связи**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Противоречащие связи

NOT_RECORDED

#### Контекстные/недостаточные связи

NOT_RECORDED

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "SOURCE_NOT_RETRIEVED",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "MATERIAL_REUSED",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      },
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_INDEPENDENCE_UNKNOWN",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
        "id": "00000004-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
        "id": "00000004-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Критические замечания — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
      "id": "00000004-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_RUN_SAME_PROVIDER",
    "delivery": "DELIVERED",
    "editor_action": "Получить отдельную человеческую критику гипотезы I.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Only synthetic metadata; no actual model run."
    },
    "provenance": {
      "kind": "MODEL_PROPOSED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Synthetic model proposal, NO provider execution"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какие объяснения условного наблюдения S допустимо сопоставлять без сенсационности?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Найти первичный материал вручную и отметить зависимости перепечаток."
      }
    }
  }
]
```

### Утверждение 2

**Исходный текст утверждения**

```text
СИНТЕТИЧЕСКАЯ редакционная интерпретация: Какие объяснения условного наблюдения S допустимо сопоставлять без сенсационности?
```

**Точный RRef**

```text
{
  "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
  "id": "00000004-0000-4000-8000-000000000007",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип и центральность (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "interpretation"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "details": {
    "reason": "Fixture: explicitly not supplied",
    "state": "UNKNOWN"
  },
  "provenance": {
    "kind": "MODEL_PROPOSED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "NOT_REVIEWED"
}
```

**Неопределённость**

```text
{
  "level": "UNKNOWN",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Поддерживающие связи — не proof истины

[Источник 2](#source-2)

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 91
```

**Точный RRef**

```text
{
  "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
  "id": "00000004-0000-4000-8000-000000000006",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записанное основание связи**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Противоречащие связи

NOT_RECORDED

#### Контекстные/недостаточные связи

NOT_RECORDED

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "SOURCE_NOT_RETRIEVED",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "MATERIAL_REUSED",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      },
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
        "id": "00000004-0000-4000-8000-000000000007",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  }
]
```

**Критические замечания — unresolved/declared**

```text
[]
```

## Источники, фрагменты и ограничения

### Source 1

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точный RRef**

```text
{
  "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
  "id": "00000004-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Локатор как данные (не активная ссылка)**

```text
{
  "kind": "LOCAL_ID",
  "value": "synthetic-local-1"
}
```

**Автор / организация / даты — как предоставлены**

```text
{
  "author": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "organization": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "published_at": {
    "state": "KNOWN",
    "value": {
      "precision": "YEAR",
      "value": "2020"
    }
  },
  "retrieved_at": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "kind": "EDITOR_DECLARED",
  "method_label": {
    "state": "KNOWN",
    "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
  },
  "producer_label": {
    "state": "KNOWN",
    "value": "Researcher A"
  },
  "upstream_refs": []
}
```

**Пять независимых записанных observations**

```text
{
  "content": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_REVIEWED"
  },
  "editor_confirmation": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_REVIEWED"
  },
  "integrity": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "HASH_REPORTED"
  },
  "link_existence": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_CHECKED"
  },
  "retrieval": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_RETRIEVED"
  }
}
```

**Ограничения**

```text
[
  "Искусственные данные для теста; не свидетельство о реальном мире."
]
```

**Фрагмент**

```text
F1
```

**Точный предоставленный текст — не verified quote**

```text
СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: условное наблюдение S отделено от гипотезы I; происхождение реальных космических сигналов здесь не установлено.
```

**Предоставленный указатель**

```text
Синтетический параграф 1
```

**Точный RRef**

```text
{
  "state": "KNOWN",
  "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
}
```

### Source 2

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 91
```

**Точный RRef**

```text
{
  "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
  "id": "00000004-0000-4000-8000-000000000006",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Локатор как данные (не активная ссылка)**

```text
{
  "kind": "LOCAL_ID",
  "value": "synthetic-local-91"
}
```

**Автор / организация / даты — как предоставлены**

```text
{
  "author": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "organization": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "published_at": {
    "state": "KNOWN",
    "value": {
      "precision": "YEAR",
      "value": "2020"
    }
  },
  "retrieved_at": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "kind": "EDITOR_DECLARED",
  "method_label": {
    "state": "KNOWN",
    "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
  },
  "producer_label": {
    "state": "KNOWN",
    "value": "Researcher A"
  },
  "upstream_refs": [
    {
      "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
      "id": "00000004-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

**Пять независимых записанных observations**

```text
{
  "content": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_REVIEWED"
  },
  "editor_confirmation": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_REVIEWED"
  },
  "integrity": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "HASH_REPORTED"
  },
  "link_existence": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_CHECKED"
  },
  "retrieval": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_RETRIEVED"
  }
}
```

**Ограничения**

```text
[
  "Искусственные данные для теста; не свидетельство о реальном мире."
]
```

**Фрагмент**

```text
F1
```

**Точный предоставленный текст — не verified quote**

```text
СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: условное наблюдение S отделено от гипотезы I; происхождение реальных космических сигналов здесь не установлено.
```

**Предоставленный указатель**

```text
Синтетический параграф 1
```

**Точный RRef**

```text
{
  "state": "KNOWN",
  "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
}
```

## Действия редактора — порядок источников, не новый приоритет

### 1 — CONTROLLED_ACTION

```text
Получите материал вручную; URL не подтверждает получение.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[0]",
      "record_refs": [
        {
          "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
          "id": "00000004-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "8841305c4e3189d713a572c9e23dc7c84a8dbcae1cde7f9577976aa50e92931e",
      "source_action": {
        "action": {
          "ru": "Получите материал вручную; URL не подтверждает получение.",
          "uk": "Отримайте матеріал вручну; URL не підтверджує отримання."
        },
        "code": "SOURCE_NOT_RETRIEVED",
        "record_refs": [
          {
            "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
            "id": "00000004-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    },
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[2]",
      "record_refs": [
        {
          "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
          "id": "00000004-0000-4000-8000-000000000006",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "8841305c4e3189d713a572c9e23dc7c84a8dbcae1cde7f9577976aa50e92931e",
      "source_action": {
        "action": {
          "ru": "Получите материал вручную; URL не подтверждает получение.",
          "uk": "Отримайте матеріал вручну; URL не підтверджує отримання."
        },
        "code": "SOURCE_NOT_RETRIEVED",
        "record_refs": [
          {
            "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
            "id": "00000004-0000-4000-8000-000000000006",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
      "id": "00000004-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    },
    {
      "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
      "id": "00000004-0000-4000-8000-000000000006",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 2 — CONTROLLED_ACTION

```text
Отдельно рассмотрите основания пяти наблюдений и ограничения источника.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[1]",
      "record_refs": [
        {
          "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
          "id": "00000004-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "8841305c4e3189d713a572c9e23dc7c84a8dbcae1cde7f9577976aa50e92931e",
      "source_action": {
        "action": {
          "ru": "Отдельно рассмотрите основания пяти наблюдений и ограничения источника.",
          "uk": "Окремо розгляньте підстави п’яти спостережень та обмеження джерела."
        },
        "code": "SOURCE_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
            "id": "00000004-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    },
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[3]",
      "record_refs": [
        {
          "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
          "id": "00000004-0000-4000-8000-000000000006",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "8841305c4e3189d713a572c9e23dc7c84a8dbcae1cde7f9577976aa50e92931e",
      "source_action": {
        "action": {
          "ru": "Отдельно рассмотрите основания пяти наблюдений и ограничения источника.",
          "uk": "Окремо розгляньте підстави п’яти спостережень та обмеження джерела."
        },
        "code": "SOURCE_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
            "id": "00000004-0000-4000-8000-000000000006",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
      "id": "00000004-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    },
    {
      "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
      "id": "00000004-0000-4000-8000-000000000006",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 3 — CONTROLLED_ACTION

```text
Установите происхождение общего материала; не считайте его независимым подтверждением.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[4]",
      "record_refs": [
        {
          "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
          "id": "00000004-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        },
        {
          "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
          "id": "00000004-0000-4000-8000-000000000006",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "8841305c4e3189d713a572c9e23dc7c84a8dbcae1cde7f9577976aa50e92931e",
      "source_action": {
        "action": {
          "ru": "Установите происхождение общего материала; не считайте его независимым подтверждением.",
          "uk": "Встановіть походження спільного матеріалу; не вважайте його незалежним підтвердженням."
        },
        "code": "MATERIAL_REUSED",
        "record_refs": [
          {
            "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
            "id": "00000004-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          },
          {
            "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
            "id": "00000004-0000-4000-8000-000000000006",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
      "id": "00000004-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    },
    {
      "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
      "id": "00000004-0000-4000-8000-000000000006",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 4 — CONTROLLED_ACTION

```text
Запишите рассмотрение точных материалов и неопределённости утверждения.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[5]",
      "record_refs": [
        {
          "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
          "id": "00000004-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "8841305c4e3189d713a572c9e23dc7c84a8dbcae1cde7f9577976aa50e92931e",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
            "id": "00000004-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    },
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[6]",
      "record_refs": [
        {
          "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
          "id": "00000004-0000-4000-8000-000000000007",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "8841305c4e3189d713a572c9e23dc7c84a8dbcae1cde7f9577976aa50e92931e",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
            "id": "00000004-0000-4000-8000-000000000007",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    {
      "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
      "id": "00000004-0000-4000-8000-000000000007",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 5 — CONTROLLED_ACTION

```text
Уточните независимость критика; labels не удостоверяют личность.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[7]",
      "record_refs": [
        {
          "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
          "id": "00000004-0000-4000-8000-000000000003",
          "research_type": "ResearchCritiqueV1",
          "revision": 1
        },
        {
          "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
          "id": "00000004-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "8841305c4e3189d713a572c9e23dc7c84a8dbcae1cde7f9577976aa50e92931e",
      "source_action": {
        "action": {
          "ru": "Уточните независимость критика; labels не удостоверяют личность.",
          "uk": "Уточніть незалежність критика; labels не засвідчують особу."
        },
        "code": "CRITIQUE_INDEPENDENCE_UNKNOWN",
        "record_refs": [
          {
            "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
            "id": "00000004-0000-4000-8000-000000000003",
            "research_type": "ResearchCritiqueV1",
            "revision": 1
          },
          {
            "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
            "id": "00000004-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
      "id": "00000004-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 6 — CONTROLLED_ACTION

```text
Передайте существенные замечания человеку; сохраните разногласия.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[8]",
      "record_refs": [
        {
          "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
          "id": "00000004-0000-4000-8000-000000000003",
          "research_type": "ResearchCritiqueV1",
          "revision": 1
        },
        {
          "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
          "id": "00000004-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "8841305c4e3189d713a572c9e23dc7c84a8dbcae1cde7f9577976aa50e92931e",
      "source_action": {
        "action": {
          "ru": "Передайте существенные замечания человеку; сохраните разногласия.",
          "uk": "Передайте суттєві зауваження людині; збережіть розбіжності."
        },
        "code": "CRITIQUE_HIGH",
        "record_refs": [
          {
            "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
            "id": "00000004-0000-4000-8000-000000000003",
            "research_type": "ResearchCritiqueV1",
            "revision": 1
          },
          {
            "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
            "id": "00000004-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
      "id": "00000004-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 7 — CONTROLLED_ACTION

```text
Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[9]",
      "record_refs": [],
      "sha256": "8841305c4e3189d713a572c9e23dc7c84a8dbcae1cde7f9577976aa50e92931e",
      "source_action": {
        "action": {
          "ru": "Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.",
          "uk": "Перед Topic Scoring передайте точний звіт редактору та розгляньте всі збережені зауваження; автоматичного допуску немає."
        },
        "code": "EDITOR_REVIEW_REQUIRED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 8 — CONTROLLED_ACTION

```text
Рассмотрите точное соответствие исследования и supplied SI; смысловой охват не доказан.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[10]",
      "record_refs": [],
      "sha256": "8841305c4e3189d713a572c9e23dc7c84a8dbcae1cde7f9577976aa50e92931e",
      "source_action": {
        "action": {
          "ru": "Рассмотрите точное соответствие исследования и supplied SI; смысловой охват не доказан.",
          "uk": "Розгляньте точну відповідність дослідження та supplied SI; змістове охоплення не доведено."
        },
        "code": "SCOPE_UNVERIFIED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 9 — CONTROLLED_ACTION

```text
Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[11]",
      "record_refs": [],
      "sha256": "8841305c4e3189d713a572c9e23dc7c84a8dbcae1cde7f9577976aa50e92931e",
      "source_action": {
        "action": {
          "ru": "Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.",
          "uk": "Людина розглядає всі дев’ять SI ratings і findings; preliminary ratings не імпортуються автоматично."
        },
        "code": "HUMAN_SI_REVIEW",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 10 — RECORDED_GAP

```text
Найти первичный материал вручную и отметить зависимости перепечаток.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[0]",
      "record_ref": {
        "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
        "id": "00000004-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
      "id": "00000004-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 11 — RECORDED_GAP

```text
Получить отдельную человеческую критику гипотезы I.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[1]",
      "record_ref": {
        "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
        "id": "00000004-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
      "id": "00000004-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 12 — RECORDED_ACTION

```text
Найти первичный материал вручную и отметить зависимости перепечаток.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[0]",
      "record_ref": {
        "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
        "id": "00000004-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
      "id": "00000004-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 13 — RECORDED_ACTION

```text
Получить отдельную человеческую критику гипотезы I.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[1]",
      "record_ref": {
        "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
        "id": "00000004-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchCritiqueV1",
      "field_path": "$.payload.editor_action",
      "record_ref": {
        "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
        "id": "00000004-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
      "id": "00000004-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    },
    {
      "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
      "id": "00000004-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 14 — RECORDED_ACTION

```text
Получить реальные материалы вручную.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
        "id": "00000004-0000-4000-8000-000000000007",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    {
      "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
      "id": "00000004-0000-4000-8000-000000000007",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

## Только записанные творческие предложения

RECORDED

**Точный RRef**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "source_ref": {
    "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
    "id": "00000004-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  }
}
```

**Записанный основной ракурс**

```text
Какие объяснения условного наблюдения S допустимо сопоставлять без сенсационности?
```

### Альтернативные ракурсы

```text
Сузить вопрос до конкретного примера: Какие объяснения условного наблюдения S допустимо сопоставлять без сенсационности?
```

**Точный RRef**

```text
[
  {
    "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
    "id": "00000004-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Ограничения**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

### Эмоциональные хуки

```text
Наблюдение и его объяснение — разные вопросы.
```

**Точный RRef**

```text
[
  {
    "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
    "id": "00000004-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Ограничения**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

### Интеллектуальные хуки

NOT_RECORDED

**Записанный повествовательный потенциал**

UNKNOWN

```text
Не предоставлено; не восстановлено автоматически.
```

**Записанные визуальные потребности — не готовые assets/права**

```text
[
  "Помеченная учебная схема; реальные материалы/права не предоставлены."
]
```

**Ограничения**

```text
[
  "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
]
```

**Структурированные narrative alternatives — поля нет в принятом input**

```text
{
  "reason": "NO_STRUCTURED_FIELD_IN_ACCEPTED_INPUT",
  "state": "NOT_RECORDED"
}
```

## Неизменённая SI оценка supplied frame

```text
OK
```

### Существующая Projection card — только supplied SI view

**decision_summary**

```text
Сначала закройте отмеченные исследовательские пробелы.
```

**reasons**

```text
Основание — условия, зафиксированные оценкой переданных данных.
```

```text
Итоговый балл не определён.
```

```text
Рубрика 1 / Оценка «Интерес аудитории»: Не задана одна из обязательных оценок по рубрике.
```

**blocking_risks_and_gaps**

```text
Рубрика 1 / Оценка «Интерес аудитории»: Не задана одна из обязательных оценок по рубрике.
```

**next_actions**

```text
Рубрика 1 / Оценка «Интерес аудитории»: Представьте недостающую оценку или рассмотрите её неопределённость, сохраняя неизвестные значения явно.
```

**limitations**

```text
Карточка поясняет только оценку переданного контекста; полнота внешних данных не установлена.
```

```text
Баллы и уверенность не доказывают научную истинность, достоверность источников или спрос аудитории.
```

```text
Рассмотрение научных выводов человеком и всех семи областей научной проверки этой карточкой не удостоверяется.
```

```text
Права на материалы, фактическая доступность и выполнимость производства требуют отдельной проверки.
```

```text
Карточка не удостоверяет личность, компетентность или полномочия проверяющего и не предоставляет редакционного утверждения.
```

```text
Допуск к творческой разработке не является разрешением на производство или публикацию.
```

| Критерий | Вес | Исходная SI оценка | Confidence |
|---|---:|---|---|
| Интерес аудитории | 15 | UNKNOWN | HIGH |
| Соответствие каналу | 10 | 5 | HIGH |
| Новизна ракурса | 10 | 5 | HIGH |
| Качество оснований | 20 | 5 | HIGH |
| Повествовательный потенциал | 15 | 5 | HIGH |
| Визуальная осуществимость | 10 | 5 | HIGH |
| Соответствие ресурсам | 10 | 5 | HIGH |
| Управляемость рисков | 5 | 5 | HIGH |
| Отличие от портфеля | 5 | 5 | HIGH |

**Интерес аудитории**

```text
Synthetic supplied rating
```

**Соответствие каналу**

```text
Synthetic supplied rating
```

**Новизна ракурса**

```text
Synthetic supplied rating
```

**Качество оснований**

```text
Synthetic supplied rating
```

**Повествовательный потенциал**

```text
Synthetic supplied rating
```

**Визуальная осуществимость**

```text
Synthetic supplied rating
```

**Соответствие ресурсам**

```text
Synthetic supplied rating
```

**Управляемость рисков**

```text
Synthetic supplied rating
```

**Отличие от портфеля**

```text
Synthetic supplied rating
```

**Исходный aggregate_tenths — без пересчёта шкалы**

```text
{
  "reason": "At least one required rating is unknown.",
  "state": "UNKNOWN"
}
```

**Существующий результат evaluator (не решение человека)**

```text
{
  "currentness": "CURRENT",
  "diagnostics": [
    {
      "code": "EVIDENCE_NEEDED",
      "field_path": "$.ratings[0].value",
      "input_ref": {
        "id": "0000000a-2222-4222-8222-222222222222",
        "revision": 1,
        "sha256": "42ec5228b4cbf682899a9c2a1bd62b9f593b20851234b4e34d41ab4b9130a144",
        "type": "Rubric"
      },
      "message": "A required rating is unknown."
    }
  ],
  "eligibility": {
    "reason_codes": [
      "EVIDENCE_NEEDED"
    ],
    "state": "NEEDS_RESEARCH"
  },
  "status": "OK"
}
```

**Research preliminary ratings — НЕ SI ratings**

```text
[
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "audience_interest",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "channel_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "angle_novelty",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "evidence_quality",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "narrative_potential",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "visual_feasibility",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "resource_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "risk_manageability",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "portfolio_distinctness",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  }
]
```

## Ограничения

- SI результат относится только к supplied SI view, не к доказанному охвату исследования.
- Correspondence фиксирует заявление, не semantic equivalence или авторство.
- Research readiness не является SI eligibility или разрешением Topic Scoring.
- Баллы и critique labels не доказывают научную истину, фактическую проверку или независимость человека.
- Редактор принимает решение; bridge не создаёт рекомендацию, human findings или approval.
- Нет правового, коммерческого, публикационного или производственного разрешения.

## Незаполненный бланк решения человека

Бланк не подтверждает состоявшийся review. Ничего не выбрано и не датировано программой.

- [ ] Develop
- [ ] Research Further
- [ ] Reframe
- [ ] Reject
- [ ] Defer

**Обоснование:** ____________________

**Нерешённые риски:** ____________________

**Выбранный ракурс:** ____________________

**Следующие действия:** ____________________

**Личность редактора (заполнить вручную):** ____________________

**Дата review:** ____________________

HUMAN_PILOT_PENDING
