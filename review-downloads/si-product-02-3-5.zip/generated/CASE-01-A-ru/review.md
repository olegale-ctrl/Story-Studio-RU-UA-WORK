# Редакторское рассмотрение — V1

Приватные записанные данные, не инструкции к выполнению. Структура/labels не доказывают истину, личность, права или допуск. Окончательное решение принимает человек.

## Тема и отдельные состояния

**Название темы**

```text
Почему исчезли древние цивилизации?
```

**Исследовательский вопрос**

```text
Какой конкретный период и регион нужно исследовать, прежде чем сравнивать H1 и H2?
```

**Аудитория**

```text
Редактор учебного научно-популярного проекта
```

**Исследовательская готовность**

```text
NEEDS_INPUT
```

**SI eligibility — только supplied SI view**

```text
SI_NOT_RUN
```

**Производственное состояние — не допуск**

```text
NOT_ASSESSED
```

**Связь Research ↔ SI не доказана; recorded scope — заявление**

```text
{
  "correspondence_state": "NO_FRAME",
  "declared_correspondence": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "dossier_sha256": "30241bbe5e78d40ddaf2cf7bcab2acdd54561d7a17538f88fd9a1daee3d6cf15",
  "evidence_correspondence": "EXACT_REPLAY_MATCH",
  "evidence_report_sha256": "c3d826d6a0acf3e880d8353509ed1883feb84c273b59fc67146f56bc96776c3a",
  "frame_origin": "NONE",
  "frame_sha256": null,
  "research_snapshot_sha256": "44da14fc10c4f8bf5e6da70f12aaca6cd0a2c9d334ab4c4e54694e7d272fcab8",
  "semantic_coverage_verified": false
}
```

**Критические замечания — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
      "id": "00000001-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_HUMAN",
    "delivery": "DELIVERED",
    "editor_action": "Запросить независимые основания для H2 и сохранить H1/H2 раздельно.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Два разных условных человека A и B в тестовой fixture."
    },
    "provenance": {
      "kind": "EDITOR_DECLARED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Critic B"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
      "id": "00000001-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какой конкретный период и регион нужно исследовать, прежде чем сравнивать H1 и H2?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Выбрать конкретный период и регион."
      }
    }
  }
]
```

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
        "id": "00000001-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
        "id": "00000001-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "EVIDENCE_MISSING",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
        "id": "00000001-0000-4000-8000-000000000006",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
        "id": "00000001-0000-4000-8000-000000000006",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
        "id": "00000001-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
        "id": "00000001-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Записанное предложение и риски из input — не новое решение**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "recorded": {
    "editorial_risks": [],
    "gaps": [
      "Выбрать конкретный период и регион.",
      "Запросить независимые основания для H2 и сохранить H1/H2 раздельно."
    ],
    "production_limits": {
      "state": "KNOWN",
      "value": [
        "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
      ]
    },
    "prospect": "RESEARCH_MORE",
    "reasons": [
      {
        "basis_claim_refs": [
          {
            "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
            "id": "00000001-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ],
        "kind": "RESEARCH_GAP",
        "text": "Требуется отдельное человеческое рассмотрение; данные только синтетические."
      }
    ],
    "scientific_risks": []
  },
  "source_ref": {
    "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
    "id": "00000001-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  },
  "state": "RECORDED"
}
```

Не хватает записанных данных; это не вердикт об истинности.

## Утверждения и доказательные связи

### Утверждение 1

**Исходный текст утверждения**

```text
Синтетический кейс 1: СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: в учебной таблице перечислены конкурирующие H1 и H2; данных для универсальной причины нет.
```

**Точный RRef**

```text
{
  "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
  "id": "00000001-0000-4000-8000-000000000002",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип и центральность (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "factual"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "details": {
    "state": "KNOWN",
    "value": {
      "reason": "Учебная фиксация рассмотрения, не аутентификация.",
      "reviewed_at": {
        "reason": "Не предоставлено; не восстановлено автоматически.",
        "state": "UNKNOWN"
      },
      "reviewed_source_refs": [
        {
          "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
          "id": "00000001-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "reviewer_label": "Researcher A"
    }
  },
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "EDITOR_REVIEW_RECORDED"
}
```

**Неопределённость**

```text
{
  "level": "HIGH",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Поддерживающие связи — не proof истины

[Источник 1](#source-1)

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точный RRef**

```text
{
  "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
  "id": "00000001-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записанное основание связи**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Противоречащие связи

NOT_RECORDED

#### Контекстные/недостаточные связи

NOT_RECORDED

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
        "id": "00000001-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
        "id": "00000001-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
        "id": "00000001-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
        "id": "00000001-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Критические замечания — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
      "id": "00000001-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_HUMAN",
    "delivery": "DELIVERED",
    "editor_action": "Запросить независимые основания для H2 и сохранить H1/H2 раздельно.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Два разных условных человека A и B в тестовой fixture."
    },
    "provenance": {
      "kind": "EDITOR_DECLARED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Critic B"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
      "id": "00000001-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какой конкретный период и регион нужно исследовать, прежде чем сравнивать H1 и H2?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Выбрать конкретный период и регион."
      }
    }
  }
]
```

### Утверждение 2

**Исходный текст утверждения**

```text
СИНТЕТИЧЕСКАЯ конкурирующая H2: основания пока не предоставлены.
```

**Точный RRef**

```text
{
  "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
  "id": "00000001-0000-4000-8000-000000000006",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип и центральность (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "factual"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "details": {
    "reason": "Fixture: explicitly not supplied",
    "state": "UNKNOWN"
  },
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "NOT_REVIEWED"
}
```

**Неопределённость**

```text
{
  "level": "HIGH",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Поддерживающие связи — не proof истины

NOT_RECORDED

#### Противоречащие связи

NOT_RECORDED

#### Контекстные/недостаточные связи

NOT_RECORDED

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "EVIDENCE_MISSING",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
        "id": "00000001-0000-4000-8000-000000000006",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
        "id": "00000001-0000-4000-8000-000000000006",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  }
]
```

**Критические замечания — unresolved/declared**

```text
[]
```

## Источники, фрагменты и ограничения

### Source 1

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точный RRef**

```text
{
  "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
  "id": "00000001-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Локатор как данные (не активная ссылка)**

```text
{
  "kind": "LOCAL_ID",
  "value": "synthetic-local-1"
}
```

**Автор / организация / даты — как предоставлены**

```text
{
  "author": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "organization": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "published_at": {
    "state": "KNOWN",
    "value": {
      "precision": "YEAR",
      "value": "2020"
    }
  },
  "retrieved_at": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "kind": "EDITOR_DECLARED",
  "method_label": {
    "state": "KNOWN",
    "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
  },
  "producer_label": {
    "state": "KNOWN",
    "value": "Researcher A"
  },
  "upstream_refs": []
}
```

**Пять независимых записанных observations**

```text
{
  "content": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "6c2010217b1550f7de0db92643a7ee26f9749054f844bc4fb0fc8a43ebba6e50"
    },
    "state": "CONTEXT_REVIEW_REPORTED"
  },
  "editor_confirmation": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "6c2010217b1550f7de0db92643a7ee26f9749054f844bc4fb0fc8a43ebba6e50"
    },
    "state": "CONFIRMED_AS_RECORDED"
  },
  "integrity": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "6c2010217b1550f7de0db92643a7ee26f9749054f844bc4fb0fc8a43ebba6e50"
    },
    "state": "HASH_REPORTED"
  },
  "link_existence": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "6c2010217b1550f7de0db92643a7ee26f9749054f844bc4fb0fc8a43ebba6e50"
    },
    "state": "RESOLVED"
  },
  "retrieval": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "6c2010217b1550f7de0db92643a7ee26f9749054f844bc4fb0fc8a43ebba6e50"
    },
    "state": "RETRIEVED"
  }
}
```

**Ограничения**

```text
[
  "Искусственные данные для теста; не свидетельство о реальном мире."
]
```

**Фрагмент**

```text
F1
```

**Точный предоставленный текст — не verified quote**

```text
СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: в учебной таблице перечислены конкурирующие H1 и H2; данных для универсальной причины нет.
```

**Предоставленный указатель**

```text
Синтетический параграф 1
```

**Точный RRef**

```text
{
  "state": "KNOWN",
  "value": "6c2010217b1550f7de0db92643a7ee26f9749054f844bc4fb0fc8a43ebba6e50"
}
```

## Действия редактора — порядок источников, не новый приоритет

### 1 — CONTROLLED_ACTION

```text
Отдельно рассмотрите основания пяти наблюдений и ограничения источника.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[0]",
      "record_refs": [
        {
          "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
          "id": "00000001-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Отдельно рассмотрите основания пяти наблюдений и ограничения источника.",
          "uk": "Окремо розгляньте підстави п’яти спостережень та обмеження джерела."
        },
        "code": "SOURCE_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
            "id": "00000001-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
      "id": "00000001-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 2 — CONTROLLED_ACTION

```text
Запишите рассмотрение точных материалов и неопределённости утверждения.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[1]",
      "record_refs": [
        {
          "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
          "id": "00000001-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
            "id": "00000001-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    },
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[3]",
      "record_refs": [
        {
          "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
          "id": "00000001-0000-4000-8000-000000000006",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
            "id": "00000001-0000-4000-8000-000000000006",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
      "id": "00000001-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    {
      "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
      "id": "00000001-0000-4000-8000-000000000006",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 3 — CONTROLLED_ACTION

```text
Добавьте точные основания утверждения; не заменяйте их рейтингом.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[2]",
      "record_refs": [
        {
          "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
          "id": "00000001-0000-4000-8000-000000000006",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Добавьте точные основания утверждения; не заменяйте их рейтингом.",
          "uk": "Додайте точні підстави твердження; не замінюйте їх рейтингом."
        },
        "code": "EVIDENCE_MISSING",
        "record_refs": [
          {
            "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
            "id": "00000001-0000-4000-8000-000000000006",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
      "id": "00000001-0000-4000-8000-000000000006",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 4 — CONTROLLED_ACTION

```text
Передайте существенные замечания человеку; сохраните разногласия.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[4]",
      "record_refs": [
        {
          "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
          "id": "00000001-0000-4000-8000-000000000003",
          "research_type": "ResearchCritiqueV1",
          "revision": 1
        },
        {
          "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
          "id": "00000001-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Передайте существенные замечания человеку; сохраните разногласия.",
          "uk": "Передайте суттєві зауваження людині; збережіть розбіжності."
        },
        "code": "CRITIQUE_HIGH",
        "record_refs": [
          {
            "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
            "id": "00000001-0000-4000-8000-000000000003",
            "research_type": "ResearchCritiqueV1",
            "revision": 1
          },
          {
            "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
            "id": "00000001-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
      "id": "00000001-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
      "id": "00000001-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 5 — CONTROLLED_ACTION

```text
Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[5]",
      "record_refs": [],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.",
          "uk": "Перед Topic Scoring передайте точний звіт редактору та розгляньте всі збережені зауваження; автоматичного допуску немає."
        },
        "code": "EDITOR_REVIEW_REQUIRED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 6 — CONTROLLED_ACTION

```text
При необходимости предоставьте готовый SI frame; исследование ещё не оценено SI.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[6]",
      "record_refs": [],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "При необходимости предоставьте готовый SI frame; исследование ещё не оценено SI.",
          "uk": "За потреби надайте готовий SI frame; дослідження ще не оцінено SI."
        },
        "code": "NO_SI_FRAME",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 7 — CONTROLLED_ACTION

```text
Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[7]",
      "record_refs": [],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.",
          "uk": "Людина розглядає всі дев’ять SI ratings і findings; preliminary ratings не імпортуються автоматично."
        },
        "code": "HUMAN_SI_REVIEW",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 8 — RECORDED_GAP

```text
Выбрать конкретный период и регион.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[0]",
      "record_ref": {
        "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
        "id": "00000001-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
      "id": "00000001-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 9 — RECORDED_GAP

```text
Запросить независимые основания для H2 и сохранить H1/H2 раздельно.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[1]",
      "record_ref": {
        "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
        "id": "00000001-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
      "id": "00000001-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 10 — RECORDED_ACTION

```text
Выбрать конкретный период и регион.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[0]",
      "record_ref": {
        "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
        "id": "00000001-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
      "id": "00000001-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 11 — RECORDED_ACTION

```text
Запросить независимые основания для H2 и сохранить H1/H2 раздельно.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[1]",
      "record_ref": {
        "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
        "id": "00000001-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchCritiqueV1",
      "field_path": "$.payload.editor_action",
      "record_ref": {
        "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
        "id": "00000001-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
      "id": "00000001-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    },
    {
      "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
      "id": "00000001-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
      "id": "00000001-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 12 — RECORDED_ACTION

```text
Получить реальные материалы вручную.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
        "id": "00000001-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
        "id": "00000001-0000-4000-8000-000000000006",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
      "id": "00000001-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    {
      "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
      "id": "00000001-0000-4000-8000-000000000006",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

## Только записанные творческие предложения

RECORDED

**Точный RRef**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "source_ref": {
    "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
    "id": "00000001-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  }
}
```

**Записанный основной ракурс**

```text
Какой конкретный период и регион нужно исследовать, прежде чем сравнивать H1 и H2?
```

### Альтернативные ракурсы

```text
Сузить вопрос до конкретного примера: Какой конкретный период и регион нужно исследовать, прежде чем сравнивать H1 и H2?
```

**Точный RRef**

```text
[
  {
    "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
    "id": "00000001-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Ограничения**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

```text
Сопоставить H1 и H2 без единой причины для всех цивилизаций.
```

**Точный RRef**

```text
[
  {
    "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
    "id": "00000001-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Ограничения**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

### Эмоциональные хуки

```text
Наблюдение и его объяснение — разные вопросы.
```

**Точный RRef**

```text
[
  {
    "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
    "id": "00000001-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Ограничения**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

### Интеллектуальные хуки

```text
Сравнить альтернативы без универсального вывода.
```

**Точный RRef**

```text
[
  {
    "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
    "id": "00000001-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Ограничения**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

**Записанный повествовательный потенциал**

UNKNOWN

```text
Не предоставлено; не восстановлено автоматически.
```

**Записанные визуальные потребности — не готовые assets/права**

```text
NOT_RECORDED
```

**Ограничения**

```text
[
  "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
]
```

**Структурированные narrative alternatives — поля нет в принятом input**

```text
{
  "reason": "NO_STRUCTURED_FIELD_IN_ACCEPTED_INPUT",
  "state": "NOT_RECORDED"
}
```

## Неизменённая SI оценка supplied frame

```text
SI_NOT_RUN
```

### Существующая Projection card — только supplied SI view

NOT_RECORDED

| Критерий | Вес | Исходная SI оценка | Confidence |
|---|---:|---|---|
| Интерес аудитории | 15 | SI_NOT_RUN | — |
| Соответствие каналу | 10 | SI_NOT_RUN | — |
| Новизна ракурса | 10 | SI_NOT_RUN | — |
| Качество оснований | 20 | SI_NOT_RUN | — |
| Повествовательный потенциал | 15 | SI_NOT_RUN | — |
| Визуальная осуществимость | 10 | SI_NOT_RUN | — |
| Соответствие ресурсам | 10 | SI_NOT_RUN | — |
| Управляемость рисков | 5 | SI_NOT_RUN | — |
| Отличие от портфеля | 5 | SI_NOT_RUN | — |

**Исходный aggregate_tenths — без пересчёта шкалы**

```text
null
```

**Существующий результат evaluator (не решение человека)**

```text
null
```

**Research preliminary ratings — НЕ SI ratings**

```text
[
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "audience_interest",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "channel_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "angle_novelty",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "evidence_quality",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "narrative_potential",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "visual_feasibility",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "resource_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "risk_manageability",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "portfolio_distinctness",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  }
]
```

## Ограничения

- SI результат относится только к supplied SI view, не к доказанному охвату исследования.
- Correspondence фиксирует заявление, не semantic equivalence или авторство.
- Research readiness не является SI eligibility или разрешением Topic Scoring.
- Баллы и critique labels не доказывают научную истину, фактическую проверку или независимость человека.
- Редактор принимает решение; bridge не создаёт рекомендацию, human findings или approval.
- Нет правового, коммерческого, публикационного или производственного разрешения.

## Незаполненный бланк решения человека

Бланк не подтверждает состоявшийся review. Ничего не выбрано и не датировано программой.

- [ ] Develop
- [ ] Research Further
- [ ] Reframe
- [ ] Reject
- [ ] Defer

**Обоснование:** ____________________

**Нерешённые риски:** ____________________

**Выбранный ракурс:** ____________________

**Следующие действия:** ____________________

**Личность редактора (заполнить вручную):** ____________________

**Дата review:** ____________________

HUMAN_PILOT_PENDING
