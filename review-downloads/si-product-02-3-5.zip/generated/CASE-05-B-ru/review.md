# Редакторское рассмотрение — V1

Приватные записанные данные, не инструкции к выполнению. Структура/labels не доказывают истину, личность, права или допуск. Окончательное решение принимает человек.

## Тема и отдельные состояния

**Название темы**

```text
Почему некоторые популярные исторические факты оказались мифами?
```

**Исследовательский вопрос**

```text
Какой один исторический пример и его исходное свидетельство предстоит выбрать?
```

**Аудитория**

```text
Редактор учебного научно-популярного проекта
```

**Исследовательская готовность**

```text
NEEDS_REVIEW
```

**SI eligibility — только supplied SI view**

```text
{
  "reason_codes": [
    "CENTRAL_CLAIM_UNSUPPORTED"
  ],
  "state": "BLOCKED"
}
```

**Производственное состояние — не допуск**

```text
NOT_ASSESSED
```

**Связь Research ↔ SI не доказана; recorded scope — заявление**

```text
{
  "correspondence_state": "UNVERIFIED_SCOPE",
  "declared_correspondence": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "dossier_sha256": "bd481c1db712cebd23a247ff039b96acc907513806c18399bf3b537ad8826d43",
  "evidence_correspondence": "EXACT_REPLAY_MATCH",
  "evidence_report_sha256": "22449924addc515e3cc28c47c18e872ab6e19dc4e4a03ff3a841c204f37a4f28",
  "frame_origin": "EXPLICIT",
  "frame_sha256": "75eb2aa631a43ea536922605a4ec03bc74aa4f67f717fb250ae7fb0f3c1aa9e2",
  "research_snapshot_sha256": "d3a2245dc5a22e705aa7b3ff91703b194b55649bb1efd020c2128d0776927f4d",
  "semantic_coverage_verified": false
}
```

**Критические замечания — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
      "id": "00000005-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_HUMAN",
    "delivery": "DELIVERED",
    "editor_action": "Проследить исходное свидетельство и сохранить противоречия.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Два разных условных человека A и B в тестовой fixture."
    },
    "provenance": {
      "kind": "EDITOR_DECLARED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Researcher A"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какой один исторический пример и его исходное свидетельство предстоит выбрать?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Выбрать один реальный исторический пример до сбора доказательств."
      }
    }
  }
]
```

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
        "id": "00000005-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
        "id": "00000005-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CONTRADICTION_UNRESOLVED",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
        "id": "00000005-0000-4000-8000-000000000007",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_INDEPENDENCE_UNKNOWN",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
        "id": "00000005-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
        "id": "00000005-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Записанное предложение и риски из input — не новое решение**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "recorded": {
    "editorial_risks": [],
    "gaps": [
      "Выбрать один реальный исторический пример до сбора доказательств.",
      "Проследить исходное свидетельство и сохранить противоречия."
    ],
    "production_limits": {
      "state": "KNOWN",
      "value": [
        "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
      ]
    },
    "prospect": "RESEARCH_MORE",
    "reasons": [
      {
        "basis_claim_refs": [
          {
            "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
            "id": "00000005-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ],
        "kind": "RESEARCH_GAP",
        "text": "Требуется отдельное человеческое рассмотрение; данные только синтетические."
      }
    ],
    "scientific_risks": []
  },
  "source_ref": {
    "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
    "id": "00000005-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  },
  "state": "RECORDED"
}
```

Предоставленные данные требуют рассмотрения человеком.

## Утверждения и доказательные связи

### Утверждение 1

**Исходный текст утверждения**

```text
Синтетический кейс 5: СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: условная запись M1 и её поздняя интерпретация расходятся; это не свидетельство о реальной истории.
```

**Точный RRef**

```text
{
  "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
  "id": "00000005-0000-4000-8000-000000000002",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип и центральность (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "factual"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "details": {
    "state": "KNOWN",
    "value": {
      "reason": "Учебная фиксация рассмотрения, не аутентификация.",
      "reviewed_at": {
        "reason": "Не предоставлено; не восстановлено автоматически.",
        "state": "UNKNOWN"
      },
      "reviewed_source_refs": [
        {
          "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
          "id": "00000005-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        },
        {
          "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
          "id": "00000005-0000-4000-8000-000000000006",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "reviewer_label": "Researcher A"
    }
  },
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "DISAGREEMENT_RECORDED"
}
```

**Неопределённость**

```text
{
  "level": "HIGH",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Поддерживающие связи — не proof истины

[Источник 1](#source-1)

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точный RRef**

```text
{
  "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
  "id": "00000005-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записанное основание связи**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Противоречащие связи

[Источник 2](#source-2)

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 91
```

**Точный RRef**

```text
{
  "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
  "id": "00000005-0000-4000-8000-000000000006",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записанное основание связи**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Контекстные/недостаточные связи

NOT_RECORDED

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
        "id": "00000005-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
        "id": "00000005-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CONTRADICTION_UNRESOLVED",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_INDEPENDENCE_UNKNOWN",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
        "id": "00000005-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
        "id": "00000005-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Критические замечания — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
      "id": "00000005-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_HUMAN",
    "delivery": "DELIVERED",
    "editor_action": "Проследить исходное свидетельство и сохранить противоречия.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Два разных условных человека A и B в тестовой fixture."
    },
    "provenance": {
      "kind": "EDITOR_DECLARED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Researcher A"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какой один исторический пример и его исходное свидетельство предстоит выбрать?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Выбрать один реальный исторический пример до сбора доказательств."
      }
    }
  }
]
```

### Утверждение 2

**Исходный текст утверждения**

```text
СИНТЕТИЧЕСКАЯ редакционная интерпретация: Какой один исторический пример и его исходное свидетельство предстоит выбрать?
```

**Точный RRef**

```text
{
  "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
  "id": "00000005-0000-4000-8000-000000000007",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип и центральность (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "interpretation"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "details": {
    "reason": "Fixture: explicitly not supplied",
    "state": "UNKNOWN"
  },
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "NOT_REVIEWED"
}
```

**Неопределённость**

```text
{
  "level": "HIGH",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Поддерживающие связи — не proof истины

[Источник 2](#source-2)

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 91
```

**Точный RRef**

```text
{
  "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
  "id": "00000005-0000-4000-8000-000000000006",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записанное основание связи**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Противоречащие связи

NOT_RECORDED

#### Контекстные/недостаточные связи

NOT_RECORDED

**Пробелы и недостающие подтверждения**

```text
[
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
        "id": "00000005-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
        "id": "00000005-0000-4000-8000-000000000007",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  }
]
```

**Критические замечания — unresolved/declared**

```text
[]
```

## Источники, фрагменты и ограничения

### Source 1

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точный RRef**

```text
{
  "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
  "id": "00000005-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Локатор как данные (не активная ссылка)**

```text
{
  "kind": "LOCAL_ID",
  "value": "synthetic-local-1"
}
```

**Автор / организация / даты — как предоставлены**

```text
{
  "author": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "organization": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "published_at": {
    "state": "KNOWN",
    "value": {
      "precision": "YEAR",
      "value": "2020"
    }
  },
  "retrieved_at": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "kind": "EDITOR_DECLARED",
  "method_label": {
    "state": "KNOWN",
    "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
  },
  "producer_label": {
    "state": "KNOWN",
    "value": "Researcher A"
  },
  "upstream_refs": []
}
```

**Пять независимых записанных observations**

```text
{
  "content": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "fe61b83ee0b7a6ddcae94b67331435f2ef663280a0b85873d367a1ffe45ddf11"
    },
    "state": "CONTEXT_REVIEW_REPORTED"
  },
  "editor_confirmation": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "fe61b83ee0b7a6ddcae94b67331435f2ef663280a0b85873d367a1ffe45ddf11"
    },
    "state": "CONFIRMED_AS_RECORDED"
  },
  "integrity": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "fe61b83ee0b7a6ddcae94b67331435f2ef663280a0b85873d367a1ffe45ddf11"
    },
    "state": "HASH_REPORTED"
  },
  "link_existence": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "fe61b83ee0b7a6ddcae94b67331435f2ef663280a0b85873d367a1ffe45ddf11"
    },
    "state": "RESOLVED"
  },
  "retrieval": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "fe61b83ee0b7a6ddcae94b67331435f2ef663280a0b85873d367a1ffe45ddf11"
    },
    "state": "RETRIEVED"
  }
}
```

**Ограничения**

```text
[
  "Искусственные данные для теста; не свидетельство о реальном мире."
]
```

**Фрагмент**

```text
F1
```

**Точный предоставленный текст — не verified quote**

```text
СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: условная запись M1 и её поздняя интерпретация расходятся; это не свидетельство о реальной истории.
```

**Предоставленный указатель**

```text
Синтетический параграф 1
```

**Точный RRef**

```text
{
  "state": "KNOWN",
  "value": "fe61b83ee0b7a6ddcae94b67331435f2ef663280a0b85873d367a1ffe45ddf11"
}
```

### Source 2

**Источник**

```text
СИНТЕТИЧЕСКИЙ локальный материал 91
```

**Точный RRef**

```text
{
  "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
  "id": "00000005-0000-4000-8000-000000000006",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Локатор как данные (не активная ссылка)**

```text
{
  "kind": "LOCAL_ID",
  "value": "synthetic-local-91"
}
```

**Автор / организация / даты — как предоставлены**

```text
{
  "author": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "organization": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "published_at": {
    "state": "KNOWN",
    "value": {
      "precision": "YEAR",
      "value": "2020"
    }
  },
  "retrieved_at": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  }
}
```

**Записанная проверка — не удостоверенный факт review**

```text
{
  "kind": "EDITOR_DECLARED",
  "method_label": {
    "state": "KNOWN",
    "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
  },
  "producer_label": {
    "state": "KNOWN",
    "value": "Researcher A"
  },
  "upstream_refs": [
    {
      "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
      "id": "00000005-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

**Пять независимых записанных observations**

```text
{
  "content": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "0755b395b33660367b75184eb83963d2099407b22ebbb5146eefbbc12a0eb82b"
    },
    "state": "CONTEXT_REVIEW_REPORTED"
  },
  "editor_confirmation": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "0755b395b33660367b75184eb83963d2099407b22ebbb5146eefbbc12a0eb82b"
    },
    "state": "CONFIRMED_AS_RECORDED"
  },
  "integrity": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "0755b395b33660367b75184eb83963d2099407b22ebbb5146eefbbc12a0eb82b"
    },
    "state": "HASH_REPORTED"
  },
  "link_existence": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "0755b395b33660367b75184eb83963d2099407b22ebbb5146eefbbc12a0eb82b"
    },
    "state": "RESOLVED"
  },
  "retrieval": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "0755b395b33660367b75184eb83963d2099407b22ebbb5146eefbbc12a0eb82b"
    },
    "state": "RETRIEVED"
  }
}
```

**Ограничения**

```text
[
  "Искусственные данные для теста; не свидетельство о реальном мире."
]
```

**Фрагмент**

```text
F1
```

**Точный предоставленный текст — не verified quote**

```text
СИНТЕТИЧЕСКАЯ производная запись M2 иначе интерпретирует M1; независимость не установлена.
```

**Предоставленный указатель**

```text
Синтетический параграф 1
```

**Точный RRef**

```text
{
  "state": "KNOWN",
  "value": "0755b395b33660367b75184eb83963d2099407b22ebbb5146eefbbc12a0eb82b"
}
```

## Действия редактора — порядок источников, не новый приоритет

### 1 — CONTROLLED_ACTION

```text
Отдельно рассмотрите основания пяти наблюдений и ограничения источника.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[0]",
      "record_refs": [
        {
          "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
          "id": "00000005-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Отдельно рассмотрите основания пяти наблюдений и ограничения источника.",
          "uk": "Окремо розгляньте підстави п’яти спостережень та обмеження джерела."
        },
        "code": "SOURCE_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
            "id": "00000005-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    },
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[1]",
      "record_refs": [
        {
          "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
          "id": "00000005-0000-4000-8000-000000000006",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Отдельно рассмотрите основания пяти наблюдений и ограничения источника.",
          "uk": "Окремо розгляньте підстави п’яти спостережень та обмеження джерела."
        },
        "code": "SOURCE_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
            "id": "00000005-0000-4000-8000-000000000006",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
      "id": "00000005-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    },
    {
      "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
      "id": "00000005-0000-4000-8000-000000000006",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 2 — CONTROLLED_ACTION

```text
Рассмотрите все контрдоказательства; не устраняйте их голосованием.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[2]",
      "record_refs": [
        {
          "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
          "id": "00000005-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Рассмотрите все контрдоказательства; не устраняйте их голосованием.",
          "uk": "Розгляньте всі контрдокази; не усувайте їх голосуванням."
        },
        "code": "CONTRADICTION_UNRESOLVED",
        "record_refs": [
          {
            "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
            "id": "00000005-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 3 — CONTROLLED_ACTION

```text
Запишите рассмотрение точных материалов и неопределённости утверждения.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[3]",
      "record_refs": [
        {
          "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
          "id": "00000005-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
            "id": "00000005-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    },
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[4]",
      "record_refs": [
        {
          "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
          "id": "00000005-0000-4000-8000-000000000007",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
            "id": "00000005-0000-4000-8000-000000000007",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    {
      "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
      "id": "00000005-0000-4000-8000-000000000007",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 4 — CONTROLLED_ACTION

```text
Уточните независимость критика; labels не удостоверяют личность.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[5]",
      "record_refs": [
        {
          "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
          "id": "00000005-0000-4000-8000-000000000003",
          "research_type": "ResearchCritiqueV1",
          "revision": 1
        },
        {
          "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
          "id": "00000005-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Уточните независимость критика; labels не удостоверяют личность.",
          "uk": "Уточніть незалежність критика; labels не засвідчують особу."
        },
        "code": "CRITIQUE_INDEPENDENCE_UNKNOWN",
        "record_refs": [
          {
            "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
            "id": "00000005-0000-4000-8000-000000000003",
            "research_type": "ResearchCritiqueV1",
            "revision": 1
          },
          {
            "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
            "id": "00000005-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
      "id": "00000005-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 5 — CONTROLLED_ACTION

```text
Передайте существенные замечания человеку; сохраните разногласия.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[6]",
      "record_refs": [
        {
          "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
          "id": "00000005-0000-4000-8000-000000000003",
          "research_type": "ResearchCritiqueV1",
          "revision": 1
        },
        {
          "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
          "id": "00000005-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Передайте существенные замечания человеку; сохраните разногласия.",
          "uk": "Передайте суттєві зауваження людині; збережіть розбіжності."
        },
        "code": "CRITIQUE_HIGH",
        "record_refs": [
          {
            "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
            "id": "00000005-0000-4000-8000-000000000003",
            "research_type": "ResearchCritiqueV1",
            "revision": 1
          },
          {
            "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
            "id": "00000005-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
      "id": "00000005-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 6 — CONTROLLED_ACTION

```text
Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[7]",
      "record_refs": [],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.",
          "uk": "Перед Topic Scoring передайте точний звіт редактору та розгляньте всі збережені зауваження; автоматичного допуску немає."
        },
        "code": "EDITOR_REVIEW_REQUIRED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 7 — CONTROLLED_ACTION

```text
Рассмотрите точное соответствие исследования и supplied SI; смысловой охват не доказан.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[8]",
      "record_refs": [],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Рассмотрите точное соответствие исследования и supplied SI; смысловой охват не доказан.",
          "uk": "Розгляньте точну відповідність дослідження та supplied SI; змістове охоплення не доведено."
        },
        "code": "SCOPE_UNVERIFIED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 8 — CONTROLLED_ACTION

```text
Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[9]",
      "record_refs": [],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.",
          "uk": "Людина розглядає всі дев’ять SI ratings і findings; preliminary ratings не імпортуються автоматично."
        },
        "code": "HUMAN_SI_REVIEW",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 9 — RECORDED_GAP

```text
Выбрать один реальный исторический пример до сбора доказательств.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[0]",
      "record_ref": {
        "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
        "id": "00000005-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
      "id": "00000005-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 10 — RECORDED_GAP

```text
Проследить исходное свидетельство и сохранить противоречия.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[1]",
      "record_ref": {
        "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
        "id": "00000005-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
      "id": "00000005-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 11 — RECORDED_ACTION

```text
Выбрать один реальный исторический пример до сбора доказательств.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[0]",
      "record_ref": {
        "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
        "id": "00000005-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
      "id": "00000005-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 12 — RECORDED_ACTION

```text
Проследить исходное свидетельство и сохранить противоречия.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[1]",
      "record_ref": {
        "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
        "id": "00000005-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchCritiqueV1",
      "field_path": "$.payload.editor_action",
      "record_ref": {
        "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
        "id": "00000005-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
      "id": "00000005-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    },
    {
      "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
      "id": "00000005-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 13 — RECORDED_ACTION

```text
Получить реальные материалы вручную.
```

**Происхождение действия и все ссылки**

```text
{
  "origins": [
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
        "id": "00000005-0000-4000-8000-000000000007",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    {
      "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
      "id": "00000005-0000-4000-8000-000000000007",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

## Только записанные творческие предложения

RECORDED

**Точный RRef**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "source_ref": {
    "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
    "id": "00000005-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  }
}
```

**Записанный основной ракурс**

```text
Какой один исторический пример и его исходное свидетельство предстоит выбрать?
```

### Альтернативные ракурсы

```text
Сузить вопрос до конкретного примера: Какой один исторический пример и его исходное свидетельство предстоит выбрать?
```

**Точный RRef**

```text
[
  {
    "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
    "id": "00000005-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Ограничения**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

### Эмоциональные хуки

NOT_RECORDED

### Интеллектуальные хуки

```text
Сравнить альтернативы без универсального вывода.
```

**Точный RRef**

```text
[
  {
    "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
    "id": "00000005-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Ограничения**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

**Записанный повествовательный потенциал**

UNKNOWN

```text
Не предоставлено; не восстановлено автоматически.
```

**Записанные визуальные потребности — не готовые assets/права**

```text
NOT_RECORDED
```

**Ограничения**

```text
[
  "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
]
```

**Структурированные narrative alternatives — поля нет в принятом input**

```text
{
  "reason": "NO_STRUCTURED_FIELD_IN_ACCEPTED_INPUT",
  "state": "NOT_RECORDED"
}
```

## Неизменённая SI оценка supplied frame

```text
OK
```

### Существующая Projection card — только supplied SI view

**decision_summary**

```text
Продолжение творческой разработки заблокировано отмеченными условиями.
```

**reasons**

```text
Основание — условия, зафиксированные оценкой переданных данных.
```

```text
Баллы по заданной рубрике: 1000 из 1000.
```

```text
Проверка утверждения 1: Проверка центрального фактического утверждения остаётся нерешённой или недостаточной.
```

```text
Свидетельство 1: В зафиксированных данных остаётся противоречие.
```

**blocking_risks_and_gaps**

```text
Проверка утверждения 1: Проверка центрального фактического утверждения остаётся нерешённой или недостаточной.
```

```text
Свидетельство 1: В зафиксированных данных остаётся противоречие.
```

**next_actions**

```text
Проверка утверждения 1: Исследуйте утверждение и противоречащие данные; передайте существенные разногласия на рассмотрение человеку.
```

```text
Свидетельство 1: Исследуйте утверждение и противоречащие данные; передайте существенные разногласия на рассмотрение человеку.
```

**limitations**

```text
Карточка поясняет только оценку переданного контекста; полнота внешних данных не установлена.
```

```text
Баллы и уверенность не доказывают научную истинность, достоверность источников или спрос аудитории.
```

```text
Рассмотрение научных выводов человеком и всех семи областей научной проверки этой карточкой не удостоверяется.
```

```text
Права на материалы, фактическая доступность и выполнимость производства требуют отдельной проверки.
```

```text
Карточка не удостоверяет личность, компетентность или полномочия проверяющего и не предоставляет редакционного утверждения.
```

```text
Допуск к творческой разработке не является разрешением на производство или публикацию.
```

| Критерий | Вес | Исходная SI оценка | Confidence |
|---|---:|---|---|
| Интерес аудитории | 15 | 5 | HIGH |
| Соответствие каналу | 10 | 5 | HIGH |
| Новизна ракурса | 10 | 5 | HIGH |
| Качество оснований | 20 | 5 | HIGH |
| Повествовательный потенциал | 15 | 5 | HIGH |
| Визуальная осуществимость | 10 | 5 | HIGH |
| Соответствие ресурсам | 10 | 5 | HIGH |
| Управляемость рисков | 5 | 5 | HIGH |
| Отличие от портфеля | 5 | 5 | HIGH |

**Интерес аудитории**

```text
Synthetic supplied rating
```

**Соответствие каналу**

```text
Synthetic supplied rating
```

**Новизна ракурса**

```text
Synthetic supplied rating
```

**Качество оснований**

```text
Synthetic supplied rating
```

**Повествовательный потенциал**

```text
Synthetic supplied rating
```

**Визуальная осуществимость**

```text
Synthetic supplied rating
```

**Соответствие ресурсам**

```text
Synthetic supplied rating
```

**Управляемость рисков**

```text
Synthetic supplied rating
```

**Отличие от портфеля**

```text
Synthetic supplied rating
```

**Исходный aggregate_tenths — без пересчёта шкалы**

```text
{
  "state": "KNOWN",
  "value": 1000
}
```

**Существующий результат evaluator (не решение человека)**

```text
{
  "currentness": "CURRENT",
  "diagnostics": [
    {
      "code": "CENTRAL_CLAIM_UNSUPPORTED",
      "field_path": "$.records[10].payload.state",
      "input_ref": {
        "id": "0000000b-2222-4222-8222-222222222222",
        "revision": 1,
        "sha256": "d8458861119958d2703305ca6207a00bf58da2efef237364043aa7c793780ba0",
        "type": "ClaimCheck"
      },
      "message": "A central factual claim has unresolved review."
    },
    {
      "code": "CENTRAL_CLAIM_UNSUPPORTED",
      "field_path": "$.records[9].payload.relation",
      "input_ref": {
        "id": "0000000a-2222-4222-8222-222222222222",
        "revision": 1,
        "sha256": "4c71b25ea8560e258bb1ddd9290e4324dd41d25eec7a02e2c743d0f60aa4e80e",
        "type": "EvidenceItem"
      },
      "message": "Recorded evidence remains in conflict."
    }
  ],
  "eligibility": {
    "reason_codes": [
      "CENTRAL_CLAIM_UNSUPPORTED"
    ],
    "state": "BLOCKED"
  },
  "status": "OK"
}
```

**Research preliminary ratings — НЕ SI ratings**

```text
[
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "audience_interest",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "channel_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "angle_novelty",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "evidence_quality",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "narrative_potential",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "visual_feasibility",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "resource_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "risk_manageability",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "portfolio_distinctness",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  }
]
```

## Ограничения

- SI результат относится только к supplied SI view, не к доказанному охвату исследования.
- Correspondence фиксирует заявление, не semantic equivalence или авторство.
- Research readiness не является SI eligibility или разрешением Topic Scoring.
- Баллы и critique labels не доказывают научную истину, фактическую проверку или независимость человека.
- Редактор принимает решение; bridge не создаёт рекомендацию, human findings или approval.
- Нет правового, коммерческого, публикационного или производственного разрешения.

## Незаполненный бланк решения человека

Бланк не подтверждает состоявшийся review. Ничего не выбрано и не датировано программой.

- [ ] Develop
- [ ] Research Further
- [ ] Reframe
- [ ] Reject
- [ ] Defer

**Обоснование:** ____________________

**Нерешённые риски:** ____________________

**Выбранный ракурс:** ____________________

**Следующие действия:** ____________________

**Личность редактора (заполнить вручную):** ____________________

**Дата review:** ____________________

HUMAN_PILOT_PENDING
