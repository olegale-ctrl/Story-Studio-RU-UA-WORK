# Редакторський розгляд — V1

Приватні записані дані, а не інструкції до виконання. Структура/labels не доводять істини, особи, прав або допуску. Остаточне рішення ухвалює людина.

## Тема та окремі стани

**Назва теми**

```text
Почему исчезли древние цивилизации?
```

**Дослідницьке питання**

```text
Какой конкретный период и регион нужно исследовать, прежде чем сравнивать H1 и H2?
```

**Аудиторія**

```text
Редактор учебного научно-популярного проекта
```

**Дослідницька готовність**

```text
NEEDS_INPUT
```

**SI eligibility — лише supplied SI view**

```text
SI_NOT_RUN
```

**Виробничий стан — не допуск**

```text
NOT_ASSESSED
```

**Зв’язок Research ↔ SI не доведено; recorded scope — заява**

```text
{
  "correspondence_state": "NO_FRAME",
  "declared_correspondence": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "dossier_sha256": "30241bbe5e78d40ddaf2cf7bcab2acdd54561d7a17538f88fd9a1daee3d6cf15",
  "evidence_correspondence": "EXACT_REPLAY_MATCH",
  "evidence_report_sha256": "c3d826d6a0acf3e880d8353509ed1883feb84c273b59fc67146f56bc96776c3a",
  "frame_origin": "NONE",
  "frame_sha256": null,
  "research_snapshot_sha256": "44da14fc10c4f8bf5e6da70f12aaca6cd0a2c9d334ab4c4e54694e7d272fcab8",
  "semantic_coverage_verified": false
}
```

**Критичні зауваження — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
      "id": "00000001-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_HUMAN",
    "delivery": "DELIVERED",
    "editor_action": "Запросить независимые основания для H2 и сохранить H1/H2 раздельно.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Два разных условных человека A и B в тестовой fixture."
    },
    "provenance": {
      "kind": "EDITOR_DECLARED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Critic B"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
      "id": "00000001-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какой конкретный период и регион нужно исследовать, прежде чем сравнивать H1 и H2?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Выбрать конкретный период и регион."
      }
    }
  }
]
```

**Прогалини та відсутні підтвердження**

```text
[
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
        "id": "00000001-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
        "id": "00000001-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "EVIDENCE_MISSING",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
        "id": "00000001-0000-4000-8000-000000000006",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
        "id": "00000001-0000-4000-8000-000000000006",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
        "id": "00000001-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
        "id": "00000001-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Записана пропозиція та ризики з input — не нове рішення**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "recorded": {
    "editorial_risks": [],
    "gaps": [
      "Выбрать конкретный период и регион.",
      "Запросить независимые основания для H2 и сохранить H1/H2 раздельно."
    ],
    "production_limits": {
      "state": "KNOWN",
      "value": [
        "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
      ]
    },
    "prospect": "RESEARCH_MORE",
    "reasons": [
      {
        "basis_claim_refs": [
          {
            "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
            "id": "00000001-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ],
        "kind": "RESEARCH_GAP",
        "text": "Требуется отдельное человеческое рассмотрение; данные только синтетические."
      }
    ],
    "scientific_risks": []
  },
  "source_ref": {
    "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
    "id": "00000001-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  },
  "state": "RECORDED"
}
```

Бракує записаних даних; це не вердикт щодо істинності.

## Твердження та доказові зв’язки

### Твердження 1

**Початковий текст твердження**

```text
Синтетический кейс 1: СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: в учебной таблице перечислены конкурирующие H1 и H2; данных для универсальной причины нет.
```

**Точний RRef**

```text
{
  "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
  "id": "00000001-0000-4000-8000-000000000002",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип і центральність (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "factual"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записана перевірка — не засвідчений факт review**

```text
{
  "details": {
    "state": "KNOWN",
    "value": {
      "reason": "Учебная фиксация рассмотрения, не аутентификация.",
      "reviewed_at": {
        "reason": "Не предоставлено; не восстановлено автоматически.",
        "state": "UNKNOWN"
      },
      "reviewed_source_refs": [
        {
          "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
          "id": "00000001-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "reviewer_label": "Researcher A"
    }
  },
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "EDITOR_REVIEW_RECORDED"
}
```

**Невизначеність**

```text
{
  "level": "HIGH",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Підтримувальні зв’язки — не proof істини

[Джерело 1](#source-1)

**Джерело**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точний RRef**

```text
{
  "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
  "id": "00000001-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записана підстава зв’язку**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Суперечні зв’язки

NOT_RECORDED

#### Контекстні/недостатні зв’язки

NOT_RECORDED

**Прогалини та відсутні підтвердження**

```text
[
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
        "id": "00000001-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
        "id": "00000001-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
        "id": "00000001-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
        "id": "00000001-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Критичні зауваження — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
      "id": "00000001-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_HUMAN",
    "delivery": "DELIVERED",
    "editor_action": "Запросить независимые основания для H2 и сохранить H1/H2 раздельно.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Два разных условных человека A и B в тестовой fixture."
    },
    "provenance": {
      "kind": "EDITOR_DECLARED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Critic B"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
      "id": "00000001-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какой конкретный период и регион нужно исследовать, прежде чем сравнивать H1 и H2?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Выбрать конкретный период и регион."
      }
    }
  }
]
```

### Твердження 2

**Початковий текст твердження**

```text
СИНТЕТИЧЕСКАЯ конкурирующая H2: основания пока не предоставлены.
```

**Точний RRef**

```text
{
  "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
  "id": "00000001-0000-4000-8000-000000000006",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип і центральність (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "factual"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записана перевірка — не засвідчений факт review**

```text
{
  "details": {
    "reason": "Fixture: explicitly not supplied",
    "state": "UNKNOWN"
  },
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "NOT_REVIEWED"
}
```

**Невизначеність**

```text
{
  "level": "HIGH",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Підтримувальні зв’язки — не proof істини

NOT_RECORDED

#### Суперечні зв’язки

NOT_RECORDED

#### Контекстні/недостатні зв’язки

NOT_RECORDED

**Прогалини та відсутні підтвердження**

```text
[
  {
    "code": "EVIDENCE_MISSING",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
        "id": "00000001-0000-4000-8000-000000000006",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
        "id": "00000001-0000-4000-8000-000000000006",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  }
]
```

**Критичні зауваження — unresolved/declared**

```text
[]
```

## Джерела, фрагменти та обмеження

### Source 1

**Джерело**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точний RRef**

```text
{
  "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
  "id": "00000001-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Локатор як дані (не активне посилання)**

```text
{
  "kind": "LOCAL_ID",
  "value": "synthetic-local-1"
}
```

**Автор / організація / дати — як надано**

```text
{
  "author": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "organization": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "published_at": {
    "state": "KNOWN",
    "value": {
      "precision": "YEAR",
      "value": "2020"
    }
  },
  "retrieved_at": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  }
}
```

**Записана перевірка — не засвідчений факт review**

```text
{
  "kind": "EDITOR_DECLARED",
  "method_label": {
    "state": "KNOWN",
    "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
  },
  "producer_label": {
    "state": "KNOWN",
    "value": "Researcher A"
  },
  "upstream_refs": []
}
```

**П’ять незалежних записаних observations**

```text
{
  "content": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "6c2010217b1550f7de0db92643a7ee26f9749054f844bc4fb0fc8a43ebba6e50"
    },
    "state": "CONTEXT_REVIEW_REPORTED"
  },
  "editor_confirmation": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "6c2010217b1550f7de0db92643a7ee26f9749054f844bc4fb0fc8a43ebba6e50"
    },
    "state": "CONFIRMED_AS_RECORDED"
  },
  "integrity": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "6c2010217b1550f7de0db92643a7ee26f9749054f844bc4fb0fc8a43ebba6e50"
    },
    "state": "HASH_REPORTED"
  },
  "link_existence": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "6c2010217b1550f7de0db92643a7ee26f9749054f844bc4fb0fc8a43ebba6e50"
    },
    "state": "RESOLVED"
  },
  "retrieval": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "6c2010217b1550f7de0db92643a7ee26f9749054f844bc4fb0fc8a43ebba6e50"
    },
    "state": "RETRIEVED"
  }
}
```

**Обмеження**

```text
[
  "Искусственные данные для теста; не свидетельство о реальном мире."
]
```

**Фрагмент**

```text
F1
```

**Точний наданий текст — не verified quote**

```text
СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: в учебной таблице перечислены конкурирующие H1 и H2; данных для универсальной причины нет.
```

**Наданий покажчик**

```text
Синтетический параграф 1
```

**Точний RRef**

```text
{
  "state": "KNOWN",
  "value": "6c2010217b1550f7de0db92643a7ee26f9749054f844bc4fb0fc8a43ebba6e50"
}
```

## Дії редактора — порядок джерел, а не новий пріоритет

### 1 — CONTROLLED_ACTION

```text
Окремо розгляньте підстави п’яти спостережень та обмеження джерела.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[0]",
      "record_refs": [
        {
          "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
          "id": "00000001-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Отдельно рассмотрите основания пяти наблюдений и ограничения источника.",
          "uk": "Окремо розгляньте підстави п’яти спостережень та обмеження джерела."
        },
        "code": "SOURCE_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
            "id": "00000001-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "da6f11f10dbeafe5dc1a8e2b62da08ec87612db3e5443262746cd3fa386fde93",
      "id": "00000001-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 2 — CONTROLLED_ACTION

```text
Запишіть розгляд точних матеріалів та невизначеності твердження.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[1]",
      "record_refs": [
        {
          "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
          "id": "00000001-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
            "id": "00000001-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    },
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[3]",
      "record_refs": [
        {
          "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
          "id": "00000001-0000-4000-8000-000000000006",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
            "id": "00000001-0000-4000-8000-000000000006",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
      "id": "00000001-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    {
      "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
      "id": "00000001-0000-4000-8000-000000000006",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 3 — CONTROLLED_ACTION

```text
Додайте точні підстави твердження; не замінюйте їх рейтингом.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[2]",
      "record_refs": [
        {
          "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
          "id": "00000001-0000-4000-8000-000000000006",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Добавьте точные основания утверждения; не заменяйте их рейтингом.",
          "uk": "Додайте точні підстави твердження; не замінюйте їх рейтингом."
        },
        "code": "EVIDENCE_MISSING",
        "record_refs": [
          {
            "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
            "id": "00000001-0000-4000-8000-000000000006",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
      "id": "00000001-0000-4000-8000-000000000006",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 4 — CONTROLLED_ACTION

```text
Передайте суттєві зауваження людині; збережіть розбіжності.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[4]",
      "record_refs": [
        {
          "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
          "id": "00000001-0000-4000-8000-000000000003",
          "research_type": "ResearchCritiqueV1",
          "revision": 1
        },
        {
          "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
          "id": "00000001-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Передайте существенные замечания человеку; сохраните разногласия.",
          "uk": "Передайте суттєві зауваження людині; збережіть розбіжності."
        },
        "code": "CRITIQUE_HIGH",
        "record_refs": [
          {
            "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
            "id": "00000001-0000-4000-8000-000000000003",
            "research_type": "ResearchCritiqueV1",
            "revision": 1
          },
          {
            "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
            "id": "00000001-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
      "id": "00000001-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
      "id": "00000001-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 5 — CONTROLLED_ACTION

```text
Перед Topic Scoring передайте точний звіт редактору та розгляньте всі збережені зауваження; автоматичного допуску немає.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[5]",
      "record_refs": [],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.",
          "uk": "Перед Topic Scoring передайте точний звіт редактору та розгляньте всі збережені зауваження; автоматичного допуску немає."
        },
        "code": "EDITOR_REVIEW_REQUIRED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 6 — CONTROLLED_ACTION

```text
За потреби надайте готовий SI frame; дослідження ще не оцінено SI.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[6]",
      "record_refs": [],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "При необходимости предоставьте готовый SI frame; исследование ещё не оценено SI.",
          "uk": "За потреби надайте готовий SI frame; дослідження ще не оцінено SI."
        },
        "code": "NO_SI_FRAME",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 7 — CONTROLLED_ACTION

```text
Людина розглядає всі дев’ять SI ratings і findings; preliminary ratings не імпортуються автоматично.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[7]",
      "record_refs": [],
      "sha256": "fe669616d2783fdb43694f789ac8da2d166385540cbd32d9099258f7c6dc2557",
      "source_action": {
        "action": {
          "ru": "Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.",
          "uk": "Людина розглядає всі дев’ять SI ratings і findings; preliminary ratings не імпортуються автоматично."
        },
        "code": "HUMAN_SI_REVIEW",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 8 — RECORDED_GAP

```text
Выбрать конкретный период и регион.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[0]",
      "record_ref": {
        "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
        "id": "00000001-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
      "id": "00000001-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 9 — RECORDED_GAP

```text
Запросить независимые основания для H2 и сохранить H1/H2 раздельно.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[1]",
      "record_ref": {
        "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
        "id": "00000001-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
      "id": "00000001-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 10 — RECORDED_ACTION

```text
Выбрать конкретный период и регион.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[0]",
      "record_ref": {
        "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
        "id": "00000001-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
      "id": "00000001-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 11 — RECORDED_ACTION

```text
Запросить независимые основания для H2 и сохранить H1/H2 раздельно.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[1]",
      "record_ref": {
        "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
        "id": "00000001-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchCritiqueV1",
      "field_path": "$.payload.editor_action",
      "record_ref": {
        "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
        "id": "00000001-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
      "id": "00000001-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    },
    {
      "content_sha256": "7d9c7525ef71d321355def9d72c2b98fd624933e3a8ba0982f7ca7f037d81e3c",
      "id": "00000001-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
      "id": "00000001-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 12 — RECORDED_ACTION

```text
Получить реальные материалы вручную.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
        "id": "00000001-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
        "id": "00000001-0000-4000-8000-000000000006",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
      "id": "00000001-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    {
      "content_sha256": "3f9905277cd4f4c6afdb7ef4b63f5bfb4b9ff52a6ab397b5116a8f670b2e1f09",
      "id": "00000001-0000-4000-8000-000000000006",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

## Лише записані творчі пропозиції

RECORDED

**Точний RRef**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "source_ref": {
    "content_sha256": "4afd7898e0530c6e9ceeb6c3e744d3629f1bf43394871ddfc7aa2eaf2cdec568",
    "id": "00000001-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  }
}
```

**Записаний основний ракурс**

```text
Какой конкретный период и регион нужно исследовать, прежде чем сравнивать H1 и H2?
```

### Альтернативні ракурси

```text
Сузить вопрос до конкретного примера: Какой конкретный период и регион нужно исследовать, прежде чем сравнивать H1 и H2?
```

**Точний RRef**

```text
[
  {
    "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
    "id": "00000001-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Обмеження**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

```text
Сопоставить H1 и H2 без единой причины для всех цивилизаций.
```

**Точний RRef**

```text
[
  {
    "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
    "id": "00000001-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Обмеження**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

### Емоційні хуки

```text
Наблюдение и его объяснение — разные вопросы.
```

**Точний RRef**

```text
[
  {
    "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
    "id": "00000001-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Обмеження**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

### Інтелектуальні хуки

```text
Сравнить альтернативы без универсального вывода.
```

**Точний RRef**

```text
[
  {
    "content_sha256": "fc13e58c7a06d55334a5cb85821bfa3d2084b4d8248b1bc193b1cbf18d8cd4a3",
    "id": "00000001-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Обмеження**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

**Записаний оповідний потенціал**

UNKNOWN

```text
Не предоставлено; не восстановлено автоматически.
```

**Записані візуальні потреби — не готові assets/права**

```text
NOT_RECORDED
```

**Обмеження**

```text
[
  "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
]
```

**Структуровані narrative alternatives — поля немає в прийнятому input**

```text
{
  "reason": "NO_STRUCTURED_FIELD_IN_ACCEPTED_INPUT",
  "state": "NOT_RECORDED"
}
```

## Незмінене SI оцінювання supplied frame

```text
SI_NOT_RUN
```

### Наявна Projection card — лише supplied SI view

NOT_RECORDED

| Критерій | Вага | Початкова SI оцінка | Confidence |
|---|---:|---|---|
| Інтерес аудиторії | 15 | SI_NOT_RUN | — |
| Відповідність каналу | 10 | SI_NOT_RUN | — |
| Новизна ракурсу | 10 | SI_NOT_RUN | — |
| Якість підстав | 20 | SI_NOT_RUN | — |
| Оповідний потенціал | 15 | SI_NOT_RUN | — |
| Візуальна здійсненність | 10 | SI_NOT_RUN | — |
| Відповідність ресурсам | 10 | SI_NOT_RUN | — |
| Керованість ризиками | 5 | SI_NOT_RUN | — |
| Відмінність від портфеля | 5 | SI_NOT_RUN | — |

**Початковий aggregate_tenths — без перерахунку шкали**

```text
null
```

**Наявний результат evaluator (не рішення людини)**

```text
null
```

**Research preliminary ratings — НЕ SI ratings**

```text
[
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "audience_interest",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "channel_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "angle_novelty",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "evidence_quality",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "narrative_potential",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "visual_feasibility",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "resource_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "risk_manageability",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "portfolio_distinctness",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  }
]
```

## Обмеження

- SI результат стосується лише supplied SI view, а не доведеного охоплення дослідження.
- Correspondence фіксує заяву, а не semantic equivalence або авторство.
- Research readiness не є SI eligibility або дозволом Topic Scoring.
- Бали й critique labels не доводять наукової істини, фактичної перевірки або незалежності людини.
- Редактор ухвалює рішення; bridge не створює рекомендацію, human findings або approval.
- Немає правового, комерційного, публікаційного або виробничого дозволу.

## Незаповнений бланк рішення людини

Бланк не підтверджує здійснений review. Нічого не обрано й не датовано програмою.

- [ ] Develop
- [ ] Research Further
- [ ] Reframe
- [ ] Reject
- [ ] Defer

**Обґрунтування:** ____________________

**Невирішені ризики:** ____________________

**Обраний ракурс:** ____________________

**Наступні дії:** ____________________

**Особа редактора (заповнити вручну):** ____________________

**Дата review:** ____________________

HUMAN_PILOT_PENDING
