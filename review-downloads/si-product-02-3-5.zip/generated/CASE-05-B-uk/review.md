# Редакторський розгляд — V1

Приватні записані дані, а не інструкції до виконання. Структура/labels не доводять істини, особи, прав або допуску. Остаточне рішення ухвалює людина.

## Тема та окремі стани

**Назва теми**

```text
Почему некоторые популярные исторические факты оказались мифами?
```

**Дослідницьке питання**

```text
Какой один исторический пример и его исходное свидетельство предстоит выбрать?
```

**Аудиторія**

```text
Редактор учебного научно-популярного проекта
```

**Дослідницька готовність**

```text
NEEDS_REVIEW
```

**SI eligibility — лише supplied SI view**

```text
{
  "reason_codes": [
    "CENTRAL_CLAIM_UNSUPPORTED"
  ],
  "state": "BLOCKED"
}
```

**Виробничий стан — не допуск**

```text
NOT_ASSESSED
```

**Зв’язок Research ↔ SI не доведено; recorded scope — заява**

```text
{
  "correspondence_state": "UNVERIFIED_SCOPE",
  "declared_correspondence": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "dossier_sha256": "bd481c1db712cebd23a247ff039b96acc907513806c18399bf3b537ad8826d43",
  "evidence_correspondence": "EXACT_REPLAY_MATCH",
  "evidence_report_sha256": "22449924addc515e3cc28c47c18e872ab6e19dc4e4a03ff3a841c204f37a4f28",
  "frame_origin": "EXPLICIT",
  "frame_sha256": "75eb2aa631a43ea536922605a4ec03bc74aa4f67f717fb250ae7fb0f3c1aa9e2",
  "research_snapshot_sha256": "d3a2245dc5a22e705aa7b3ff91703b194b55649bb1efd020c2128d0776927f4d",
  "semantic_coverage_verified": false
}
```

**Критичні зауваження — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
      "id": "00000005-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_HUMAN",
    "delivery": "DELIVERED",
    "editor_action": "Проследить исходное свидетельство и сохранить противоречия.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Два разных условных человека A и B в тестовой fixture."
    },
    "provenance": {
      "kind": "EDITOR_DECLARED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Researcher A"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какой один исторический пример и его исходное свидетельство предстоит выбрать?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Выбрать один реальный исторический пример до сбора доказательств."
      }
    }
  }
]
```

**Прогалини та відсутні підтвердження**

```text
[
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
        "id": "00000005-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
        "id": "00000005-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CONTRADICTION_UNRESOLVED",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
        "id": "00000005-0000-4000-8000-000000000007",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_INDEPENDENCE_UNKNOWN",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
        "id": "00000005-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
        "id": "00000005-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Записана пропозиція та ризики з input — не нове рішення**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "recorded": {
    "editorial_risks": [],
    "gaps": [
      "Выбрать один реальный исторический пример до сбора доказательств.",
      "Проследить исходное свидетельство и сохранить противоречия."
    ],
    "production_limits": {
      "state": "KNOWN",
      "value": [
        "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
      ]
    },
    "prospect": "RESEARCH_MORE",
    "reasons": [
      {
        "basis_claim_refs": [
          {
            "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
            "id": "00000005-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ],
        "kind": "RESEARCH_GAP",
        "text": "Требуется отдельное человеческое рассмотрение; данные только синтетические."
      }
    ],
    "scientific_risks": []
  },
  "source_ref": {
    "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
    "id": "00000005-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  },
  "state": "RECORDED"
}
```

Надані дані потребують розгляду людиною.

## Твердження та доказові зв’язки

### Твердження 1

**Початковий текст твердження**

```text
Синтетический кейс 5: СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: условная запись M1 и её поздняя интерпретация расходятся; это не свидетельство о реальной истории.
```

**Точний RRef**

```text
{
  "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
  "id": "00000005-0000-4000-8000-000000000002",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип і центральність (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "factual"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записана перевірка — не засвідчений факт review**

```text
{
  "details": {
    "state": "KNOWN",
    "value": {
      "reason": "Учебная фиксация рассмотрения, не аутентификация.",
      "reviewed_at": {
        "reason": "Не предоставлено; не восстановлено автоматически.",
        "state": "UNKNOWN"
      },
      "reviewed_source_refs": [
        {
          "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
          "id": "00000005-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        },
        {
          "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
          "id": "00000005-0000-4000-8000-000000000006",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "reviewer_label": "Researcher A"
    }
  },
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "DISAGREEMENT_RECORDED"
}
```

**Невизначеність**

```text
{
  "level": "HIGH",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Підтримувальні зв’язки — не proof істини

[Джерело 1](#source-1)

**Джерело**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точний RRef**

```text
{
  "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
  "id": "00000005-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записана підстава зв’язку**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Суперечні зв’язки

[Джерело 2](#source-2)

**Джерело**

```text
СИНТЕТИЧЕСКИЙ локальный материал 91
```

**Точний RRef**

```text
{
  "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
  "id": "00000005-0000-4000-8000-000000000006",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записана підстава зв’язку**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Контекстні/недостатні зв’язки

NOT_RECORDED

**Прогалини та відсутні підтвердження**

```text
[
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
        "id": "00000005-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
        "id": "00000005-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CONTRADICTION_UNRESOLVED",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_INDEPENDENCE_UNKNOWN",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
        "id": "00000005-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
        "id": "00000005-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Критичні зауваження — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
      "id": "00000005-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_HUMAN",
    "delivery": "DELIVERED",
    "editor_action": "Проследить исходное свидетельство и сохранить противоречия.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Два разных условных человека A и B в тестовой fixture."
    },
    "provenance": {
      "kind": "EDITOR_DECLARED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Researcher A"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какой один исторический пример и его исходное свидетельство предстоит выбрать?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Выбрать один реальный исторический пример до сбора доказательств."
      }
    }
  }
]
```

### Твердження 2

**Початковий текст твердження**

```text
СИНТЕТИЧЕСКАЯ редакционная интерпретация: Какой один исторический пример и его исходное свидетельство предстоит выбрать?
```

**Точний RRef**

```text
{
  "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
  "id": "00000005-0000-4000-8000-000000000007",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип і центральність (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "interpretation"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записана перевірка — не засвідчений факт review**

```text
{
  "details": {
    "reason": "Fixture: explicitly not supplied",
    "state": "UNKNOWN"
  },
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "NOT_REVIEWED"
}
```

**Невизначеність**

```text
{
  "level": "HIGH",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Підтримувальні зв’язки — не proof істини

[Джерело 2](#source-2)

**Джерело**

```text
СИНТЕТИЧЕСКИЙ локальный материал 91
```

**Точний RRef**

```text
{
  "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
  "id": "00000005-0000-4000-8000-000000000006",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записана підстава зв’язку**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Суперечні зв’язки

NOT_RECORDED

#### Контекстні/недостатні зв’язки

NOT_RECORDED

**Прогалини та відсутні підтвердження**

```text
[
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
        "id": "00000005-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
        "id": "00000005-0000-4000-8000-000000000007",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  }
]
```

**Критичні зауваження — unresolved/declared**

```text
[]
```

## Джерела, фрагменти та обмеження

### Source 1

**Джерело**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точний RRef**

```text
{
  "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
  "id": "00000005-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Локатор як дані (не активне посилання)**

```text
{
  "kind": "LOCAL_ID",
  "value": "synthetic-local-1"
}
```

**Автор / організація / дати — як надано**

```text
{
  "author": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "organization": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "published_at": {
    "state": "KNOWN",
    "value": {
      "precision": "YEAR",
      "value": "2020"
    }
  },
  "retrieved_at": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  }
}
```

**Записана перевірка — не засвідчений факт review**

```text
{
  "kind": "EDITOR_DECLARED",
  "method_label": {
    "state": "KNOWN",
    "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
  },
  "producer_label": {
    "state": "KNOWN",
    "value": "Researcher A"
  },
  "upstream_refs": []
}
```

**П’ять незалежних записаних observations**

```text
{
  "content": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "fe61b83ee0b7a6ddcae94b67331435f2ef663280a0b85873d367a1ffe45ddf11"
    },
    "state": "CONTEXT_REVIEW_REPORTED"
  },
  "editor_confirmation": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "fe61b83ee0b7a6ddcae94b67331435f2ef663280a0b85873d367a1ffe45ddf11"
    },
    "state": "CONFIRMED_AS_RECORDED"
  },
  "integrity": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "fe61b83ee0b7a6ddcae94b67331435f2ef663280a0b85873d367a1ffe45ddf11"
    },
    "state": "HASH_REPORTED"
  },
  "link_existence": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "fe61b83ee0b7a6ddcae94b67331435f2ef663280a0b85873d367a1ffe45ddf11"
    },
    "state": "RESOLVED"
  },
  "retrieval": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "fe61b83ee0b7a6ddcae94b67331435f2ef663280a0b85873d367a1ffe45ddf11"
    },
    "state": "RETRIEVED"
  }
}
```

**Обмеження**

```text
[
  "Искусственные данные для теста; не свидетельство о реальном мире."
]
```

**Фрагмент**

```text
F1
```

**Точний наданий текст — не verified quote**

```text
СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: условная запись M1 и её поздняя интерпретация расходятся; это не свидетельство о реальной истории.
```

**Наданий покажчик**

```text
Синтетический параграф 1
```

**Точний RRef**

```text
{
  "state": "KNOWN",
  "value": "fe61b83ee0b7a6ddcae94b67331435f2ef663280a0b85873d367a1ffe45ddf11"
}
```

### Source 2

**Джерело**

```text
СИНТЕТИЧЕСКИЙ локальный материал 91
```

**Точний RRef**

```text
{
  "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
  "id": "00000005-0000-4000-8000-000000000006",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Локатор як дані (не активне посилання)**

```text
{
  "kind": "LOCAL_ID",
  "value": "synthetic-local-91"
}
```

**Автор / організація / дати — як надано**

```text
{
  "author": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "organization": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "published_at": {
    "state": "KNOWN",
    "value": {
      "precision": "YEAR",
      "value": "2020"
    }
  },
  "retrieved_at": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  }
}
```

**Записана перевірка — не засвідчений факт review**

```text
{
  "kind": "EDITOR_DECLARED",
  "method_label": {
    "state": "KNOWN",
    "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
  },
  "producer_label": {
    "state": "KNOWN",
    "value": "Researcher A"
  },
  "upstream_refs": [
    {
      "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
      "id": "00000005-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

**П’ять незалежних записаних observations**

```text
{
  "content": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "0755b395b33660367b75184eb83963d2099407b22ebbb5146eefbbc12a0eb82b"
    },
    "state": "CONTEXT_REVIEW_REPORTED"
  },
  "editor_confirmation": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "0755b395b33660367b75184eb83963d2099407b22ebbb5146eefbbc12a0eb82b"
    },
    "state": "CONFIRMED_AS_RECORDED"
  },
  "integrity": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "0755b395b33660367b75184eb83963d2099407b22ebbb5146eefbbc12a0eb82b"
    },
    "state": "HASH_REPORTED"
  },
  "link_existence": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "0755b395b33660367b75184eb83963d2099407b22ebbb5146eefbbc12a0eb82b"
    },
    "state": "RESOLVED"
  },
  "retrieval": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "0755b395b33660367b75184eb83963d2099407b22ebbb5146eefbbc12a0eb82b"
    },
    "state": "RETRIEVED"
  }
}
```

**Обмеження**

```text
[
  "Искусственные данные для теста; не свидетельство о реальном мире."
]
```

**Фрагмент**

```text
F1
```

**Точний наданий текст — не verified quote**

```text
СИНТЕТИЧЕСКАЯ производная запись M2 иначе интерпретирует M1; независимость не установлена.
```

**Наданий покажчик**

```text
Синтетический параграф 1
```

**Точний RRef**

```text
{
  "state": "KNOWN",
  "value": "0755b395b33660367b75184eb83963d2099407b22ebbb5146eefbbc12a0eb82b"
}
```

## Дії редактора — порядок джерел, а не новий пріоритет

### 1 — CONTROLLED_ACTION

```text
Окремо розгляньте підстави п’яти спостережень та обмеження джерела.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[0]",
      "record_refs": [
        {
          "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
          "id": "00000005-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Отдельно рассмотрите основания пяти наблюдений и ограничения источника.",
          "uk": "Окремо розгляньте підстави п’яти спостережень та обмеження джерела."
        },
        "code": "SOURCE_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
            "id": "00000005-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    },
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[1]",
      "record_refs": [
        {
          "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
          "id": "00000005-0000-4000-8000-000000000006",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Отдельно рассмотрите основания пяти наблюдений и ограничения источника.",
          "uk": "Окремо розгляньте підстави п’яти спостережень та обмеження джерела."
        },
        "code": "SOURCE_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
            "id": "00000005-0000-4000-8000-000000000006",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "d0dc534bf03fdbbc2493fdda09cc087c4699eed482ab772df1c3001597c3fd32",
      "id": "00000005-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    },
    {
      "content_sha256": "962b25126c94adea22bbb1cdc133940cef13d7618843d2ede48b5d69d0dc6c1d",
      "id": "00000005-0000-4000-8000-000000000006",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 2 — CONTROLLED_ACTION

```text
Розгляньте всі контрдокази; не усувайте їх голосуванням.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[2]",
      "record_refs": [
        {
          "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
          "id": "00000005-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Рассмотрите все контрдоказательства; не устраняйте их голосованием.",
          "uk": "Розгляньте всі контрдокази; не усувайте їх голосуванням."
        },
        "code": "CONTRADICTION_UNRESOLVED",
        "record_refs": [
          {
            "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
            "id": "00000005-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 3 — CONTROLLED_ACTION

```text
Запишіть розгляд точних матеріалів та невизначеності твердження.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[3]",
      "record_refs": [
        {
          "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
          "id": "00000005-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
            "id": "00000005-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    },
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[4]",
      "record_refs": [
        {
          "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
          "id": "00000005-0000-4000-8000-000000000007",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
            "id": "00000005-0000-4000-8000-000000000007",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    {
      "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
      "id": "00000005-0000-4000-8000-000000000007",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 4 — CONTROLLED_ACTION

```text
Уточніть незалежність критика; labels не засвідчують особу.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[5]",
      "record_refs": [
        {
          "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
          "id": "00000005-0000-4000-8000-000000000003",
          "research_type": "ResearchCritiqueV1",
          "revision": 1
        },
        {
          "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
          "id": "00000005-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Уточните независимость критика; labels не удостоверяют личность.",
          "uk": "Уточніть незалежність критика; labels не засвідчують особу."
        },
        "code": "CRITIQUE_INDEPENDENCE_UNKNOWN",
        "record_refs": [
          {
            "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
            "id": "00000005-0000-4000-8000-000000000003",
            "research_type": "ResearchCritiqueV1",
            "revision": 1
          },
          {
            "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
            "id": "00000005-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
      "id": "00000005-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 5 — CONTROLLED_ACTION

```text
Передайте суттєві зауваження людині; збережіть розбіжності.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[6]",
      "record_refs": [
        {
          "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
          "id": "00000005-0000-4000-8000-000000000003",
          "research_type": "ResearchCritiqueV1",
          "revision": 1
        },
        {
          "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
          "id": "00000005-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Передайте существенные замечания человеку; сохраните разногласия.",
          "uk": "Передайте суттєві зауваження людині; збережіть розбіжності."
        },
        "code": "CRITIQUE_HIGH",
        "record_refs": [
          {
            "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
            "id": "00000005-0000-4000-8000-000000000003",
            "research_type": "ResearchCritiqueV1",
            "revision": 1
          },
          {
            "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
            "id": "00000005-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
      "id": "00000005-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 6 — CONTROLLED_ACTION

```text
Перед Topic Scoring передайте точний звіт редактору та розгляньте всі збережені зауваження; автоматичного допуску немає.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[7]",
      "record_refs": [],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.",
          "uk": "Перед Topic Scoring передайте точний звіт редактору та розгляньте всі збережені зауваження; автоматичного допуску немає."
        },
        "code": "EDITOR_REVIEW_REQUIRED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 7 — CONTROLLED_ACTION

```text
Розгляньте точну відповідність дослідження та supplied SI; змістове охоплення не доведено.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[8]",
      "record_refs": [],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Рассмотрите точное соответствие исследования и supplied SI; смысловой охват не доказан.",
          "uk": "Розгляньте точну відповідність дослідження та supplied SI; змістове охоплення не доведено."
        },
        "code": "SCOPE_UNVERIFIED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 8 — CONTROLLED_ACTION

```text
Людина розглядає всі дев’ять SI ratings і findings; preliminary ratings не імпортуються автоматично.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[9]",
      "record_refs": [],
      "sha256": "fd3232f447c4a127125bcd65030f6fa97ad58b3a635bb8bd0f28c146a66ea658",
      "source_action": {
        "action": {
          "ru": "Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.",
          "uk": "Людина розглядає всі дев’ять SI ratings і findings; preliminary ratings не імпортуються автоматично."
        },
        "code": "HUMAN_SI_REVIEW",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 9 — RECORDED_GAP

```text
Выбрать один реальный исторический пример до сбора доказательств.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[0]",
      "record_ref": {
        "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
        "id": "00000005-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
      "id": "00000005-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 10 — RECORDED_GAP

```text
Проследить исходное свидетельство и сохранить противоречия.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[1]",
      "record_ref": {
        "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
        "id": "00000005-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
      "id": "00000005-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 11 — RECORDED_ACTION

```text
Выбрать один реальный исторический пример до сбора доказательств.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[0]",
      "record_ref": {
        "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
        "id": "00000005-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
      "id": "00000005-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 12 — RECORDED_ACTION

```text
Проследить исходное свидетельство и сохранить противоречия.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[1]",
      "record_ref": {
        "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
        "id": "00000005-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchCritiqueV1",
      "field_path": "$.payload.editor_action",
      "record_ref": {
        "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
        "id": "00000005-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
      "id": "00000005-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    },
    {
      "content_sha256": "395f18016f3aa0c0fb22ad9619eeef5b098397f66cd08bb7fa9c149a192ba21c",
      "id": "00000005-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 13 — RECORDED_ACTION

```text
Получить реальные материалы вручную.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
        "id": "00000005-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
        "id": "00000005-0000-4000-8000-000000000007",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
      "id": "00000005-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    {
      "content_sha256": "f2574539082408c546acd75ae9d9c3a44a188098c2404c77427c073971238e7f",
      "id": "00000005-0000-4000-8000-000000000007",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

## Лише записані творчі пропозиції

RECORDED

**Точний RRef**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "source_ref": {
    "content_sha256": "baa84f6f1e9856ab359469a70d9c3adbc7249374f7d06320d40cf93898d04533",
    "id": "00000005-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  }
}
```

**Записаний основний ракурс**

```text
Какой один исторический пример и его исходное свидетельство предстоит выбрать?
```

### Альтернативні ракурси

```text
Сузить вопрос до конкретного примера: Какой один исторический пример и его исходное свидетельство предстоит выбрать?
```

**Точний RRef**

```text
[
  {
    "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
    "id": "00000005-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Обмеження**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

### Емоційні хуки

NOT_RECORDED

### Інтелектуальні хуки

```text
Сравнить альтернативы без универсального вывода.
```

**Точний RRef**

```text
[
  {
    "content_sha256": "1da73912f1bda60e1c40fcbcf3c493a90e9e8add6a7a9e2e9cc50d0fce5641e7",
    "id": "00000005-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Обмеження**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

**Записаний оповідний потенціал**

UNKNOWN

```text
Не предоставлено; не восстановлено автоматически.
```

**Записані візуальні потреби — не готові assets/права**

```text
NOT_RECORDED
```

**Обмеження**

```text
[
  "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
]
```

**Структуровані narrative alternatives — поля немає в прийнятому input**

```text
{
  "reason": "NO_STRUCTURED_FIELD_IN_ACCEPTED_INPUT",
  "state": "NOT_RECORDED"
}
```

## Незмінене SI оцінювання supplied frame

```text
OK
```

### Наявна Projection card — лише supplied SI view

**decision_summary**

```text
Продовження творчої розробки заблоковане зазначеними умовами.
```

**reasons**

```text
Підстава — умови, зафіксовані оцінкою переданих даних.
```

```text
Бали за заданою рубрикою: 1000 із 1000.
```

```text
Перевірка твердження 1: Перевірка центрального фактичного твердження залишається невирішеною або недостатньою.
```

```text
Свідчення 1: У зафіксованих даних залишається суперечність.
```

**blocking_risks_and_gaps**

```text
Перевірка твердження 1: Перевірка центрального фактичного твердження залишається невирішеною або недостатньою.
```

```text
Свідчення 1: У зафіксованих даних залишається суперечність.
```

**next_actions**

```text
Перевірка твердження 1: Дослідіть твердження й суперечливі дані; передайте суттєві розбіжності на розгляд людині.
```

```text
Свідчення 1: Дослідіть твердження й суперечливі дані; передайте суттєві розбіжності на розгляд людині.
```

**limitations**

```text
Картка пояснює лише оцінку переданого контексту; повноту зовнішніх даних не встановлено.
```

```text
Бали й упевненість не доводять наукової істинності, достовірності джерел або попиту аудиторії.
```

```text
Розгляд наукових висновків людиною й усіх семи сфер наукової перевірки цією карткою не засвідчується.
```

```text
Права на матеріали, фактична доступність і здійсненність виробництва потребують окремої перевірки.
```

```text
Картка не засвідчує особу, компетентність або повноваження перевіряльника й не надає редакційного затвердження.
```

```text
Допуск до творчої розробки не є дозволом на виробництво або публікацію.
```

| Критерій | Вага | Початкова SI оцінка | Confidence |
|---|---:|---|---|
| Інтерес аудиторії | 15 | 5 | HIGH |
| Відповідність каналу | 10 | 5 | HIGH |
| Новизна ракурсу | 10 | 5 | HIGH |
| Якість підстав | 20 | 5 | HIGH |
| Оповідний потенціал | 15 | 5 | HIGH |
| Візуальна здійсненність | 10 | 5 | HIGH |
| Відповідність ресурсам | 10 | 5 | HIGH |
| Керованість ризиками | 5 | 5 | HIGH |
| Відмінність від портфеля | 5 | 5 | HIGH |

**Інтерес аудиторії**

```text
Synthetic supplied rating
```

**Відповідність каналу**

```text
Synthetic supplied rating
```

**Новизна ракурсу**

```text
Synthetic supplied rating
```

**Якість підстав**

```text
Synthetic supplied rating
```

**Оповідний потенціал**

```text
Synthetic supplied rating
```

**Візуальна здійсненність**

```text
Synthetic supplied rating
```

**Відповідність ресурсам**

```text
Synthetic supplied rating
```

**Керованість ризиками**

```text
Synthetic supplied rating
```

**Відмінність від портфеля**

```text
Synthetic supplied rating
```

**Початковий aggregate_tenths — без перерахунку шкали**

```text
{
  "state": "KNOWN",
  "value": 1000
}
```

**Наявний результат evaluator (не рішення людини)**

```text
{
  "currentness": "CURRENT",
  "diagnostics": [
    {
      "code": "CENTRAL_CLAIM_UNSUPPORTED",
      "field_path": "$.records[10].payload.state",
      "input_ref": {
        "id": "0000000b-2222-4222-8222-222222222222",
        "revision": 1,
        "sha256": "d8458861119958d2703305ca6207a00bf58da2efef237364043aa7c793780ba0",
        "type": "ClaimCheck"
      },
      "message": "A central factual claim has unresolved review."
    },
    {
      "code": "CENTRAL_CLAIM_UNSUPPORTED",
      "field_path": "$.records[9].payload.relation",
      "input_ref": {
        "id": "0000000a-2222-4222-8222-222222222222",
        "revision": 1,
        "sha256": "4c71b25ea8560e258bb1ddd9290e4324dd41d25eec7a02e2c743d0f60aa4e80e",
        "type": "EvidenceItem"
      },
      "message": "Recorded evidence remains in conflict."
    }
  ],
  "eligibility": {
    "reason_codes": [
      "CENTRAL_CLAIM_UNSUPPORTED"
    ],
    "state": "BLOCKED"
  },
  "status": "OK"
}
```

**Research preliminary ratings — НЕ SI ratings**

```text
[
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "audience_interest",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "channel_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "angle_novelty",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "evidence_quality",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "narrative_potential",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "visual_feasibility",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "resource_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "risk_manageability",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "portfolio_distinctness",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  }
]
```

## Обмеження

- SI результат стосується лише supplied SI view, а не доведеного охоплення дослідження.
- Correspondence фіксує заяву, а не semantic equivalence або авторство.
- Research readiness не є SI eligibility або дозволом Topic Scoring.
- Бали й critique labels не доводять наукової істини, фактичної перевірки або незалежності людини.
- Редактор ухвалює рішення; bridge не створює рекомендацію, human findings або approval.
- Немає правового, комерційного, публікаційного або виробничого дозволу.

## Незаповнений бланк рішення людини

Бланк не підтверджує здійснений review. Нічого не обрано й не датовано програмою.

- [ ] Develop
- [ ] Research Further
- [ ] Reframe
- [ ] Reject
- [ ] Defer

**Обґрунтування:** ____________________

**Невирішені ризики:** ____________________

**Обраний ракурс:** ____________________

**Наступні дії:** ____________________

**Особа редактора (заповнити вручну):** ____________________

**Дата review:** ____________________

HUMAN_PILOT_PENDING
