# Редакторський розгляд — V1

Приватні записані дані, а не інструкції до виконання. Структура/labels не доводять істини, особи, прав або допуску. Остаточне рішення ухвалює людина.

## Тема та окремі стани

**Назва теми**

```text
Загадочные сигналы из космоса
```

**Дослідницьке питання**

```text
Какие объяснения условного наблюдения S допустимо сопоставлять без сенсационности?
```

**Аудиторія**

```text
Редактор учебного научно-популярного проекта
```

**Дослідницька готовність**

```text
NEEDS_INPUT
```

**SI eligibility — лише supplied SI view**

```text
SI_NOT_RUN
```

**Виробничий стан — не допуск**

```text
NOT_ASSESSED
```

**Зв’язок Research ↔ SI не доведено; recorded scope — заява**

```text
{
  "correspondence_state": "NO_FRAME",
  "declared_correspondence": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "dossier_sha256": "784c6bd399ac20cfdf070dbd4f3acd51cea07c7c9f0f037608fba9eb41ae3f8a",
  "evidence_correspondence": "EXACT_REPLAY_MATCH",
  "evidence_report_sha256": "24c03eaed0f4bf9228137690bd171f649cb6076b0c64b8b692baa1f32cfa38ad",
  "frame_origin": "NONE",
  "frame_sha256": null,
  "research_snapshot_sha256": "b869c5dcfd9e2368b2b6eb20859a03cefff48fefc341babf037eab4e9a097466",
  "semantic_coverage_verified": false
}
```

**Критичні зауваження — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
      "id": "00000004-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_RUN_SAME_PROVIDER",
    "delivery": "DELIVERED",
    "editor_action": "Получить отдельную человеческую критику гипотезы I.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Only synthetic metadata; no actual model run."
    },
    "provenance": {
      "kind": "MODEL_PROPOSED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Synthetic model proposal, NO provider execution"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какие объяснения условного наблюдения S допустимо сопоставлять без сенсационности?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Найти первичный материал вручную и отметить зависимости перепечаток."
      }
    }
  }
]
```

**Прогалини та відсутні підтвердження**

```text
[
  {
    "code": "SOURCE_NOT_RETRIEVED",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_NOT_RETRIEVED",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "MATERIAL_REUSED",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      },
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
        "id": "00000004-0000-4000-8000-000000000007",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_INDEPENDENCE_UNKNOWN",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
        "id": "00000004-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
        "id": "00000004-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Записана пропозиція та ризики з input — не нове рішення**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "recorded": {
    "editorial_risks": [],
    "gaps": [
      "Найти первичный материал вручную и отметить зависимости перепечаток.",
      "Получить отдельную человеческую критику гипотезы I."
    ],
    "production_limits": {
      "state": "KNOWN",
      "value": [
        "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
      ]
    },
    "prospect": "RESEARCH_MORE",
    "reasons": [
      {
        "basis_claim_refs": [
          {
            "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
            "id": "00000004-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ],
        "kind": "RESEARCH_GAP",
        "text": "Требуется отдельное человеческое рассмотрение; данные только синтетические."
      }
    ],
    "scientific_risks": []
  },
  "source_ref": {
    "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
    "id": "00000004-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  },
  "state": "RECORDED"
}
```

Бракує записаних даних; це не вердикт щодо істинності.

## Твердження та доказові зв’язки

### Твердження 1

**Початковий текст твердження**

```text
Синтетический кейс 4: СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: условное наблюдение S отделено от гипотезы I; происхождение реальных космических сигналов здесь не установлено.
```

**Точний RRef**

```text
{
  "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
  "id": "00000004-0000-4000-8000-000000000002",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип і центральність (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "factual"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записана перевірка — не засвідчений факт review**

```text
{
  "details": {
    "reason": "Fixture: explicitly not supplied",
    "state": "UNKNOWN"
  },
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "NOT_REVIEWED"
}
```

**Невизначеність**

```text
{
  "level": "UNKNOWN",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Підтримувальні зв’язки — не proof істини

[Джерело 1](#source-1)

**Джерело**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точний RRef**

```text
{
  "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
  "id": "00000004-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записана підстава зв’язку**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Суперечні зв’язки

NOT_RECORDED

#### Контекстні/недостатні зв’язки

NOT_RECORDED

**Прогалини та відсутні підтвердження**

```text
[
  {
    "code": "SOURCE_NOT_RETRIEVED",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "MATERIAL_REUSED",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      },
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  },
  {
    "code": "CRITIQUE_INDEPENDENCE_UNKNOWN",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
        "id": "00000004-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  },
  {
    "code": "CRITIQUE_HIGH",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
        "id": "00000004-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      },
      {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "critiques"
  }
]
```

**Критичні зауваження — unresolved/declared**

```text
[
  {
    "critique_ref": {
      "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
      "id": "00000004-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    "declared_independence": "SEPARATE_RUN_SAME_PROVIDER",
    "delivery": "DELIVERED",
    "editor_action": "Получить отдельную человеческую критику гипотезы I.",
    "independence_basis": {
      "state": "KNOWN",
      "value": "Only synthetic metadata; no actual model run."
    },
    "provenance": {
      "kind": "MODEL_PROPOSED",
      "method_label": {
        "state": "KNOWN",
        "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
      },
      "producer_label": {
        "state": "KNOWN",
        "value": "Synthetic model proposal, NO provider execution"
      },
      "upstream_refs": []
    },
    "resolution_state": "NOT_RECORDED",
    "severity": "HIGH",
    "target": {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    "unresolved_issues": {
      "alternative": {
        "state": "KNOWN",
        "value": "Какие объяснения условного наблюдения S допустимо сопоставлять без сенсационности?"
      },
      "counterargument": {
        "state": "KNOWN",
        "value": "Предоставленные данные не устанавливают общий вывод о реальном мире."
      },
      "issue": {
        "state": "KNOWN",
        "value": "СИНТЕТИЧЕСКАЯ критика: Найти первичный материал вручную и отметить зависимости перепечаток."
      }
    }
  }
]
```

### Твердження 2

**Початковий текст твердження**

```text
СИНТЕТИЧЕСКАЯ редакционная интерпретация: Какие объяснения условного наблюдения S допустимо сопоставлять без сенсационности?
```

**Точний RRef**

```text
{
  "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
  "id": "00000004-0000-4000-8000-000000000007",
  "research_type": "ResearchClaimV1",
  "revision": 1
}
```

**Тип і центральність (записано)**

```text
{
  "kind": {
    "state": "KNOWN",
    "value": "interpretation"
  },
  "materiality": {
    "state": "KNOWN",
    "value": "CENTRAL"
  }
}
```

**Записана перевірка — не засвідчений факт review**

```text
{
  "details": {
    "reason": "Fixture: explicitly not supplied",
    "state": "UNKNOWN"
  },
  "provenance": {
    "kind": "MODEL_PROPOSED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "state": "NOT_REVIEWED"
}
```

**Невизначеність**

```text
{
  "level": "UNKNOWN",
  "reasons": {
    "state": "KNOWN",
    "value": [
      "Реальные доказательства и применимость здесь не проверялись."
    ]
  }
}
```

#### Підтримувальні зв’язки — не proof істини

[Джерело 2](#source-2)

**Джерело**

```text
СИНТЕТИЧЕСКИЙ локальный материал 91
```

**Точний RRef**

```text
{
  "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
  "id": "00000004-0000-4000-8000-000000000006",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Фрагмент**

```text
F1
```

**Записана підстава зв’язку**

```text
Записанная связь с искусственным фрагментом, не научная верификация.
```

#### Суперечні зв’язки

NOT_RECORDED

#### Контекстні/недостатні зв’язки

NOT_RECORDED

**Прогалини та відсутні підтвердження**

```text
[
  {
    "code": "SOURCE_NOT_RETRIEVED",
    "level": "INPUT",
    "record_refs": [
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "SOURCE_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "MATERIAL_REUSED",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
        "id": "00000004-0000-4000-8000-000000000001",
        "research_type": "ResearchSourceV1",
        "revision": 1
      },
      {
        "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
        "id": "00000004-0000-4000-8000-000000000006",
        "research_type": "ResearchSourceV1",
        "revision": 1
      }
    ],
    "section": "sources"
  },
  {
    "code": "CLAIM_REVIEW_MISSING",
    "level": "REVIEW",
    "record_refs": [
      {
        "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
        "id": "00000004-0000-4000-8000-000000000007",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    ],
    "section": "claims"
  }
]
```

**Критичні зауваження — unresolved/declared**

```text
[]
```

## Джерела, фрагменти та обмеження

### Source 1

**Джерело**

```text
СИНТЕТИЧЕСКИЙ локальный материал 1
```

**Точний RRef**

```text
{
  "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
  "id": "00000004-0000-4000-8000-000000000001",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Локатор як дані (не активне посилання)**

```text
{
  "kind": "LOCAL_ID",
  "value": "synthetic-local-1"
}
```

**Автор / організація / дати — як надано**

```text
{
  "author": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "organization": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "published_at": {
    "state": "KNOWN",
    "value": {
      "precision": "YEAR",
      "value": "2020"
    }
  },
  "retrieved_at": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  }
}
```

**Записана перевірка — не засвідчений факт review**

```text
{
  "kind": "EDITOR_DECLARED",
  "method_label": {
    "state": "KNOWN",
    "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
  },
  "producer_label": {
    "state": "KNOWN",
    "value": "Researcher A"
  },
  "upstream_refs": []
}
```

**П’ять незалежних записаних observations**

```text
{
  "content": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_REVIEWED"
  },
  "editor_confirmation": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_REVIEWED"
  },
  "integrity": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "HASH_REPORTED"
  },
  "link_existence": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_CHECKED"
  },
  "retrieval": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_RETRIEVED"
  }
}
```

**Обмеження**

```text
[
  "Искусственные данные для теста; не свидетельство о реальном мире."
]
```

**Фрагмент**

```text
F1
```

**Точний наданий текст — не verified quote**

```text
СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: условное наблюдение S отделено от гипотезы I; происхождение реальных космических сигналов здесь не установлено.
```

**Наданий покажчик**

```text
Синтетический параграф 1
```

**Точний RRef**

```text
{
  "state": "KNOWN",
  "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
}
```

### Source 2

**Джерело**

```text
СИНТЕТИЧЕСКИЙ локальный материал 91
```

**Точний RRef**

```text
{
  "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
  "id": "00000004-0000-4000-8000-000000000006",
  "research_type": "ResearchSourceV1",
  "revision": 1
}
```

**Локатор як дані (не активне посилання)**

```text
{
  "kind": "LOCAL_ID",
  "value": "synthetic-local-91"
}
```

**Автор / організація / дати — як надано**

```text
{
  "author": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "organization": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  },
  "published_at": {
    "state": "KNOWN",
    "value": {
      "precision": "YEAR",
      "value": "2020"
    }
  },
  "retrieved_at": {
    "reason": "Не предоставлено; не восстановлено автоматически.",
    "state": "UNKNOWN"
  }
}
```

**Записана перевірка — не засвідчений факт review**

```text
{
  "kind": "EDITOR_DECLARED",
  "method_label": {
    "state": "KNOWN",
    "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
  },
  "producer_label": {
    "state": "KNOWN",
    "value": "Researcher A"
  },
  "upstream_refs": [
    {
      "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
      "id": "00000004-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

**П’ять незалежних записаних observations**

```text
{
  "content": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_REVIEWED"
  },
  "editor_confirmation": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_REVIEWED"
  },
  "integrity": {
    "basis": {
      "state": "KNOWN",
      "value": "СИНТЕТИЧЕСКОЕ заявление для проверки структуры."
    },
    "origin": {
      "state": "KNOWN",
      "value": "EDITOR_DECLARED"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "HASH_REPORTED"
  },
  "link_existence": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_CHECKED"
  },
  "retrieval": {
    "basis": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "origin": {
      "reason": "Fixture: explicitly not supplied",
      "state": "UNKNOWN"
    },
    "reviewed_material_sha256": {
      "state": "KNOWN",
      "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
    },
    "state": "NOT_RETRIEVED"
  }
}
```

**Обмеження**

```text
[
  "Искусственные данные для теста; не свидетельство о реальном мире."
]
```

**Фрагмент**

```text
F1
```

**Точний наданий текст — не verified quote**

```text
СИНТЕТИЧЕСКИЙ МАТЕРИАЛ: условное наблюдение S отделено от гипотезы I; происхождение реальных космических сигналов здесь не установлено.
```

**Наданий покажчик**

```text
Синтетический параграф 1
```

**Точний RRef**

```text
{
  "state": "KNOWN",
  "value": "40c2b7c68425a55e991256d12e0b63009d1519eb6d547b362b28c8603b544794"
}
```

## Дії редактора — порядок джерел, а не новий пріоритет

### 1 — CONTROLLED_ACTION

```text
Отримайте матеріал вручну; URL не підтверджує отримання.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[0]",
      "record_refs": [
        {
          "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
          "id": "00000004-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "908560d8cd51eac4698e24ff307722677ffa732fa0926842a266114884ee3a5c",
      "source_action": {
        "action": {
          "ru": "Получите материал вручную; URL не подтверждает получение.",
          "uk": "Отримайте матеріал вручну; URL не підтверджує отримання."
        },
        "code": "SOURCE_NOT_RETRIEVED",
        "record_refs": [
          {
            "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
            "id": "00000004-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    },
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[2]",
      "record_refs": [
        {
          "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
          "id": "00000004-0000-4000-8000-000000000006",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "908560d8cd51eac4698e24ff307722677ffa732fa0926842a266114884ee3a5c",
      "source_action": {
        "action": {
          "ru": "Получите материал вручную; URL не подтверждает получение.",
          "uk": "Отримайте матеріал вручну; URL не підтверджує отримання."
        },
        "code": "SOURCE_NOT_RETRIEVED",
        "record_refs": [
          {
            "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
            "id": "00000004-0000-4000-8000-000000000006",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
      "id": "00000004-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    },
    {
      "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
      "id": "00000004-0000-4000-8000-000000000006",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 2 — CONTROLLED_ACTION

```text
Окремо розгляньте підстави п’яти спостережень та обмеження джерела.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[1]",
      "record_refs": [
        {
          "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
          "id": "00000004-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "908560d8cd51eac4698e24ff307722677ffa732fa0926842a266114884ee3a5c",
      "source_action": {
        "action": {
          "ru": "Отдельно рассмотрите основания пяти наблюдений и ограничения источника.",
          "uk": "Окремо розгляньте підстави п’яти спостережень та обмеження джерела."
        },
        "code": "SOURCE_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
            "id": "00000004-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    },
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[3]",
      "record_refs": [
        {
          "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
          "id": "00000004-0000-4000-8000-000000000006",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "908560d8cd51eac4698e24ff307722677ffa732fa0926842a266114884ee3a5c",
      "source_action": {
        "action": {
          "ru": "Отдельно рассмотрите основания пяти наблюдений и ограничения источника.",
          "uk": "Окремо розгляньте підстави п’яти спостережень та обмеження джерела."
        },
        "code": "SOURCE_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
            "id": "00000004-0000-4000-8000-000000000006",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
      "id": "00000004-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    },
    {
      "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
      "id": "00000004-0000-4000-8000-000000000006",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 3 — CONTROLLED_ACTION

```text
Встановіть походження спільного матеріалу; не вважайте його незалежним підтвердженням.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[4]",
      "record_refs": [
        {
          "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
          "id": "00000004-0000-4000-8000-000000000001",
          "research_type": "ResearchSourceV1",
          "revision": 1
        },
        {
          "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
          "id": "00000004-0000-4000-8000-000000000006",
          "research_type": "ResearchSourceV1",
          "revision": 1
        }
      ],
      "sha256": "908560d8cd51eac4698e24ff307722677ffa732fa0926842a266114884ee3a5c",
      "source_action": {
        "action": {
          "ru": "Установите происхождение общего материала; не считайте его независимым подтверждением.",
          "uk": "Встановіть походження спільного матеріалу; не вважайте його незалежним підтвердженням."
        },
        "code": "MATERIAL_REUSED",
        "record_refs": [
          {
            "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
            "id": "00000004-0000-4000-8000-000000000001",
            "research_type": "ResearchSourceV1",
            "revision": 1
          },
          {
            "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
            "id": "00000004-0000-4000-8000-000000000006",
            "research_type": "ResearchSourceV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "1b3b73aa5aa58dbf71513e6046f4ddd9129a9644d59037e88f6078f21fb6cb1f",
      "id": "00000004-0000-4000-8000-000000000001",
      "research_type": "ResearchSourceV1",
      "revision": 1
    },
    {
      "content_sha256": "9688ff61440e9bf9b648cab9ad01b698de4a50ebb42f37c10c1fc16bb0ecd5ef",
      "id": "00000004-0000-4000-8000-000000000006",
      "research_type": "ResearchSourceV1",
      "revision": 1
    }
  ]
}
```

### 4 — CONTROLLED_ACTION

```text
Запишіть розгляд точних матеріалів та невизначеності твердження.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[5]",
      "record_refs": [
        {
          "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
          "id": "00000004-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "908560d8cd51eac4698e24ff307722677ffa732fa0926842a266114884ee3a5c",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
            "id": "00000004-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    },
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[6]",
      "record_refs": [
        {
          "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
          "id": "00000004-0000-4000-8000-000000000007",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "908560d8cd51eac4698e24ff307722677ffa732fa0926842a266114884ee3a5c",
      "source_action": {
        "action": {
          "ru": "Запишите рассмотрение точных материалов и неопределённости утверждения.",
          "uk": "Запишіть розгляд точних матеріалів та невизначеності твердження."
        },
        "code": "CLAIM_REVIEW_MISSING",
        "record_refs": [
          {
            "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
            "id": "00000004-0000-4000-8000-000000000007",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    {
      "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
      "id": "00000004-0000-4000-8000-000000000007",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 5 — CONTROLLED_ACTION

```text
Уточніть незалежність критика; labels не засвідчують особу.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[7]",
      "record_refs": [
        {
          "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
          "id": "00000004-0000-4000-8000-000000000003",
          "research_type": "ResearchCritiqueV1",
          "revision": 1
        },
        {
          "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
          "id": "00000004-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "908560d8cd51eac4698e24ff307722677ffa732fa0926842a266114884ee3a5c",
      "source_action": {
        "action": {
          "ru": "Уточните независимость критика; labels не удостоверяют личность.",
          "uk": "Уточніть незалежність критика; labels не засвідчують особу."
        },
        "code": "CRITIQUE_INDEPENDENCE_UNKNOWN",
        "record_refs": [
          {
            "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
            "id": "00000004-0000-4000-8000-000000000003",
            "research_type": "ResearchCritiqueV1",
            "revision": 1
          },
          {
            "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
            "id": "00000004-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
      "id": "00000004-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 6 — CONTROLLED_ACTION

```text
Передайте суттєві зауваження людині; збережіть розбіжності.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[8]",
      "record_refs": [
        {
          "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
          "id": "00000004-0000-4000-8000-000000000003",
          "research_type": "ResearchCritiqueV1",
          "revision": 1
        },
        {
          "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
          "id": "00000004-0000-4000-8000-000000000002",
          "research_type": "ResearchClaimV1",
          "revision": 1
        }
      ],
      "sha256": "908560d8cd51eac4698e24ff307722677ffa732fa0926842a266114884ee3a5c",
      "source_action": {
        "action": {
          "ru": "Передайте существенные замечания человеку; сохраните разногласия.",
          "uk": "Передайте суттєві зауваження людині; збережіть розбіжності."
        },
        "code": "CRITIQUE_HIGH",
        "record_refs": [
          {
            "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
            "id": "00000004-0000-4000-8000-000000000003",
            "research_type": "ResearchCritiqueV1",
            "revision": 1
          },
          {
            "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
            "id": "00000004-0000-4000-8000-000000000002",
            "research_type": "ResearchClaimV1",
            "revision": 1
          }
        ]
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
      "id": "00000004-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 7 — CONTROLLED_ACTION

```text
Перед Topic Scoring передайте точний звіт редактору та розгляньте всі збережені зауваження; автоматичного допуску немає.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[9]",
      "record_refs": [],
      "sha256": "908560d8cd51eac4698e24ff307722677ffa732fa0926842a266114884ee3a5c",
      "source_action": {
        "action": {
          "ru": "Перед Topic Scoring передайте точный отчёт редактору и рассмотрите все сохранённые замечания; автоматического допуска нет.",
          "uk": "Перед Topic Scoring передайте точний звіт редактору та розгляньте всі збережені зауваження; автоматичного допуску немає."
        },
        "code": "EDITOR_REVIEW_REQUIRED",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 8 — CONTROLLED_ACTION

```text
За потреби надайте готовий SI frame; дослідження ще не оцінено SI.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[10]",
      "record_refs": [],
      "sha256": "908560d8cd51eac4698e24ff307722677ffa732fa0926842a266114884ee3a5c",
      "source_action": {
        "action": {
          "ru": "При необходимости предоставьте готовый SI frame; исследование ещё не оценено SI.",
          "uk": "За потреби надайте готовий SI frame; дослідження ще не оцінено SI."
        },
        "code": "NO_SI_FRAME",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 9 — CONTROLLED_ACTION

```text
Людина розглядає всі дев’ять SI ratings і findings; preliminary ratings не імпортуються автоматично.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicScoringBridgeReportV1",
      "field_path": "$.editorial_decision_support.next_actions[11]",
      "record_refs": [],
      "sha256": "908560d8cd51eac4698e24ff307722677ffa732fa0926842a266114884ee3a5c",
      "source_action": {
        "action": {
          "ru": "Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.",
          "uk": "Людина розглядає всі дев’ять SI ratings і findings; preliminary ratings не імпортуються автоматично."
        },
        "code": "HUMAN_SI_REVIEW",
        "record_refs": []
      }
    }
  ],
  "record_refs": []
}
```

### 10 — RECORDED_GAP

```text
Найти первичный материал вручную и отметить зависимости перепечаток.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[0]",
      "record_ref": {
        "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
        "id": "00000004-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
      "id": "00000004-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 11 — RECORDED_GAP

```text
Получить отдельную человеческую критику гипотезы I.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.gaps[1]",
      "record_ref": {
        "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
        "id": "00000004-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
      "id": "00000004-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 12 — RECORDED_ACTION

```text
Найти первичный материал вручную и отметить зависимости перепечаток.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[0]",
      "record_ref": {
        "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
        "id": "00000004-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
      "id": "00000004-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    }
  ]
}
```

### 13 — RECORDED_ACTION

```text
Получить отдельную человеческую критику гипотезы I.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "TopicRecommendationV1",
      "field_path": "$.payload.next_actions[1]",
      "record_ref": {
        "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
        "id": "00000004-0000-4000-8000-000000000004",
        "research_type": "TopicRecommendationV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchCritiqueV1",
      "field_path": "$.payload.editor_action",
      "record_ref": {
        "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
        "id": "00000004-0000-4000-8000-000000000003",
        "research_type": "ResearchCritiqueV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
      "id": "00000004-0000-4000-8000-000000000004",
      "research_type": "TopicRecommendationV1",
      "revision": 1
    },
    {
      "content_sha256": "5c10a0028a3472ecee2e4b25e8409643d0a274d9040ef5e2b35a96bf1e581445",
      "id": "00000004-0000-4000-8000-000000000003",
      "research_type": "ResearchCritiqueV1",
      "revision": 1
    },
    {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

### 14 — RECORDED_ACTION

```text
Получить реальные материалы вручную.
```

**Походження дії та всі посилання**

```text
{
  "origins": [
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
        "id": "00000004-0000-4000-8000-000000000002",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    },
    {
      "artifact": "ResearchClaimV1",
      "field_path": "$.payload.further_research.actions[0]",
      "record_ref": {
        "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
        "id": "00000004-0000-4000-8000-000000000007",
        "research_type": "ResearchClaimV1",
        "revision": 1
      }
    }
  ],
  "record_refs": [
    {
      "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
      "id": "00000004-0000-4000-8000-000000000002",
      "research_type": "ResearchClaimV1",
      "revision": 1
    },
    {
      "content_sha256": "075f0165222d6415f5c5b259f90694f3232fcc3aaa4fcd1df528a8242f5fddaf",
      "id": "00000004-0000-4000-8000-000000000007",
      "research_type": "ResearchClaimV1",
      "revision": 1
    }
  ]
}
```

## Лише записані творчі пропозиції

RECORDED

**Точний RRef**

```text
{
  "provenance": {
    "kind": "EDITOR_DECLARED",
    "method_label": {
      "state": "KNOWN",
      "value": "MANUAL INPUT — SYNTHETIC FIXTURE"
    },
    "producer_label": {
      "state": "KNOWN",
      "value": "Researcher A"
    },
    "upstream_refs": []
  },
  "source_ref": {
    "content_sha256": "d0a535e609443b52811f3a2cc9f19f3b00c63bfdc3171d94b02ef02e6294b465",
    "id": "00000004-0000-4000-8000-000000000004",
    "research_type": "TopicRecommendationV1",
    "revision": 1
  }
}
```

**Записаний основний ракурс**

```text
Какие объяснения условного наблюдения S допустимо сопоставлять без сенсационности?
```

### Альтернативні ракурси

```text
Сузить вопрос до конкретного примера: Какие объяснения условного наблюдения S допустимо сопоставлять без сенсационности?
```

**Точний RRef**

```text
[
  {
    "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
    "id": "00000004-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Обмеження**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

### Емоційні хуки

```text
Наблюдение и его объяснение — разные вопросы.
```

**Точний RRef**

```text
[
  {
    "content_sha256": "8a56445aff6cb22cf0c9e97d8453914ef2841bacee784ba7cd1c6544baaaa4fc",
    "id": "00000004-0000-4000-8000-000000000002",
    "research_type": "ResearchClaimV1",
    "revision": 1
  }
]
```

**Обмеження**

```text
[
  "Человеческое предложение; не установленный факт или разрешение производства."
]
```

### Інтелектуальні хуки

NOT_RECORDED

**Записаний оповідний потенціал**

UNKNOWN

```text
Не предоставлено; не восстановлено автоматически.
```

**Записані візуальні потреби — не готові assets/права**

```text
[
  "Помеченная учебная схема; реальные материалы/права не предоставлены."
]
```

**Обмеження**

```text
[
  "Реальные материалы, права и production approval отсутствуют в этом synthetic fixture."
]
```

**Структуровані narrative alternatives — поля немає в прийнятому input**

```text
{
  "reason": "NO_STRUCTURED_FIELD_IN_ACCEPTED_INPUT",
  "state": "NOT_RECORDED"
}
```

## Незмінене SI оцінювання supplied frame

```text
SI_NOT_RUN
```

### Наявна Projection card — лише supplied SI view

NOT_RECORDED

| Критерій | Вага | Початкова SI оцінка | Confidence |
|---|---:|---|---|
| Інтерес аудиторії | 15 | SI_NOT_RUN | — |
| Відповідність каналу | 10 | SI_NOT_RUN | — |
| Новизна ракурсу | 10 | SI_NOT_RUN | — |
| Якість підстав | 20 | SI_NOT_RUN | — |
| Оповідний потенціал | 15 | SI_NOT_RUN | — |
| Візуальна здійсненність | 10 | SI_NOT_RUN | — |
| Відповідність ресурсам | 10 | SI_NOT_RUN | — |
| Керованість ризиками | 5 | SI_NOT_RUN | — |
| Відмінність від портфеля | 5 | SI_NOT_RUN | — |

**Початковий aggregate_tenths — без перерахунку шкали**

```text
null
```

**Наявний результат evaluator (не рішення людини)**

```text
null
```

**Research preliminary ratings — НЕ SI ratings**

```text
[
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "audience_interest",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "channel_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "angle_novelty",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "evidence_quality",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "narrative_potential",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "visual_feasibility",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "resource_fit",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "risk_manageability",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  },
  {
    "basis_refs": [],
    "confidence": {
      "basis": "Не измерено.",
      "level": "UNKNOWN"
    },
    "criterion_key": "portfolio_distinctness",
    "editor_choice": {
      "state": "KNOWN",
      "value": {
        "chosen_value": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reason": "Не подставлять автоматический рейтинг.",
        "reviewed_at": {
          "reason": "Не предоставлено; не восстановлено автоматически.",
          "state": "UNKNOWN"
        },
        "reviewed_refs": [],
        "reviewer_label": "Researcher A"
      }
    },
    "origin": "EDITOR_DECLARED",
    "proposed_value": {
      "reason": "Не предоставлено; не восстановлено автоматически.",
      "state": "UNKNOWN"
    },
    "rationale": "Нет достаточного основания; UNKNOWN выбран человеком."
  }
]
```

## Обмеження

- SI результат стосується лише supplied SI view, а не доведеного охоплення дослідження.
- Correspondence фіксує заяву, а не semantic equivalence або авторство.
- Research readiness не є SI eligibility або дозволом Topic Scoring.
- Бали й critique labels не доводять наукової істини, фактичної перевірки або незалежності людини.
- Редактор ухвалює рішення; bridge не створює рекомендацію, human findings або approval.
- Немає правового, комерційного, публікаційного або виробничого дозволу.

## Незаповнений бланк рішення людини

Бланк не підтверджує здійснений review. Нічого не обрано й не датовано програмою.

- [ ] Develop
- [ ] Research Further
- [ ] Reframe
- [ ] Reject
- [ ] Defer

**Обґрунтування:** ____________________

**Невирішені ризики:** ____________________

**Обраний ракурс:** ____________________

**Наступні дії:** ____________________

**Особа редактора (заповнити вручну):** ____________________

**Дата review:** ____________________

HUMAN_PILOT_PENDING
