# SI-PRODUCT-02.3.5 — Independent Human Pilot Protocol

Date: 2026-11-16. **HUMAN_PILOT_PENDING.**
Participants: **0**. Completed human sessions: **0**. Human utility acceptance: **NOT_ASSESSED**.
This is preparation, not a fabricated study, editorial approval or production gate.
Base: `5cc46ef26bc78ea452d256a64ceb7f5c0359c4a1`.

## Purpose and role separation

Test whether an independent person can use the private Markdown review view to
answer Q1–Q5 without inspecting input JSON. Structural automated tests do not count
as that person's judgment. The moderator/implementation author must not impersonate
the independent editor, fill their answers or award subjective PASS automatically.
Owner recruits an actual independent editor and records role/conflicts before any
session. A second person may moderate; an author reviewing their own output is not
independent user evidence. No automatic contact, account creation or external upload.

All five cases are synthetic. Source statements, critic labels and SI ratings are
fixtures, not authentic reviews, clinical advice or scientific findings. No renderer,
TTS, provider, network acquisition or production is part of this pilot.

## Materials and privacy

Use the five unchanged CASE-01–CASE-05 inputs from 02.3.4. Generated private packets
are included in the review archive as Markdown (A/B, ru/uk); JSON is an audit sidecar,
not required reading for the participant. Give one chosen locale to the participant,
respecting original source wording (no automatic translation of quotations).

Choose A (research-only) or B (independent supplied generic SI frame) explicitly and
record the choice. In B, score/eligibility concern only that supplied SI view, whose
correspondence to the research is unverified. The participant should recognize this
boundary; do not silently present the generic frame as a topic-specific scientific
assessment. Oracles/OR-01/answer key are moderator-only until after responses.

Real future editor identities, notes, recordings and research materials stay in a
new private local directory under explicit operator control. Do not commit/publish
feedback or personal data to GitHub without separate owner consent. This package
contains only synthetic examples and a blank feedback form. POSIX modes are not
Windows ACL qualification or authoritative persistence.

## Session procedure (not executed)

1. Record participant consent/pseudonym, independence, locale, case/mode, exact view
   file SHA-256 and application/renderer used. Do not infer authentication from a name.
2. Explain that the worksheet is blank, source data are untrusted recorded statements,
   source links are literal data, no command or external URL should be executed, and
   no decision here grants scientific/rights/editorial/production authority.
3. Let the editor read only the Markdown. Do not coach or show the JSON/oracle first.
4. Start/stop a real timer with the person's consent; leave times unfilled until then.
5. Ask the six tasks below; record their own words, navigation problems and errors.
6. Collect the five qualitative assessments separately. No total score/topic ranking.
7. Debrief using moderator facts only after answers. Preserve first responses and
   disagreements. Real decisions remain separate from authority/production approval.

## Tasks for every CASE

- P1: Read the view without the source JSON.
- P2: Explain the topic state, separately identifying research readiness, SI eligibility
  (or SI_NOT_RUN) and production NOT_ASSESSED. Do not answer with one “ready” flag.
- P3: Identify scientific/editorial/informational/production limitations, including
  missing/contradicting material, HIGH/CRITICAL and declared critique independence.
- P4: Choose up to two **recorded** claims; locate their source and exact fragment,
  or explicitly state that supporting evidence is NOT_RECORDED/UNKNOWN. Record exact
  claim/source refs or source numbers. Finding “no evidence” is not inventing evidence.
- P5: Propose the next human editorial step, distinguishing supplied actions from a
  new personal choice. Do not treat generic SI score as proof of research coverage.
- P6: Choose/reject/defer a **recorded** angle/hook/visual need, or state NOT_RECORDED.
  No request to generate scientific findings, sources, medical advice or new assets.

### P4 data limitation — do not fabricate a second claim or task completion

CASE-01/04/05 contain two recorded claims. CASE-02/03 contain **one**. Original 02.3.4
fixtures/contracts are not changed to fill the missing second slot.

For CASE-02/03, P4 target_count=2, available_count=1; second slot is **NOT_RECORDED /
TASK_DATA_LIMITATION**, not automatically PASS or a second verified claim. The moderator
records the participant's recognition of that absence. The original two-claim retrieval
task is not described as fully completed for those cases. Owner can later authorize
additional fixtures or a revised study task; this protocol does not approve that change.
No human has executed P4 yet, so all actual task verdicts remain NOT_ASSESSED.

## Blank feedback form (copy for each person × CASE × mode × locale)

```json
{
  "pilot_status": "HUMAN_PILOT_PENDING",
  "participant_identity_or_pseudonym": null,
  "consent_record": null,
  "independence_record": null,
  "moderator_identity": null,
  "case_id": null,
  "mode": null,
  "locale": null,
  "view_sha256": null,
  "renderer": null,
  "started_at": null,
  "finished_at": null,
  "elapsed_seconds": null,
  "P1_read_without_json": null,
  "P2_state_explanation_verbatim": null,
  "P3_risks_verbatim": null,
  "P4_claim_one_ref": null,
  "P4_claim_one_evidence_or_absence": null,
  "P4_claim_two_ref": null,
  "P4_claim_two_evidence_or_absence": null,
  "P4_task_data_limitation": null,
  "P5_next_step_verbatim": null,
  "P6_recorded_option_choice_or_rejection": null,
  "clarity": "NOT_ASSESSED",
  "traceability": "NOT_ASSESSED",
  "risk_visibility": "NOT_ASSESSED",
  "actionability": "NOT_ASSESSED",
  "creative_usefulness": "NOT_ASSESSED",
  "interpretation_errors": null,
  "editor_comments": null
}
```

After real participation, record PASS/PARTIAL/FAIL/NOT_ASSESSED for each qualitative
trait, with the person's comments, disagreements and provenance. No automatic PASS
from a generated file, successful unit test, time value or filled name. No averaging
or composite utility/SI score. Time is an actual observation, not a fabricated value.

## Moderator-only baseline — not human findings

- CASE-01: H1/H2 remain distinct; second support absent; HIGH; narrow period/region;
  two supplied angles. No universal explanation of every ancient civilization.
- CASE-02: CRITICAL, no clinical support/material capture, one claim only; no actual
  medical instruction; generic B SI BLOCKED despite a high fixture score.
- CASE-03: one claim, scoped teaching analogy, HIGH wording caution, supplied visual
  need; no verified aviation facts or visual rights; generic B SI ELIGIBLE is not research proof.
- CASE-04: shared reported material/dependency and MODEL_PROPOSED critique; research
  NEEDS_INPUT, genuine B SI NEEDS_RESEARCH/UNKNOWN per R1/N04. Original 02.3.4 oracle
  error OR-01 must not be taught as the runtime contract.
- CASE-05: source lineage/contradiction and HIGH self-review; no broad debunking of
  actual history; two recorded claims, no production authority.

These are synthetic task-data checks, not ratings assigned by a human editor.

## Reporting and STOP

Owner assesses human evidence only after real sessions. Until then:
**HUMAN_PILOT_PENDING**, all five traits NOT_ASSESSED, no claim of full product usefulness.
The implementation may be reviewed as an EDITORIAL_VIEW_ONLY candidate; acceptance
belongs to independent owner review. No future feature work is authorized by this protocol.

## Participant prompts — RU / UK (use one locale, do not coach answers)

| Task | RU | UK |
|---|---|---|
| P1 | Прочитайте Markdown без исходного JSON. | Прочитайте Markdown без початкового JSON. |
| P2 | Объясните отдельно исследовательскую готовность, SI eligibility и производственное состояние. | Поясніть окремо дослідницьку готовність, SI eligibility та виробничий стан. |
| P3 | Назовите основные риски и что ещё неизвестно. | Назвіть основні ризики й що ще невідомо. |
| P4 | Найдите два записанных claim и их основания либо укажите отсутствие. Если claim только один, не придумывайте второй. | Знайдіть два записані claim та їхні підстави або вкажіть відсутність. Якщо claim лише один, не вигадуйте другий. |
| P5 | Какой следующий шаг выбрали бы вы и на каком основании? | Який наступний крок обрали б ви й на якій підставі? |
| P6 | Выберите или отклоните уже записанный ракурс; если его нет, укажите NOT_RECORDED. | Оберіть або відхиліть уже записаний ракурс; якщо його немає, вкажіть NOT_RECORDED. |

| Feedback key | RU label | UK label |
|---|---|---|
| clarity | Понятность | Зрозумілість |
| traceability | Прослеживаемость оснований | Простежуваність підстав |
| risk_visibility | Видимость рисков | Видимість ризиків |
| actionability | Применимость действий | Застосовність дій |
| creative_usefulness | Полезность творческих вариантов | Корисність творчих варіантів |
| elapsed_seconds | Реальное время выполнения | Реальний час виконання |
| interpretation_errors | Ошибки интерпретации | Помилки тлумачення |
| editor_comments | Собственные комментарии редактора | Власні коментарі редактора |

All response slots remain blank/NOT_ASSESSED until actual independent participation.
