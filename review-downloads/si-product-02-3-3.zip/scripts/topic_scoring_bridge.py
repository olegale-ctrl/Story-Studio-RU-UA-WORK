"""Read-only research/SI juxtaposition; no research-to-SI builder or new scoring."""
from copy import deepcopy
from hashlib import sha256
from story_intelligence.records_v1 import si_record_ref
from scripts import research_intake, evidence_critique, editor_preview

# Approved display registry only. No formula, rating generation, threshold or total.
CRITERIA = (('audience_interest',15),('channel_fit',10),('angle_novelty',10),
            ('evidence_quality',20),('narrative_potential',15),('visual_feasibility',10),
            ('resource_fit',10),('risk_manageability',5),('portfolio_distinctness',5))
TEXT = {
    'INPUT_INVALID': ('Предоставьте согласованные dossier, evidence report и неизменённый Preview input.', 'Надайте узгоджені досьє, evidence report та незмінений Preview input.'),
    'NO_SI_FRAME': ('При необходимости предоставьте готовый SI frame; исследование ещё не оценено SI.', 'За потреби надайте готовий SI frame; дослідження ще не оцінено SI.'),
    'SCOPE_UNVERIFIED': ('Рассмотрите точное соответствие исследования и supplied SI; смысловой охват не доказан.', 'Розгляньте точну відповідність дослідження та supplied SI; змістове охоплення не доведено.'),
    'SI_NOT_RUN': ('Дополните supplied SI input; результат оценки отсутствует.', 'Доповніть supplied SI input; результат оцінювання відсутній.'),
    'SI_STALE': ('Рассмотрите устаревшие SI зависимости; не подменяйте ссылки автоматически.', 'Розгляньте застарілі SI залежності; не підміняйте посилання автоматично.'),
    'PROJECTION_UNAVAILABLE': ('Карточка недоступна; не заменяйте её исследовательской рекомендацией.', 'Картка недоступна; не замінюйте її дослідницькою рекомендацією.'),
    'HUMAN_SI_REVIEW': ('Человек рассматривает все девять SI ratings и findings; preliminary ratings не импортируются автоматически.', 'Людина розглядає всі дев’ять SI ratings і findings; preliminary ratings не імпортуються автоматично.'),
}
LIMITATIONS = [
    ('SI результат относится только к supplied SI view, не к доказанному охвату исследования.', 'SI результат стосується лише supplied SI view, а не доведеного охоплення дослідження.'),
    ('Correspondence фиксирует заявление, не semantic equivalence или авторство.', 'Correspondence фіксує заяву, а не semantic equivalence або авторство.'),
    ('Research readiness не является SI eligibility или разрешением Topic Scoring.', 'Research readiness не є SI eligibility або дозволом Topic Scoring.'),
    ('Баллы и critique labels не доказывают научную истину, фактическую проверку или независимость человека.', 'Бали й critique labels не доводять наукової істини, фактичної перевірки або незалежності людини.'),
    ('Редактор принимает решение; bridge не создаёт рекомендацию, human findings или approval.', 'Редактор ухвалює рішення; bridge не створює рекомендацію, human findings або approval.'),
    ('Нет правового, коммерческого, публикационного или производственного разрешения.', 'Немає правового, комерційного, публікаційного або виробничого дозволу.'),
]


def localized(pair):return dict(ru=pair[0],uk=pair[1])


def digest(v):return sha256(research_intake.wire(v)).hexdigest()


def integrate(dossier, evidence_report, *, existing_preview_input=None, locale='ru'):
    """Return (controlled status, detached TopicScoringBridgeReportV1), INVALID/None.

    Existing pinned verification may re-execute the existing evaluator. This bridge
    never recomputes scores itself or changes those returned values/decisions.
    """
    invalid=dict(state='INVALID',diagnostics=[dict(code='INPUT_INVALID',action=localized(TEXT['INPUT_INVALID']))])
    try:
        if type(locale) is not str or locale not in ('ru','uk'):
            return invalid,None
        research_intake.bounded(dossier,depth=-2)
        research_intake.bounded(evidence_report,depth=-4)
        if existing_preview_input is not None:research_intake.bounded(existing_preview_input)
        d,e,explicit=deepcopy((dossier,evidence_report,existing_preview_input))
        status,expected=evidence_critique.analyze(d,locale)
        if status['state']!='OK' or expected is None or research_intake.wire(e)!=research_intake.wire(expected):
            return invalid,None
        snapshot=d['input_snapshot']
        embedded=research_intake.value(snapshot['existing_preview_input'])
        if explicit is not None:
            research_intake.preview_shape(explicit,'existing_preview_input')
            if embedded is not None and research_intake.wire(explicit)!=research_intake.wire(embedded):
                return invalid,None
        frame=embedded if explicit is None else explicit
        frame_origin=('NONE' if frame is None else 'DOSSIER' if explicit is None
                      else 'EXPLICIT_MATCHED_DOSSIER' if embedded is not None else 'EXPLICIT')
        actual,artifacts,result=None,{},None
        if frame is not None:
            # The existing Preview owns evaluate_si and Projection re-verification.
            actual,artifacts=editor_preview.preview(deepcopy(frame))
            state=actual['evaluation']['state']
            if actual['input_completeness']=='INVALID' or state in ('INVALID','FAILED'):
                return invalid,None
            result=artifacts.get('evaluation.json')
            if embedded is not None:
                recorded=research_intake.value(d['preview_status'])
                if recorded is None or research_intake.wire(actual)!=research_intake.wire(recorded):
                    return invalid,None
        else:state='NO_FRAME'
        declared=research_intake.value(snapshot['evaluation_correspondence'])
        if frame is not None and declared is not None:
            inputs=frame.get('evaluation_inputs')
            if type(inputs) is not dict or digest(inputs)!=declared['evaluation_inputs_sha256']:
                return invalid,None
            si_refs={research_intake.wire(si_record_ref(r)) for r in inputs.get('records',[])}
            if any(research_intake.wire(link['si_ref']) not in si_refs for link in declared['correspondence']):
                return invalid,None
        recommendation=research_intake.value(snapshot['recommendation'])
        binding=None if recommendation is None else research_intake.value(recommendation['payload']['evaluation_binding'])
        if binding is not None and (declared is None or binding!=digest(declared)):
            return invalid,None
    except Exception:
        # Dependency/validation failures cannot become a partial positive report.

        return invalid,None

    association=('NO_FRAME' if frame is None else d['preview_association']
                 if embedded is not None else 'UNVERIFIED_SCOPE')
    # No accepted semantic-equivalence proof exists here. A recorded scope statement
    # must never become VERIFIED, including when all hashes happen to match.
    identity=dict(dossier_sha256=digest(d),research_snapshot_sha256=d['intake_sha256'],
        evidence_report_sha256=digest(e),evidence_correspondence='EXACT_REPLAY_MATCH',
        frame_origin=frame_origin,frame_sha256=None if frame is None else digest(frame),
        declared_correspondence=deepcopy(snapshot['evaluation_correspondence']),
        correspondence_state=association,semantic_coverage_verified=False)
    context={name:deepcopy(e[name]) for name in ('claim_review','source_review','critique_review',
        'reused_materials','evidence_gaps','research_readiness','limitations')}
    # All accepted ratings are copied; preliminary research values are not admitted.
    criteria_review=[]
    accepted=result['ratings'] if result is not None and result['status']=='OK' else []
    for i,(key,weight) in enumerate(CRITERIA):
        flags=['EDITOR_DECISION_REQUIRED']
        if not accepted:flags.append('NO_ACCEPTED_SI_RATING')
        else:
            r=accepted[i]
            if r['value']['state']=='UNKNOWN':flags.append('VALUE_UNKNOWN')
            if r['confidence']['level']=='UNKNOWN':flags.append('CONFIDENCE_UNKNOWN')
        criteria_review.append(dict(criterion_key=key,review_context=flags))
    actions=deepcopy(e['editor_actions'])
    def note(code):actions.append(dict(code=code,record_refs=[],action=localized(TEXT[code])))
    if frame is None:note('NO_SI_FRAME')
    else:
        note('SCOPE_UNVERIFIED')
        if state=='NOT_RUN':note('SI_NOT_RUN')
        if state=='STALE':note('SI_STALE')
        if any(v['state']!='DISPLAYABLE' for v in actual['cards'].values()):note('PROJECTION_UNAVAILABLE')
    note('HUMAN_SI_REVIEW')
    report=dict(schema_version='TopicScoringBridgeReportV1',purpose='RESEARCH_ONLY',
        research_identity=identity,evidence_context=context,
        si_scoring_context=dict(state=state,criteria=[dict(criterion_key=k,weight=w) for k,w in CRITERIA],
            evaluation_result=deepcopy(result),supplied_si_ratings=(deepcopy(frame['evaluation_inputs'].get('ratings'))
                if frame is not None and type(frame.get('evaluation_inputs')) is dict else None)),
        editorial_decision_support=dict(research_preliminary_assessments=deepcopy(snapshot['preliminary_assessments']),
            criteria_for_human_review=criteria_review,next_actions=actions,
            recorded_recommendation=deepcopy(snapshot['recommendation']),recommendation_generated=False),
        preview=dict(status=deepcopy(actual),artifacts=deepcopy(artifacts)),
        production_state='NOT_ASSESSED',limitations=[localized(x) for x in LIMITATIONS])
    return dict(state='OK',diagnostics=[]),report
