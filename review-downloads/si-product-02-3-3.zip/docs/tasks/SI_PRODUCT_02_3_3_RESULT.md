# SI-PRODUCT-02.3.3 — Topic Scoring Integration / Research-to-SI Bridge

Дата: 2026-11-16. **READY_FOR_INDEPENDENT_REVIEW.**
Объём: private deterministic integration, без SI builder/scoring/authority.

## Identity и exact scope

- Repository: `olegale-ctrl/Story-Studio-RU-UA-WORK`.
- Exact base / parent: `e9512ab420c87e9c56cf5d97b348dfdae2e99e6a`.
- Branch: `feat/si-product-02-3-3-topic-scoring-integration`.
- Основание: owner task 02.3.3, OWNER_AUTHORIZED_FOR_IMPLEMENTATION.
- Result SHA — commit с этим отчётом; полный SHA в HANDOFF.json архива и финальной
  передаче, без self-reference в bytes самого commit.
- Exact base присутствовал, source worktree был чистым; новая ветка от exact SHA.

Ровно пять путей:

1. [scripts/topic_scoring_bridge.py](../../scripts/topic_scoring_bridge.py) — новый API.
2. [tests/test_topic_scoring_bridge.py](../../tests/test_topic_scoring_bridge.py) — 29 новых tests.
3. [examples/topic_scoring_bridge_example.json](../../examples/topic_scoring_bridge_example.json) — synthetic input/output packet.
4. Этот RESULT.
5. [WORKLOG](../../project-log/WORKLOG.md) — только append; base prefix byte-exact.

Нет изменений существующих intake/evidence/Preview/evaluator/Projection, SI/1,
схем, контрактов, прежних tests/goldens, Storage, зависимостей или CI.
RD-01–04/HIST-01=A сохраняются. Новый отдельный TopicScoringBridgeReportV1 прямо
предусмотрен owner task; это не расширение закрытых существующих input schemas.

## Фактические интерфейсы и граница вычислений

Прочитаны `research_intake.intake`, `evidence_critique.analyze`,
`editor_preview.preview`, `evaluate_si`, `project_evaluation`, RD/HIST документы.
Evaluator возвращает plain dict с status/currentness, eligibility, aggregate_tenths,
ratings, diagnostics; на INVALID/STALE нет принятого aggregate/eligibility.
Preview внутри вызывает evaluate_si и Projection RU/UK; Projection обязательно
повторяет evaluator для проверки соответствия inputs/result (утверждённый PD-01).

Фраза задания «SI оценка не пересчитывается» реализована как **отсутствие собственного
пересчёта/изменения результата в bridge**, не отключение обязательной безопасной
re-verification существующих API. Реальное выполнение этих API происходит и явно
не скрывается: score/UNKNOWN/eligibility/diagnostics копируются byte-equivalent
из настоящего result. Нельзя обещать zero evaluator executions при использовании
этого Preview или обходить PD-01. Новый bridge не содержит формулы total, sum,
thresholds, rating generation либо нового scoring engine.

## API и controlled failure

```python
from scripts.topic_scoring_bridge import integrate
status, report = integrate(dossier, evidence_report,
                           existing_preview_input=None, locale="ru")
```

Также ru/uk; без fallback/автоперевода исходного текста. Fixed actions/limitations
bilingual `{ru,uk}`, поэтому при одном snapshot report bytes одинаковы для ru/uk.

- Успех: `{state:OK,diagnostics:[]}`, detached TopicScoringBridgeReportV1.
- Отказ: `{state:INVALID,diagnostics:[{code:INPUT_INVALID,action:{ru,uk}}]}`, report=None.
  Нет partial positive report, raw exception/path/private-value disclosure или repair.
- Bounded JSON values проверяются перед deepcopy. `evidence_critique.analyze`
  воспроизводит принятый dossier через intake, включая закрытые поля, SHA/RRef,
  revisions/HIST и genuine optional Preview. Evidence report сравнивается с actual
  replay output по полным canonical bytes: fake readiness/refs/hash/verified flags
  или удалённые gaps не принимаются.
- Изменение порядка object keys допустимо через canonical comparison; значения,
  array order, hashes и исходный Unicode не нормализуются/не подменяются.
- Явно заявленные frame/binding/evidence failures дают controlled INVALID/None.
  Dependency exceptions также не становятся успешным частичным report.

## Optional frame и correspondence

| Вход | Поведение |
|---|---|
| Нет explicit frame и embedded UNKNOWN | Только research report; NO_FRAME, SI result=None, Preview отсутствует |
| Embedded frame, explicit=None | Используется неизменённый embedded frame; origin DOSSIER |
| Explicit frame, embedded UNKNOWN | Используется явный supplied frame; origin EXPLICIT, scope UNVERIFIED_SCOPE |
| Explicit и embedded совпадают canonical | EXPLICIT_MATCHED_DOSSIER |
| Explicit и embedded различаются | INVALID, без автоматического rebasing/выбора более нового |

Frame передаётся `editor_preview.preview` без новых полей, переноса topic/angle,
ratings/finding synthesis или автоматического построения SI records. Сохраняются
фактические evaluation/cards/plan JSON values; функция bridge не пишет/не исполняет
эти артефакты и не вызывает production. Embedded Preview status должен совпасть
с воспроизведённым status. Source dossier/evidence/frame не меняются.

Malformed Preview/input/graph или actual evaluator INVALID/FAILED → bridge INVALID,
не новый SI eligibility state. Genuine STALE остаётся STALE с null eligibility/
aggregate; incomplete structurally valid frame может дать NOT_RUN, result=None.
Genuine OK/BLOCKED/NEEDS_INPUT/NEEDS_RESEARCH/REVIEW_DUPLICATE/ELIGIBLE_FOR_CREATIVE
принимаются только как actual evaluator outcome, без изменения значения/приоритета.
Projection UNAVAILABLE не заменяется Card или research recommendation.

При Known declared correspondence проверяются точный evaluation_inputs_sha256 и
наличие каждого заявленного exact SIRef в supplied records. Known recommendation
binding должен совпадать с canonical digest полного correspondence object; иначе
INVALID. Сами research refs уже проверены accepted intake/EC replay. Нет введения
новых SI fields или ERef adapter. Partial/unknown semantic scope не додумывается.

`SCOPE_REVIEW_RECORDED` сохраняется лишь как ранее проверенное recorded заявление
embedded dossier. Explicit frame без embedded не повышает прежний NO_FRAME к
verified scope. **semantic_coverage_verified всегда false**: hash consistency или
scope note не доказывают semantic equivalence/полноту/identity. При frame всегда
сохраняется действие SCOPE_UNVERIFIED; SI result относится только к supplied SI view.
Без frame NO_FRAME означает отсутствие SI frame/result в данном вызове, не утверждение
обо всех возможных исследованиях/оценках вне supplied snapshot.

## Отдельный output

`schema_version=TopicScoringBridgeReportV1`, `purpose=RESEARCH_ONLY`:

- `research_identity`: full canonical dossier/evidence-report hashes, original
  research snapshot intake_sha256, EXACT_REPLAY_MATCH, frame origin/hash,
  declared correspondence, recorded state и semantic_coverage_verified=false.
- `evidence_context`: exact copies claim/source/critique review, reused_materials,
  evidence_gaps, research_readiness и все evidence limitations. Ни один supporting/
  contradicting link, HIGH/CRITICAL/UNKNOWN или unresolved note не исчезает.
- `si_scoring_context`: actual state/result, original supplied SI ratings и
  display registry утверждённых девяти критериев/весов 15/10/10/20/15/10/10/5/5.
  Это **не** вычислительная таблица нового scoring engine.
- `editorial_decision_support`: original preliminary assessments отдельно;
  все девять критериев для human consideration, только literal UNKNOWN/no accepted
  rating flags; все evidence actions и дополнительные fixed bridge actions.
  Declared recommendation отображается как **recorded**, recommendation_generated=false.
- `preview`: actual status/artifacts или None/empty при NO_FRAME. Plans — только
  supplied manual drafts, не автоматически созданные материалы/производство.
- `production_state=NOT_ASSESSED`; шесть обязательных limitations.

Research readiness NEEDS_INPUT/NEEDS_REVIEW/READY_FOR_EDITOR_REVIEW — separate axis.
Она не превращается в SI eligibility, не разрешает Topic Scoring или производство.
High preliminary ratings не превращаются в SI ratings/human findings. UNKNOWN
не становится 0; missing scoring не заменяется research total.
Никаких новых научных фактов, авторов, quotes, hooks, audience demand или решений.

## Воспроизводимый пример

JSON содержит **только synthetic** dossier, actual matching evidence_report,
existing synthetic EditorPreviewInputV1 и actual status/report вызова integrate.
Это не реальные независимые human reviews/исторические свидетельства.
Expected: OK, research NEEDS_REVIEW, genuine SI ELIGIBLE_FOR_CREATIVE, unverified scope,
production NOT_ASSESSED. Разные readiness/eligibility не объединены и не скрыты.

```python
import json
from scripts.topic_scoring_bridge import integrate
with open("examples/topic_scoring_bridge_example.json", encoding="utf-8") as f:
    example = json.load(f)  # committed synthetic fixture only
status, report = integrate(example["dossier"], example["evidence_report"],
                           existing_preview_input=example["existing_preview_input"],
                           locale="uk")
assert status == example["status"]
assert report == example["report"]
```

Для настоящих материалов весь report private: exact RRefs/hashes/declared critic
notes не предназначены для public Projection. Реальных private research inputs,
credentials, keys, models или media в Git/archive нет.

## Фактически выполненные проверки

Linux/Python 3.12.14, project `.venv`, без новых зависимостей.

| Suite/check | Tests | Exit |
|---|---:|---:|
| bridge | 29 | 0 |
| research | 49 | 0 |
| preview | 16 | 0 |
| full | 1234 | 0 |
| compileall | — | 0 |
| diff-check | — | 0 |

Final completed unit suites: failures=0, errors=0, skips=0, expectedFailure=0.
Команды (`python` — `/workspace/Story-Studio-RU-UA-WORK/.venv/bin/python`):

```text
python -m unittest tests.test_topic_scoring_bridge -v
python -m unittest tests.test_research_intake tests.test_evidence_critique -v
python -m unittest tests.test_editor_preview -v
python -m unittest discover -s tests -v
python -m compileall -q scripts/topic_scoring_bridge.py tests/test_topic_scoring_bridge.py
git diff --check
```

29 tests включают T01–T24 один-к-одному по names + embedded/explicit conflicts,
recorded scope/binding corruption, genuine STALE/INVALID/NOT_RUN, privacy/failure
handling и exact committed example reproduction. Independent assertions сравнивают
полные returned SI results с настоящим evaluate_si/Preview, literal approved weights,
fixed known aggregate fixture 1000 и UNKNOWN; входные dicts сравниваются до/после.
Нет mocked positive evaluation results; только real wrappers и negative fault exception.

Первый development targeted run: 29 tests, exit 1, errors=1 из-за неверного field
lookup в **новом тесте** Rubric (`H.record_type` вместо actual H.type; actual weight
field — weight_percent). Проверка исправлена по реальной схеме/public si_record_ref;
existing schemas/source не менялись. First log приложен, ошибка не скрыта. Финальные
запуски выше — после исправления; source/test/example hashes frozen и проверены при
упаковке. Full suite не выдаётся за PASS по одному тексту OK: проверен actual exit 0.

Новые tests блокируют socket/HTTP/subprocess/TTS/render/wave functions и assert-not-called
во всех своих сценариях. Legacy full discovery включает неизменённые D1 synthetic
integration tests с temporary PROJECT/RENDER/VIDEO outputs; это не production/research
render из bridge. Временные media не включены в архив.

## Ограничения и передача

Re-verification стоит CPU и может повторять evaluator несколько раз при embedded
frame. Она не отключена/не заменена unsafe trust cache. Performance optimization/
новая proof/receipt authority потребовали бы отдельного контракта. Нет authenticity
proof личности/фактического review, scientific certainty, global research completeness,
rights clearance, LLM/provider/network acquisition, automatic SI builder, persistence,
production permissions или нового scoring engine. Нового blocking contract gap нет.

Implementation commit только local; точные SHA, file statistics и clean worktree —
в HANDOFF.json. `si-product-02-3-3.zip` и `.sha256` передаются только в существующую
ветку `artifacts/si-product-02-3-0-research-contract`, `review-downloads/`.
Нет implementation push, PR, merge, tag, release или main changes.
PUBLISH_REVISION DISABLED; partial COMMIT reconstruction OFF; S3.2b не запускается.

**STOP — WAIT FOR INDEPENDENT REVIEW.**
