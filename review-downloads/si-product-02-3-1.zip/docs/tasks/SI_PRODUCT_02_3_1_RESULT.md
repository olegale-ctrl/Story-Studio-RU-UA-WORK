# SI-PRODUCT-02.3.1 — Manual-First Research Intake Result

Date: 2026-11-16. **STATUS: BLOCKED_CONTRACT / PRE_IMPLEMENTATION.**

## Identity and authorization

- Repository: `olegale-ctrl/Story-Studio-RU-UA-WORK`.
- Exact base / parent: `73dd049e94b6f968b250e9ad8bb9ce5d294e283a`.
- Branch: `feat/si-product-02-3-1-research-intake`.
- Result SHA: the commit containing this report; full SHA is supplied in the external
  `HANDOFF.json` and final response, avoiding self-reference in the committed bytes.
- Exact base exists and source worktree was clean; new branch created from that SHA.
- The current owner START task accepts 02.3.0/02.3.0a and authorizes implementation.
  Historical BLOCKED_BY_DEPENDENCY text is superseded by that authorization.
  RD-01–RD-04 remain A / APPROVED. No renewed vote on those decisions is requested.
- This STOP follows the current instruction to stop on contract contradictions;
  it is not a refusal based on historical proposal headers or lack of permission.

## Required technical task could not be located

The instruction refers to a previously prepared **full technical task 02.3.1**.
On the exact base there are only the research contract, integration matrix, owner
registry and historical results for 02.3.0/0a. No 02.3.1 technical-task file exists.
`git ls-tree -r --name-only 73dd049e94b6f968b250e9ad8bb9ce5d294e283a`
was inspected; remote heads matching `*02-3-1*` were absent before branch creation.
The original uploaded 02.3.0 task was also read in full: it requires proposal docs,
not an executable 02.3.1 task. The current START message supplies the allowlist,
features and R-T01–R-T18 requirement, but not the missing detailed specification.

[Research contract §3](SI_PRODUCT_02_3_0_RESEARCH_CONTRACT.md) lines 82–83 delegates
file limits and CLI to that separate task. This absence alone is reported as missing
input, not treated as evidence that implementation permission was withheld.

## RI-G01 — Historical recommendations cannot be carried by the closed intake

Evidence in [Research contract](SI_PRODUCT_02_3_0_RESEARCH_CONTRACT.md):

- §3, lines 68–80: four envelope types, exact previous revisions, retained history;
  missing refs, cycles and hash mismatches must be structural failures.
- §6, lines 225–232: a critique may target an earlier TopicRecommendationV1;
  a new recommendation references the critique and previous snapshot to avoid cycles.
- §9.1, lines 379–391: closed ResearchIntakeV1 has lists only for sources, claims,
  critiques, and a **single** `K<TopicRecommendationV1>` recommendation. It has no
  archive/history list or resolver input for earlier recommendations.
- No local storage or arbitrary material-file traversal may be added to fill the gap.

### Minimal graph witness (contract analysis, not an executed runtime failure)

Let `P1` be TopicRecommendation revision 1. Let `C1` be a delivered critique whose
`target` is the exact RRef of P1. Let `P2` be revision 2 of the same recommendation,
with `previous` identifying P1 and `research_snapshot_refs` containing C1.
All hashes can be correct; the graph is acyclic: P2 → C1 → P1, and P2 → P1.

In a closed intake with `recommendation=KNOWN(P2)` and `critiques=KNOWN([C1])`,
there is no field for the P1 envelope. An RRef is not the record bytes needed to
validate its hash/history. The known containers cannot safely carry P1:

1. Adding a `history` field changes the closed input schema.
2. Putting P1 in sources/claims/critiques violates the listed envelope types.
3. Making recommendation a list changes its declared K<TopicRecommendationV1> type.
4. Skipping the P1 lookup violates fail-closed exact-ref checking.
5. Retargeting C1 to P2 changes provenance and creates the forbidden cycle.
6. Loading P1 from an invented store/path adds an unapproved input/storage mechanism.

Therefore the allowed historical case has no defined representation. Rejecting every
such history would silently narrow the documented revision workflow; accepting it
without its record would weaken validation. Neither choice is made here.
This is a specification witness, **not a confirmed bug in an existing intake module**.

### Minimal clarification needed

Provide the full technical task, or an explicit narrow amendment defining where exact
historical recommendation envelopes are supplied and how closed validation resolves
those records. Alternatively explicitly bound this MVP to first recommendations and
state how historical cases are rejected. These are alternatives for owner selection,
not approvals or new wire fields introduced by this report. Preserve RD-01–RD-04,
exact refs, source history, optional SI frame and existing APIs in either outcome.
The same task should pin CLI/file limits delegated by §3; no additional scoring,
provider, identity authority or production mechanism is needed.

## What was and was not changed

Only:

1. This new `docs/tasks/SI_PRODUCT_02_3_1_RESULT.md`.
2. Append-only entry in `project-log/WORKLOG.md`.

No partial `research_intake.py`, tests or examples are created while the wire/history
question is unresolved. Existing SI/1, evaluator, Projection, Editor Preview,
contracts, golden vectors, CI and dependencies are unchanged. No search, LLM, TTS,
FFmpeg, rendering or production permission is implemented.

## Checks and test accounting

- Exact base and source clean state: PASS.
- New branch parent equals exact base: checked after local commit.
- Changed files: allowed subset above; WORKLOG base prefix remains byte-exact.
- Local Markdown links and `git diff --check`: checked before commit.
- R-T01–R-T18: **NOT_RUN / BLOCKED_CONTRACT**; zero new executable tests.
- Targeted intake, preview regression and full unittest: **NOT_RUN**. No runtime
  implementation exists for this task; no PASS or exit code is invented.
- Structural/document checks are not counted as Python unit tests.
- Archive CRC, file SHA-256 manifest, artifact remote SHA and source-worktree
  cleanliness: verified externally in the accompanying checks/handoff.

## Handoff and STOP

Only the review archive and its checksum may be pushed to the existing
`artifacts/si-product-02-3-0-research-contract` branch under `review-downloads/`.
The implementation branch remains local; no PR, merge, release, tag or main change.
The archive contains the committed report/WORKLOG, verification results and checksum
manifest. It does not contain a completed implementation or synthetic research passed
as verified evidence. No real private source material is published.

**STOP — WAIT FOR CONTRACT CLARIFICATION / INDEPENDENT REVIEW.**
